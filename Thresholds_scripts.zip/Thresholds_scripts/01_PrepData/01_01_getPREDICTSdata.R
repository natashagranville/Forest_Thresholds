#### PREDICTS data ------------------------------------------------------------

# remotes::install_github("timnewbold/predicts-demo",subdir="predictsFunctions")

library(dplyr)
library(fossil)
library(predictsFunctions)
library(readr)
library(sf)
library(stringr)


#### Get data ------------------------------------------------------------------
# Download PREDICTS data from NHM data portal
predicts <- readRDS("data/raw/PREDICTS_v1.1/PREDICTS_v1.1.rds")

#### Pre-processing ------------------------------------------------------------
# https://timnewbold.github.io/PredictsIntroduction.html

# Correct effort-sensitive abundance measures (assumes linear relationship between effort and recorded abundance)
predicts <- predictsFunctions::CorrectSamplingEffort(diversity = predicts)

# Combine sites with identical coordinates, belonging to same study and spatial block of sites, sampled on same dates with same method and metric
predicts <- predictsFunctions::MergeSites(diversity = predicts, silent = TRUE)

#### Subset for vertebrates and arthropods -------------------------------------------------

data <- subset(predicts, Phylum == 'Arthropoda'  | Phylum == 'Chordata')


#### Remove missing coords -----------------------------------------------------

## remove the missing coordinates
data <- subset(data, !is.na(data$Longitude | data$Latitude))


#### Convert abundance to occurrence -------------------------------------------

# - remove the measurements that are not abundance or occurrence
data <- subset(data, Diversity_metric == 'abundance' | Diversity_metric == 'occurrence' | Diversity_metric == 'effort-corrected abundance')

# - convert abundance to occurrence
data$occ <- ifelse(data$Measurement>0,1,0)

#### Sampling year(s) -----------------------------------------------------------
## summarise the sample date as the end year 

# - extract just the years from the start and end dates
data$Start_Year <- substr(data$Sample_start_earliest, 1, 4)
data$End_Year <- substr(data$Sample_end_latest, 1, 4)

# Combine start year and end year into one column 
data$Year <- ifelse(
  data$Start_Year == data$End_Year,
  data$Start_Year,
  paste(data$Start_Year, data$End_Year, sep = '-')
)


#### Study names ---------------------------------------------------------------

## make the Study column
# re-format the reference column to be consistent with the data from other databases
# so the study name is just first author and year

data$Study <- paste(gsub("^([A-Za-z]+).*", "\\1", data$Reference), 
                    as.integer(gsub("^.*([0-9]{4}).*", "\\1", data$Reference)), 
                    sep = '')

## check the names and correct if needed
unique(data$Study)
data$Study[data$Study == "B2010"] <- "Bocon2010"
data$Study[data$Study == "O2007"] <- "ODea2007"
data$Study[data$Study == "St2007"] <- "St-Laurent2007"
data$Study[data$Study == "B2005"] <- "Báldi2005"
data$Study[data$Study == "de2013"] <- "deLima2013"
data$Study[data$Study == "D2011"] <- "DCruze2011"
data$Study[data$Study == "de2008"] <- "deSouza2008"
data$Study[data$Study == "C2010"] <- "Caceres2010"
data$Study[data$Study == "O2008"] <- "OFarrell2008"
data$Study[data$Study == "K2012"] <- "Korosi2012"
data$Study[data$Study == "de2012"] <- "deSassi2012"
data$Study[data$Study == "R2012"] <- "Ros2012"
data$Study[data$Study == "L2011"] <- "Legaré2011"
data$Study[data$Study == "de2010"] <- "deThoisy2010"


## Remove Bóçon2010 where all the sites have the same coordinate
data <- subset(data, Study != 'Bóçon2010')


## Remove duplicate study
data$Study_plus_year <- paste(data$Study, data$Year, sep = "_")
sort(unique(data$Study_plus_year))

data <- subset(data, Study_plus_year != "Sam2014_2010")

data <- data %>% dplyr::select(- Study_plus_year)

#### Site ID -------------------------------------------------------------------
## make a unique site ID
data$SiteID <- paste(data$Study, data$Site_number, sep = '_')



#### Format ----------------------------------------------

# label database
data$Database <- 'PREDICTS'


# select columns of interest
colnames(data)
data <- subset(data, select = c("Database", "Study", "SiteID", "Class",
                                "Taxon_name_entered", "occ",
                                "Latitude",  "Longitude", 
                                "Sampling_method", "Year", "Realm",
                                "Ecoregion", "Biome"))

# rename columns 
names(data)[names(data) == 'occ'] <- 'Occupancy'
names(data)[names(data) == 'Sampling_method'] <- 'Method'
names(data)[names(data) == 'Scientific_name'] <- 'Species'
names(data)[names(data) == 'Taxon_name_entered'] <- 'Species'

# re-format the Methods
data$Method <- as.character(data$Method)
unique(data$Method)

data$Method[data$Method == "mist-netting"] <- "Mist_net"
data$Method[data$Method == "point counts"] <- "Point_count"
data$Method[data$Method == "line/belt transects"] <- "Line_transect"
data$Method[data$Method == "systematic searching"] <- "Systematic_searching"
data$Method[data$Method == "visual encounter survey"] <- "Visual_encounter_survey"
data$Method[data$Method == "aerial transect"] <- "Line_transect"
data$Method[data$Method == "call playback"] <- "Call_playback"
data$Method[data$Method == "camera traps"] <- "Camera_trap"
data$Method[data$Method == "random walk"] <- "Random_walk"
data$Method[data$Method == "various"] <- "Various"


data$Realm <- as.character(data$Realm)
unique(data$Realm)

data$Realm[data$Realm == "Neotropic"] <- "Neotropical"
data$Realm[data$Realm == "Afrotropic"] <- "Afrotropical"
data$Realm[data$Realm == "Australasia"] <- "Australasian"




#### Remove temporal replicates ---------------------------
### Remove temporal replicate studies to reduce pseudoreplication

# remove replicate of part of Azprioz study 
Azpiroz <- subset(data, Study %in% c("Azpiroz2009"))
Azpiroz_to_remove <- subset(Azpiroz, Year == 2005)
data <- anti_join(st_drop_geometry(data), Azpiroz_to_remove, by = c("Study", "Year"))

# remove temporal replicate of Brandt study 
Brandt <- subset(data, Study %in% c("Brandt2013"))
Brandt_to_remove <- subset(Brandt, Year == 2011)
data <- anti_join(st_drop_geometry(data), Brandt_to_remove, by = c("Study", "Year"))

# remove temporal replicates of Lehouck study 
Lehouck <- subset(data, Study %in% c("Lehouck2009"))
Lehouck_to_remove <- subset(Lehouck, Year == 2005 | Year == 2006)
data <- anti_join(st_drop_geometry(data), Lehouck_to_remove, by = c("Study", "Year"))

# Lehouck: remove replicate with different method listed
data <- subset(data, Study != "Lehouck2009")
Lehouck_to_keep <- subset(Lehouck, Method != "Visual_encounter_survey")
data <- rbind(data, Lehouck_to_keep)

# remove temporal replicate of Ndang study 
Ndang <- subset(data, Study %in% c("Ndang2013"))
Ndang_to_remove <- subset(Ndang, Year == "2011-2012")
data <- anti_join(st_drop_geometry(data), Ndang_to_remove, by = c("Study", "Year"))

data <- subset(data, Study != "Ranganathan2008")
data <- subset(data, Study != "Urbina2008")
data <- subset(data, Study != "Garc2013")
data <- subset(data, Study != "Kutt2012")
data <- subset(data, Study != "Blanche2006")


data <- subset(data, Study != "Craig2009")
data <- subset(data, Study != "Craig2012")
data <- subset(data, Study != "Craig2014")
data <- subset(data, Study != "Craig2015")

data <- subset(data, Study != "Borges2006")
data <- subset(data, Study != "Farwig2009")
data <- subset(data, Study != "Littlewood2012")
data <- subset(data, Study != "Noriega2012")
data <- subset(data, Study != "Rey2012")
data <- subset(data, Study != "Uehara2007")
data <- subset(data, Study != "Uehara2009")
data <- subset(data, Study != "Vu2009")
data <- subset(data, Study != "Waite2013")



#### Rename spatial replicates ----------
# where there are two separate studies conducted in separate locations by the same author
# ensure the studies have distinct names

# Rename distinct studies by Munyekenye
Munyekenye_conditions <- data$Study == "Munyekenye2008" & data$Year %in% c("2004-2005", "2005")
Munyekenye_new_study_values <- ifelse(data$Year == "2004-2005", "Munyekenye2008a", "Munyekenye2008b")
data$Study[Munyekenye_conditions] <- Munyekenye_new_study_values[Munyekenye_conditions]

data <- subset(data, Study != "Munyenkenye2008b")

# Rename distinct studies by Otto
Otto_conditions <- data$Study == "Otto2012" & data$Year %in% c("2010", "2011")
Otto_new_study_values <- ifelse(data$Year == "2010", "Otto2012a", "Otto2012b")
data$Study[Otto_conditions] <- Otto_new_study_values[Otto_conditions]

data <- subset(data, Study != "Otto2012b")

# Rename distinct studies by Rey
Rey_conditions <- data$Study == "Rey2010" & data$Year %in% c("2008", "2009")
Rey_new_study_values <- ifelse(data$Year == "2008", "Rey2010a", "Rey2010b")
data$Study[Rey_conditions] <- Rey_new_study_values[Rey_conditions]

data <- subset(data, Study != "Rey2010b")

# Rename distinct studies by Woinarski
Woinarski_conditions <- data$Study == "Woinarski2009" & data$Year %in% c("2006", "2007", "2008")
Woinarski_new_study_values <- ifelse(data$Year == "2006", "Woinarski2009a",
                                     ifelse(data$Year == "2007", "Woinarski2009b",
                                            ifelse(data$Year == "2008", "Woinarski2009c", data$Study)))
data$Study[Woinarski_conditions] <- Woinarski_new_study_values[Woinarski_conditions]

data <- subset(data, Study != "Woinarski2009c")
data <- subset(data, Study != "Woinarski2009b")

# Remove Li study as it's too small
data <- subset(data, Study != "Li2013")

#### Combine year labels where  different year labels are listed for the same study --------
data[data$Study == "Jolli2011",]$Year <- "2009-2011"



#### Remove studies also found in BIOFRAG database ---------------------------------
data <- subset(data, Study != "Phalan2011")
data <- subset(data, Study != "Marsh2010")
data <- subset(data, Study != "Urbina2006")
data <- subset(data, Study != "Ewers2007")
data <- subset(data, Study != "Ewers2013")
data <- subset(data, Study != "Struebig2008")
data <- subset(data, Study != "Stouffer2011")
data <- subset(data, Study != "Ribeiro2012")
data <- subset(data, Study != "DCruze2011")
data <- subset(data, Study != "Tylianakis2005")
data <- subset(data, Study != "Lantschner2012")
data <- subset(data, Study != "Wells2007")
data <- subset(data, Study != "Lachat2006")
data <- subset(data, Study != "Hawes2009")
data <- subset(data, Study != "Barlow2007")
data <- subset(data, Study != "Watling2009")
data <- subset(data, Study != "Lasky2010")
data <- subset(data, Study != "Proen2010")
data <- subset(data, Study != "Cleary2004")
data <- subset(data, Study != "Gardner2007")

#### Make PID labels ------------
unique(data$Class)

data <- subset(data, ! Class == "")

data$Class <- as.character(data$Class)

data$Class[data$Class == "Aves"] <- "Birds"
data$Class[data$Class == "Amphibia"] <- "Amphibians"
data$Class[data$Class == "Reptilia"] <- "Reptiles"
data$Class[data$Class == "Mammalia"] <- "Mammals"

data <- data %>% mutate(Author = str_extract(Study, "[A-Za-z]+"))

data$PID <- paste0(data$Class, "_", data$Author)
data_split <- split(data, data$PID)  # Splitting the dataset

for(i in 1:length(data_split)){
  data_split[[i]]$PID <- paste0("PID3", sprintf("%03d", i), "_", data_split[[i]]$PID) 
}
data <- do.call(rbind, data_split)  

unique(data$PID)

### Check again which taxa are included 
unique(data$Class)

data <- subset(data, Class != "Malacostraca")
data <- subset(data, Class != "Maxillopoda")


## Further cleaning

# remove study where I couldn't calculate forest cover at all the required scales
# some of these studies span a huge spatial extent, making it pretty much infeasible to make the high-resolution forest cover calculations we need
data <- subset(data, PID != "PID3021_Arachnida_Alberta")
data <- subset(data, PID != "PID3186_Insecta_Cameron")
data <- subset(data, PID != "PID3187_Insecta_Cardoso")
data <- subset(data, PID != "PID3193_Insecta_Davis")
data <- subset(data, PID != "PID3227_Insecta_Johnson")
data <- subset(data, PID != "PID3237_Insecta_Krauss")
data <- subset(data, PID != "PID3289_Insecta_Sch")
data <- subset(data, PID != "PID3298_Insecta_Todd")
data <- subset(data, PID != "PID3303_Insecta_Vasconcelos")
data <- subset(data, PID != "PID3294_Insecta_Smith")
data <- subset(data, PID != "PID3119_Birds_Woinarski")
data <- subset(data, PID != "PID3266_Insecta_Osgathorpe")
data <- subset(data, PID != "PID3297_Insecta_Summerville")
data <- subset(data, PID != "PID3362_Mammals_Woinarski")
data <- subset(data, PID != "PID3381_Reptiles_Woinarski")
data <- subset(data, PID != "PID3116_Birds_Sodhi")

# no species matrix here
data <- subset(data, PID != "PID3154_Diplopoda_Vasconcelos")

data <- subset(data, PID != "PID3216_Birds_Sodhi")


# only one site here
data <- subset(data, PID != "PID3073_Birds_deThoisy")
data <- subset(data, PID != "PID3128_Chilopoda_Carpenter")

# only one species here
data <- subset(data, PID != "PID3134_Chilopoda_Poveda")
data <- subset(data, PID != "PID3138_Chilopoda_Todd")
data <- subset(data, PID != "PID3141_Diplopoda_Basset")
data <- subset(data, PID != "PID3142_Diplopoda_Boutin")
data <- subset(data, PID != "PID3144_Diplopoda_Carpenter")
data <- subset(data, PID != "PID3152_Diplopoda_Todd")
data <- subset(data, PID != "PID3153_Diplopoda_Turner")
data <- subset(data, PID != "PID3157_Entognatha_Boutin")
data <- subset(data, PID != "PID3159_Entognatha_Ge")
data <- subset(data, PID != "PID3160_Entognatha_Muchane")
data <- subset(data, PID != "PID3161_Entognatha_Poveda")
data <- subset(data, PID != "PID3164_Entognatha_Turner")
data <- subset(data, PID != "PID3232_Insecta_Knight")
data <- subset(data, PID != "PID3241_Insecta_Liow")
data <- subset(data, PID != "PID3271_Insecta_Peters")
data <- subset(data, PID != "PID4125_Symphyla_Mulder")
data <- subset(data, PID != "PID4124_Symphyla_Blasi")
data <- subset(data, PID != "PID4122_Pauropoda_Mulder")
data <- subset(data, PID != "PID4121_Pauropoda_Burton")
data <- subset(data, PID != "PID4120_Pauropoda_Blasi")
data <- subset(data, PID != "PID3313_Insecta_Winfree")
data <- subset(data, PID != "PID3338_Mammals_Clarke")
data <- subset(data, PID != "PID3369_Mammals_St")
data <- subset(data, PID != "PID3376_Pauropoda_Basset")
data <- subset(data, PID != "PID3396_Symphyla_Todd")
data <- subset(data, PID != "PID3377_Pauropoda_Carpenter")
data <- subset(data, PID != "PID4048_Chilopoda_Blasi")
data <- subset(data, PID != "PID4050_Chilopoda_Carpenter")
data <- subset(data, PID != "PID4053_Chilopoda_Lange")
data <- subset(data, PID != "PID4056_Diplopoda_Blasi")
data <- subset(data, PID != "PID4059_Diplopoda_Carpenter")
data <- subset(data, PID != "PID4065_Entognatha_Burton")
data <- subset(data, PID != "PID4068_Entognatha_Mumme")
data <- subset(data, PID != "PID4080_Insecta_Giangarelli")
data <- subset(data, PID != "PID3136_Chilopoda_Rousseau")



### Remove studies conducted before 2000
sort(unique(data$Year))


data <- subset(data, ! Year %in% c("1986-1987", "1992", "1993", "1993-1994", "1994", "1995",
                                   "1995-1996", "1996", "1996-1997", "1997", "1998"))



#### Get data in the same format as Ben's BIOFRAG data -------------



data_split <- split(data, data$PID)

print(unique(data$PID))



for(i in 1:length(data_split)){
  
  study <- data_split[[i]]
  
  print(paste0("--------- Wrangling data for ", unique(study$PID), " ------------"))
  
  folder <- paste0("data/processed/BIOFRAG_and_PREDICTS/", unique(study$PID))
  
  if(!file.exists(folder)){
    dir.create(folder)
  }
  
  PID_number <- str_split(unique(study$PID), "_")[[1]][1]
  
  ### Plot 
  plots <- study %>% 
    distinct(SiteID, .keep_all = T) %>%
    dplyr::select(c(SiteID, Longitude, Latitude, PID))
  
  PID_Plot <- data.frame(Sites = plots$SiteID,
                         Latitude = plots$Latitude,
                         Longitude = plots$Longitude,
                         PID = PID_number)
  
  write_csv(PID_Plot, paste0(folder, "/", PID_number, "_Plot.csv"))
  
  ### Species matrix
  PID_species_matrix <- as.data.frame(t(create.matrix(study,  tax.name = "Species",  locality = "SiteID",
                                                      abund = T, abund.col = "Occupancy")))
  
  PID_species_matrix <- PID_species_matrix %>%
    radiant.data::rownames_to_column(var = "plot")
  
  write_csv(PID_species_matrix, paste0(folder, "/", PID_number, "_species_matrix.csv"))
  
  
  #### Remove studies conducted in non-forest ecoregions ---------------------------------
 
  ecoregions <- as.character(unique(study$Ecoregion))
  print(ecoregions)
  
  biomes <- as.character(unique(study$Biome))
  print(biomes)
  
  if(!any(grepl("forest", na.omit(ecoregions), ignore.case = TRUE)) &&
    !any(grepl("wood", na.omit(ecoregions), ignore.case = TRUE)) &&
    !any(grepl("mangrove", na.omit(ecoregions), ignore.case = TRUE)) &&
    !any(grepl("forest", na.omit(biomes), ignore.case = TRUE)) &&
    !any(grepl("wood", na.omit(biomes), ignore.case = TRUE)) &&
    !any(grepl("mangrove", na.omit(biomes), ignore.case = TRUE))){
    
    # delete folder
    unlink(folder, recursive = T, force = T)
    
  }
  
  
}

