#### PREDICTS data  --------------------------------------------------------

# remotes::install_github("timnewbold/predicts-demo",subdir="predictsFunctions")

library(dplyr)
library(fossil)
library(ggplot2)
library(predictsFunctions)
library(readr)
library(sf)
library(stringr)


#### Get data ------------------------------------------------------------------
# Download PREDICTS data from NHM data portal
predicts_added <- readRDS("data/raw/PREDICTS_added_data/PREDICTS_added_data.rds")


#### Pre-processing ------------------------------------------------------------
# https://timnewbold.github.io/PredictsIntroduction.html

# Correct effort-sensitive abundance measures (assumes linear relationship between effort and recorded abundance)
predicts <- predictsFunctions::CorrectSamplingEffort(diversity = predicts_added)

# Combine sites with identical coordinates, belonging to same study and spatial block of sites, sampled on same dates with same method and metric
predicts <- predictsFunctions::MergeSites(diversity = predicts_added,silent = TRUE)

#### Subset for vertebrates and arthropods -------------------------------------------------

data <- subset(predicts, Phylum == 'Arthropoda'  | Phylum == 'Chordata')


#### Remove missing coords -----------------------------------------------------

## remove the missing coordinates
data <- subset(data, !is.na(data$Longitude | data$Latitude))


#### Convert abundance to occurrence -------------------------------------------

# - remove the measurements that are not abundance or occurrence
data <- subset(data, Diversity_metric == 'abundance' | Diversity_metric == 'occurrence' | Diversity_metric == 'effort-corrected abundance')

# - convert abundance to occurrence
data$occ <- ifelse(data$Measurement>0,1,0)

#### Sampling year(s) -----------------------------------------------------------
## summarise the sample date as the end year 

# - extract just the years from the start and end dates
data$Start_Year <- substr(data$Sample_start_earliest, 1, 4)
data$End_Year <- substr(data$Sample_end_latest, 1, 4)

# Combine start year and end year into one column 
data$Year <- ifelse(
  data$Start_Year == data$End_Year,
  data$Start_Year,
  paste(data$Start_Year, data$End_Year, sep = '-')
)


#### Study names ---------------------------------------------------------------

## make the Study column
# re-format the reference column to be consistent with the data from other databases
# so the study name is just first author and year

data$Study <- paste(gsub("^([A-Za-z]+).*", "\\1", data$Reference), 
                    as.integer(gsub("^.*([0-9]{4}).*", "\\1", data$Reference)), 
                    sep = '')

## check the names and correct if needed
unique(data$Study)
data$Study[data$Study == "L2017"] <- "LopezRicaurte2017"
data$Study[data$Study == "Özden et al. 20082008"] <- "Ozden2008"
data$Study[data$Study == "da2019"] <- "daSilva2019"
data$Study[data$Study == "B2014"] <- "Boesing2014"
data$Study[data$Study == "Le2019"] <- "Leso2019"




#### Site ID -------------------------------------------------------------------
## make a unique site ID to use in my database
# this is similar to the site column, but I can't have different studies all calling their first site '1'
# so I need an identifier that I know will reliably uniquely identify each site _in each study_
data$SiteID <- paste(data$Study, data$Site_number, sep = '_')



#### Format ----------------------------------------------

# label database
data$Database <- 'PREDICTS'


# select just columns of interest
colnames(data)
data <- subset(data, select = c("Database", "Study", "SiteID", "Class",
                                "Taxon_name_entered", "occ",
                                "Latitude",  "Longitude", 
                                "Sampling_method", "Year", "Realm", 
                                "Ecoregion", "Biome"))

# rename columns to match with the other data that I'm putting in the database
names(data)[names(data) == 'occ'] <- 'Occupancy'
names(data)[names(data) == 'Sampling_method'] <- 'Method'
names(data)[names(data) == 'Scientific_name'] <- 'Species'
names(data)[names(data) == 'Taxon_name_entered'] <- 'Species'

# re-format the Methods to match with the other data that I'm putting in the database
data$Method <- as.character(data$Method)
unique(data$Method)

data$Method[data$Method == "mist-netting"] <- "Mist_net"
data$Method[data$Method == "point counts"] <- "Point_count"
data$Method[data$Method == "line/belt transects"] <- "Line_transect"
data$Method[data$Method == "systematic searching"] <- "Systematic_searching"
data$Method[data$Method == "visual encounter survey"] <- "Visual_encounter_survey"
data$Method[data$Method == "aerial transect"] <- "Line_transect"
data$Method[data$Method == "various"] <- "Various"


data$Realm <- as.character(data$Realm)
unique(data$Realm)

data$Realm[data$Realm == "Neotropic"] <- "Neotropical"
data$Realm[data$Realm == "Afrotropic"] <- "Afrotropical"



#### Remove studies also found in BIOFRAG database ---------------------------------
data <- subset(data, Study != "Gardner2007")


#### Make PID labels ------------
unique(data$Class)

data <- subset(data, ! Class == "")

data$Class <- as.character(data$Class)

data$Class[data$Class == "Aves"] <- "Birds"
data$Class[data$Class == "Amphibia"] <- "Amphibians"
data$Class[data$Class == "Reptilia"] <- "Reptiles"
data$Class[data$Class == "Mammalia"] <- "Mammals"

data <- data %>% mutate(Author = str_extract(Study, "[A-Za-z]+"))

data$PID <- paste0(data$Class, "_", data$Author)
data_split <- split(data, data$PID)  # Splitting the dataset

for(i in 1:length(data_split)){
  data_split[[i]]$PID <- paste0("PID4", sprintf("%03d", i), "_", data_split[[i]]$PID) 
}
data <- do.call(rbind, data_split)  


### Check again which taxa are included 
unique(data$Class)

data <- subset(data, Class != "Malacostraca")
data <- subset(data, Class != "Maxillopoda")


# no species matrix here
data <- subset(data, PID != "PID4061_Diplopoda_Lange")
data <- subset(data, PID != "PID4066_Entognatha_Lange")


### Remove studies conducted before 2000
sort(unique(data$Year))


data <- subset(data, ! Year %in% c("1993-1999", "1996", "1996-1999", "1997-1999", "1998", "1998-1999", "1999"))



#### Get data in the same format as Ben's BIOFRAG data -------------



data_split <- split(data, data$PID)


for(i in 1:length(data_split)){
  
  study <- data_split[[i]]
  
  print(paste0("--------- Wrangling data for ", unique(study$PID), " ------------"))
  
  folder <- paste0("data/processed/BIOFRAG_and_PREDICTS/", unique(study$PID))
  
  if(!file.exists(folder)){
    dir.create(folder)
  }
  
  PID_number <- str_split(unique(study$PID), "_")[[1]][1]
  
  ### Plot 
  plots <- study %>% 
    distinct(SiteID, .keep_all = T) %>%
    select(c(SiteID, Longitude, Latitude, PID))
  
  PID_Plot <- data.frame(Sites = plots$SiteID,
                         Latitude = plots$Latitude,
                         Longitude = plots$Longitude,
                         PID = PID_number)
  
  write_csv(PID_Plot, paste0(folder, "/", PID_number, "_Plot.csv"))
  
  ### Species matrix
  PID_species_matrix <- as.data.frame(t(create.matrix(study,  tax.name = "Species",  locality = "SiteID",
                                                      abund = T, abund.col = "Occupancy")))
  
  PID_species_matrix <- PID_species_matrix %>%
    radiant.data::rownames_to_column(var = "plot")
  
  write_csv(PID_species_matrix, paste0(folder, "/", PID_number, "_species_matrix.csv"))
  
  
  
  #### Remove studies conducted in non-forest ecoregions ---------------------------------
  
  ecoregions <- as.character(unique(study$Ecoregion))
  print(ecoregions)
  
  biomes <- as.character(unique(study$Biome))
  print(biomes)
  
  if(!any(grepl("forest", na.omit(ecoregions), ignore.case = TRUE)) &&
     !any(grepl("wood", na.omit(ecoregions), ignore.case = TRUE)) &&
     !any(grepl("mangrove", na.omit(ecoregions), ignore.case = TRUE)) &&
     !any(grepl("forest", na.omit(biomes), ignore.case = TRUE)) &&
     !any(grepl("wood", na.omit(biomes), ignore.case = TRUE)) &&
     !any(grepl("mangrove", na.omit(biomes), ignore.case = TRUE))){
    
    # delete folder
    unlink(folder, recursive = T, force = T)
    
  }
  
}
