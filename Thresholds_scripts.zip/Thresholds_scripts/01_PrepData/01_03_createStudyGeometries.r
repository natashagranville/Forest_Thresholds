#### Create study geometries --------------------------------------------
# points and bounding boxes 

library(tidyverse)
library(sf)
library(landscapemetrics)
library(janitor)
library(terra)

## List all  study folders

Studies = list.files("data/processed/BIOFRAG_and_PREDICTS", pattern = "PID*")

## All biofrag folders have the same folders:
## Landscape meta, plots, species matrix, plot meta, and species meta
## Plot meta contains the point for each plot/site
## Landscape meta contains the central points for the study

####################################################
## Load in points for each plot for each study
####################################################

study_Plot_Points = lapply(Studies, function(x) {
    study_Code = str_split(x, pattern = "_")[[1]][1]
    df = read.csv(paste0("data/processed/BIOFRAG_and_PREDICTS/", x, "/", study_Code, "_Plot.csv"))
    if(ncol(df) < 4) {df$PID = study_Code}
    colnames(df) = c("Plot", "Latitude", "Longitude", "PID")
    df = df %>% dplyr:::select(Plot, Latitude, Longitude, PID) %>% mutate(Plot = as.character(Plot), Latitude = as.numeric(Latitude), 
                                                                            Longitude = as.numeric(Longitude), PID = as.character(PID))
    return(df)})

## Remove rows with NAs
study_Plot_Points = lapply(study_Plot_Points, function(x) x[complete.cases(x),])

## Convert to geometry objects

study_Plot_Points_sf = lapply(study_Plot_Points, function(x) {
    df = st_as_sf(x, coords = c("Longitude", "Latitude"), crs = 4326)
    return(df)})

############################################################
## Create shapefiles for the different study sites
############################################################

## Make each study into a simple four sided shape file
## each corner is the maximum longitude and latitude in a direction
## and then an additional 1 degrees is added, which is about 100km
## to ensure that we have all data when buffers are then added to sites

Create_Study_Shapefile = function(study) {

    min_Long = min(study$Longitude) - 1; max_Long = max(study$Longitude) + 1;
    min_Lat = min(study$Latitude) - 1; max_Lat = max(study$Latitude) + 1;

    study_Coords = rbind(c(min_Long, min_Lat), c(max_Long, min_Lat), c(max_Long, max_Lat),
        c(min_Long, max_Lat), c(min_Long, min_Lat))

    study_Shapefile = st_geometry(st_polygon(list(study_Coords)))
    st_crs(study_Shapefile) = 4326
    
    return(study_Shapefile)
}

## Create shapefiles encompassing all plots of every study

study_Shapefiles = lapply(study_Plot_Points, Create_Study_Shapefile)

save(study_Plot_Points, study_Plot_Points_sf, study_Shapefiles, file = "data/processed/study_Geometries.RData")
