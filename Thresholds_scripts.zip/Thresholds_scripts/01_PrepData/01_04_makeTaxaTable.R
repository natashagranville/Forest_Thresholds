#### Make taxa lookup table -------------

library(tidyverse)
library(sf)

study_names <- list.files("data/processed/BIOFRAG_and_PREDICTS")

PIDs <- unlist(lapply(str_split(study_names, "_"), function(x) x[1]))

taxa <- unlist(lapply(str_split(study_names, "_"), function(x) x[2]))

# get author names 
author <- unlist(lapply(str_split(study_names, "_"), function(x) x[3]))
# but note that for BIOFRAG, the author names are on a separate spreadsheet
author[1:91] <- "BIOFRAG"


# Put PID numbers and taxa names into a dataframe
pidTaxa <- data.frame(pid = PIDs, taxa = taxa, author = author)

#### Get taxa names -------------------------------------------------------------
# Format taxa names
sort(unique(pidTaxa$taxa))

pidTaxa$taxa[pidTaxa$taxa == "Amphibia"] <- "Herptiles"
pidTaxa$taxa[pidTaxa$taxa == "Amphibians"] <- "Herptiles"
pidTaxa$taxa[pidTaxa$taxa == "Ants"] <- "Arthropods"
pidTaxa$taxa[pidTaxa$taxa == "Arachnida"] <- "Arthropods"
pidTaxa$taxa[pidTaxa$taxa == "Arachnids"] <- "Arthropods"
pidTaxa$taxa[pidTaxa$taxa == "Bats"] <- "Mammals"
pidTaxa$taxa[pidTaxa$taxa == "BeesWasps"] <- "Arthropods"
pidTaxa$taxa[pidTaxa$taxa == "Beetles"] <- "Arthropods"
pidTaxa$taxa[pidTaxa$taxa == "Blowflies"] <- "Arthropods"
pidTaxa$taxa[pidTaxa$taxa == "Butterflies"] <- "Arthropods"
pidTaxa$taxa[pidTaxa$taxa == "Butterfly"] <- "Arthropods"
pidTaxa$taxa[pidTaxa$taxa == "Arachnida"] <- "Arthropods"
pidTaxa$taxa[pidTaxa$taxa == "Chilopoda"] <- "Arthropods"
pidTaxa$taxa[pidTaxa$taxa == "Diplopoda"] <- "Arthropods"
pidTaxa$taxa[pidTaxa$taxa == "DungBeetles"] <- "Arthropods"
pidTaxa$taxa[pidTaxa$taxa == "Entognatha"] <- "Arthropods"
pidTaxa$taxa[pidTaxa$taxa == "Frogs"] <- "Herptiles"
pidTaxa$taxa[pidTaxa$taxa == "Fruitflies"] <- "Arthropods"
pidTaxa$taxa[pidTaxa$taxa == "Grasshoppers"] <- "Arthropods"
pidTaxa$taxa[pidTaxa$taxa == "Herpetofauna"] <- "Herptiles"
pidTaxa$taxa[pidTaxa$taxa == "Herps"] <- "Herptiles"
pidTaxa$taxa[pidTaxa$taxa == "Insecta"] <- "Arthropods"
pidTaxa$taxa[pidTaxa$taxa == "Insects"] <- "Arthropods"
pidTaxa$taxa[pidTaxa$taxa == "Lizards"] <- "Herptiles"
pidTaxa$taxa[pidTaxa$taxa == "Mammal"] <- "Mammals"
pidTaxa$taxa[pidTaxa$taxa == "Moths"] <- "Arthropods"
pidTaxa$taxa[pidTaxa$taxa == "OrchidBees"] <- "Arthropods"
pidTaxa$taxa[pidTaxa$taxa == "OtherArthropods"] <- "Arthropods"
pidTaxa$taxa[pidTaxa$taxa == "Pauropoda"] <- "Arthropods"
pidTaxa$taxa[pidTaxa$taxa == "Reptile"] <- "Herptiles"
pidTaxa$taxa[pidTaxa$taxa == "Reptiles"] <- "Herptiles"
pidTaxa$taxa[pidTaxa$taxa == "SmallMammals"] <- "Mammals"
pidTaxa$taxa[pidTaxa$taxa == "Spiders"] <- "Arthropods"
pidTaxa$taxa[pidTaxa$taxa == "Symphyla"] <- "Arthropods"



unique(pidTaxa$taxa)



#### Get realm names -----------------------------------------------------------

load("data/processed/study_Geometries.Rdata")

centroids <- lapply(study_Plot_Points_sf, function(x) {
  st_centroid(sfheaders::sf_multipoint(st_coordinates(x)))
})

PIDs <- lapply(study_Plot_Points_sf, function(x) {
  unique(x$PID)
})

centroids_sf <- do.call(rbind, centroids)
PIDs <- do.call(rbind, PIDs)

centroids <- cbind(centroids_sf, PIDs)
colnames(centroids) <- c("id","pid","geometry")

ecoregions <- st_read("data/raw/Ecoregions2017/Ecoregions2017.shp")

ecoregions <- st_transform(ecoregions, 4326)

ecoregions <- dplyr::select(ecoregions, c(ECO_NAME, BIOME_NAME, REALM))

ecoregions <- st_make_valid(ecoregions)

st_crs(centroids) <- 4326

ecoregion_data <- st_join(centroids, ecoregions)

pidTaxa <- left_join(pidTaxa, ecoregion_data[,c("pid", "REALM")], by = "pid")

pidTaxa <- as.data.frame(st_drop_geometry(pidTaxa))

head(pidTaxa)

write_csv(pidTaxa, "data/processed/taxa_PID_Lookup.csv")
