#########################################################
## Calculate distance between sites in studies
#########################################################

library(tidyverse)
library(janitor)
library(sf)
library(units)

## List all biofrag study folders
Studies = list.files("data/processed/BIOFRAG_and_PREDICTS", pattern = "PID*")
study_PIDs = sapply(1:length(Studies), function (x) {str_split(Studies, pattern = "_")[[x]][1]})

load("data/processed/study_Geometries.RData")

## Calculate distances between sites
## To do this we want to project to azimuthal equidistant projection
## which requires a central point to project from
## We will use the centroid of the study area

studyCentroids = lapply(study_Plot_Points_sf, function(x) {
    df = st_centroid(st_union(x))
    return(df)
})

## Transform each study to the azimuthal equidistant projection
## using the centroid of the study as the central point

azimuthal_Proj_Fmt = "+proj=aeqd +lat_0=%0.8f +lon_0=%0.8f +x_0=0 +y_0=0 +ellps=WGS84 +datum=WGS84 +units=m no_defs"

studyPlotPoints = mapply(study_Plot_Points_sf, studyCentroids, FUN = function(x, y) {
    azimuthal_Proj = sprintf(azimuthal_Proj_Fmt, st_coordinates(y)[,'Y'], st_coordinates(y)[,'X'])
    df = st_transform(x, crs = azimuthal_Proj)
    return(df)
}, SIMPLIFY = F)



## Calculate distances between all sites in each study
distances = lapply(studyPlotPoints, function(x) {
    df = st_distance(x)
    df = drop_units(df)
    df = as.data.frame(df)
    return(df)
})

## Add plot_id as a column and column names of the distance data frames
distances = mapply(distances, studyPlotPoints, 
    FUN = function(x, y) x %>% setNames(y$Plot) %>%
    add_column(.before = 1, plot = y$Plot))

## Convert to long format
distances = lapply(distances, function(x) {
    df = pivot_longer(x, cols = -plot, names_to = "plot2", values_to = "distance")
    return(df)
}) 

## Add pid to each data frame in the list
distances = mapply(distances, studyPlotPoints, FUN = function(x, y) {
    df = mutate(.before = 1, x, pid = y$PID[[1]])
    return(df)
}, SIMPLIFY = F)

## Bind rows and remove rows where plot == plot2
distances = distances %>%
    bind_rows() %>%
    filter(plot != plot2)






## Save csv
write_csv(distances, "data/processed/distances.csv")
