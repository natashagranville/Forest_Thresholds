#### Get Tree Cover Maps -------------------------------------
# https://storage.googleapis.com/earthenginepartners-hansen/GFC-2022-v1.10/download.html

library(gfcanalysis)
library(sf)
library(stringr)
library(terra)

raw_Hansen_folder <- "C:/Users/nrg19/OneDrive - Imperial College London/PhD/2nd-Chapter_Microclimate-ThermalLimits/data/raw/Hansen_ForestCover"

load("data/processed/study_Geometries.RData")

raster_Paths = list.files("data/processed/BIOFRAG_and_PREDICTS", pattern = "hansen_image_", recursive = T, full.names = T)

study_names = list.files("data/processed/BIOFRAG_and_PREDICTS")


### Functions for formatting coordinates for tile names
convert_coord <- function(coord, type) {
  if (coord < 0) {
    coord <- abs(coord)
    direction <- ifelse(type == "lon", "W", "S")
  } else {
    direction <- ifelse(type == "lon", "E", "N")
  }
  
  if (type == "lon") {
    formatted_coord <- sprintf("%03d%s", coord, direction)
  } else {
    formatted_coord <- sprintf("%02d%s", coord, direction)
  }
  
  return(formatted_coord)
}

convert_coords <- function(coords) {
  
  lon <- coords[1]
  lat <- coords[2]
  
  lon_converted <- convert_coord(lon, "lon")
  lat_converted <- convert_coord(lat, "lat")
  
  return(c(lon_converted, lat_converted))
}



site = study_Plot_Points_sf[[185]]
raster_File = raster_Paths[[185]]
study_Shapefile = study_Shapefiles[[185]]





getHansenMaps = function(site, raster_File, study_Shapefile) {
  
  tryCatch({
    
  if(!file.exists(raster_File)){
    
    study_PID = site$PID[1]
    
    print(paste0("---------- Getting treecover map for ", study_PID, " ----------"))
    
    study_tiles <- calc_gfc_tiles(study_Shapefile)
    study_tiles
    
    if(nrow(study_tiles) == 1){
      
      ## Get coordinate of top-left corner of tile
      tile_xmin <- st_bbox(study_tiles)[1]
      tile_ymax <- st_bbox(study_tiles)[4]
      coords <- c(tile_xmin, tile_ymax)
      converted_coords <- convert_coords(coords)
      converted_coords
      
      ## Read in the raster files for this tile
      treecover_rast <- rast(paste0(raw_Hansen_folder, "/Hansen_GFC-2022-v1.10_treecover2000_", converted_coords[2], "_", converted_coords[1], ".tif"))
      datamask_rast <- rast(paste0(raw_Hansen_folder, "/Hansen_GFC-2022-v1.10_datamask_", converted_coords[2], "_", converted_coords[1], ".tif"))
      
    }
    
    if(nrow(study_tiles) > 1){ # If the study covers >1 tile, read in each tile separately then stick them together
      
      treecover_rast_list <- list()
      datamask_rast_list <- list()
      
      for(i in 1:nrow(study_tiles)){
        
        # Get coordinate of top-left corner of this tile
        tile_i <- study_tiles[i,]
        tile_i_xmin <- st_bbox(tile_i)[1]
        tile_i_ymax <- st_bbox(tile_i)[4]
        coords_i <- c(tile_i_xmin, tile_i_ymax)
        converted_coords_i <- convert_coords(coords_i)
        converted_coords_i
        
        # Read in the raster files for this tile
        treecover_rast_i <- rast(paste0(raw_Hansen_folder, "/Hansen_GFC-2022-v1.10_treecover2000_", converted_coords_i[2], "_", converted_coords_i[1], ".tif"))
        datamask_rast_i <- rast(paste0(raw_Hansen_folder, "/Hansen_GFC-2022-v1.10_datamask_", converted_coords_i[2], "_", converted_coords_i[1], ".tif"))
        
        # Join this with the list of tiles
        treecover_rast_list <- list(treecover_rast_list, treecover_rast_i)
        datamask_rast_list <- list(datamask_rast_list, datamask_rast_i)
        
      }
      
      if(nrow(study_tiles) == 2 | nrow(study_tiles) == 3){
        
        # Remove null element
        treecover_rast_list[[1]] <- treecover_rast_list[[1]][[2]] 
        datamask_rast_list[[1]] <- datamask_rast_list[[1]][[2]] 
        
        # Merge raster tiles
        treecover_rast <- do.call(merge, treecover_rast_list)
        datamask_rast <- do.call(merge, datamask_rast_list)
        
      }
      
      if(nrow(study_tiles) == 4){
        
        # Remove null element
        treecover_rast_list_new <- list()
        treecover_rast_list_new[[1]] <- treecover_rast_list[[1]][[1]][[1]][[2]]
        treecover_rast_list_new[[2]] <- treecover_rast_list[[1]][[1]][[2]]
        treecover_rast_list_new[[3]] <- treecover_rast_list[[1]][[2]]
        treecover_rast_list_new[[4]] <- treecover_rast_list[[2]]
        
        datamask_rast_list_new <- list()
        datamask_rast_list_new[[1]] <- datamask_rast_list[[1]][[1]][[1]][[2]]
        datamask_rast_list_new[[2]] <- datamask_rast_list[[1]][[1]][[2]]
        datamask_rast_list_new[[3]] <- datamask_rast_list[[1]][[2]]
        datamask_rast_list_new[[4]] <- datamask_rast_list[[2]]
        
        # Merge raster tiles
        treecover_rast <- do.call(merge, treecover_rast_list_new)
        datamask_rast <- do.call(merge, datamask_rast_list_new)
        
      }
     
      
    }
    
    # Crop to buffered bounding box around study area
    study_treecover_rast <- crop(treecover_rast, study_Shapefile)
    study_datamask_rast <- crop(datamask_rast, study_Shapefile)
    
    study_hansen_image <- c(study_treecover_rast, study_datamask_rast)
    
    #plot(study_hansen_image[[1]])
    #plot(st_geometry(study_Shapefile), add = T, col = "red")
    writeRaster(study_hansen_image, raster_File, overwrite = T)
  
    
       }  
    
  }, error = function(e) {
    print(paste("Error:", conditionMessage(e), "\n"))
    
  })
  
}
mapply(getHansenMaps, study_Plot_Points_sf, raster_Paths, study_Shapefiles)

