################################################################
## Calculate Forest Cover for each site at different buffers
## Using 70% Forest cover as binary forest/non-forest cut off

## Ben Howes, 2nd Year PhD, Imperial College London, 2021
################################################################

library(tidyverse)
library(sf)
library(landscapemetrics)
library(janitor)
library(terra)
library(stringr)

## List all biofrag study folders

Studies = list.files("data/processed/BIOFRAG_and_PREDICTS", pattern = "PID*")

## All biofrag folders have the same folders:
## Landscape meta, plots, species matrix, plot meta, and species meta
## Plot meta contains the point for each plot/site
## Landscape meta contains the central points for the study

load("data/processed/study_Geometries.RData")

############################################################
## Calculate forest cover
############################################################

## Load in rasters
raster_Paths = list.files("data/processed/BIOFRAG_and_PREDICTS", pattern = "hansen_image_", recursive = T, full.names = T)

## Used to transform to equal area projection
behr = "+proj=cea +lon_0=0 +lat_ts=30 +x_0=0 +y_0=0 +datum=WGS84 +ellps=WGS84 +units=m +no_defs"

## Calculate Landscape Metrics for each plot in each study



# site = study_Plot_Points_sf[[300]]
# raster_File = raster_Paths[[300]]
# study_Shapefile = study_Shapefiles[[300]]
# cutOff_value = 70

calculate_Frag_Metrics = function(site, raster_File, study_Shapefile, cutOff_value) {
  
  tryCatch({
    
    
    study_PID = site$PID[1]

    buffer_Sizes = c(200,500,1000,2000)
    
    filePaths =  c(paste0(str_split(raster_File, pattern = "hansen_")[[1]][1],
                          "landscape_metrics_", study_PID, "_", buffer_Sizes, "_fp", cutOff_value, ".csv"))
    
    if (sum(!file.exists(filePaths)) != 0) {

        print(paste0("Calculating landscape forest cover for ", study_PID))

        site_Raster = rast(raster_File)[[1]] ## Load raster and select treecover2000 layer

        ## Only keep pixels which have forest cover equal or greater than 70% 
        ## we could change it to see how this cut-off value affects results
        if (length(site_Raster[1]) > 1) {
            tree = site_Raster$treecover2000
        } else {
            tree = site_Raster[[1]]
        }
        
        mask = rast(raster_File)[[2]]

        ## Change no data and water cells to NA in the mask
        mask[mask == 2 | mask == 0] = NA

        ## Update values in tree to be NA if they are in NA of the mask
        tree = tree*mask

        ## Classify cells 70 or above to 1, and 69 or below as 0, leaving sea and water as NA values
        tree[tree < cutOff_value & !is.na(tree)] = 0
        tree[tree >= cutOff_value] = 1

        forest_Raster <- tree

        ## Transform sites and Raster to AEQD projection

        site = st_transform(site, behr)
        forest_Raster = terra::project(forest_Raster, behr, method = "near", threads = TRUE)

        for(i in 1:length(buffer_Sizes)) {
            if(!file.exists(filePaths[[i]]))
              
                print(c(study_PID, buffer_Sizes[[i]]))

                # Calculate landscape metrics

                frag_Metrics = sample_lsm(forest_Raster, site, plot_id = site$Plot, shape = "circle", size = buffer_Sizes[[i]], all_classes = T, what = "lsm_c_pland")

                ## Remove NA classes, then turn NAs in value column to 0

                frag_Metrics = frag_Metrics[!is.na(frag_Metrics$class), ]
                frag_Metrics[is.na(frag_Metrics$value), ]$value = 0

                # Label buffer sizes
                frag_Metrics$buffer <- buffer_Sizes[[i]]
                
                write.csv(frag_Metrics, file = paste0(str_split(raster_File, pattern = "hansen_")[[1]][1],
                                                    "landscape_metrics_", study_PID, "_", buffer_Sizes[[i]], "_fp", cutOff_value, ".csv"), row.names = FALSE)

            }
    }
    
  }, error = function(e) {
    print(paste("Error:", conditionMessage(e), "\n"))
    
  })
  
}


mapply(calculate_Frag_Metrics, study_Plot_Points_sf, raster_Paths, study_Shapefiles, cutOff_value = 70)


cutOff_value <- 70
## Load in plot landscape metrics
  
lsm_Paths = mixedsort(list.files("data/processed/BIOFRAG_and_PREDICTS", 
                                         pattern = paste0("fp", cutOff_value), 
                                         recursive = T, full.names = T))
  

plot_Landscape_Metrics = lapply(lsm_Paths, function(x) {read.csv(x) %>% 
    dplyr:::select(class, metric, value, plot_id, percentage_inside) %>% 
      add_column(PID = str_split(str_split(x[[1]], pattern = "/")[[1]][[5]], pattern = "_")[[1]][3],
                   buffer = gsub(".csv", "", str_split(str_split(x[[1]], pattern = "/")[[1]][[5]], pattern = "_")[[1]][4]))})

plot_Landscape_Metrics <- plot_Landscape_Metrics[sapply(plot_Landscape_Metrics, function(x) nrow(x) > 0)]

pland_Metrics = plot_Landscape_Metrics %>%
  purrr:::map(mutate, plot_id = as.character(plot_id)) %>% 
  bind_rows() %>% 
  filter(metric == "pland")


## IMPORTANT - add study labels to site names
BIOFRAG <- pland_Metrics[as.numeric(sapply(str_split(pland_Metrics$PID, "D"), "[[", 2)) < 3000 ,]
PREDICTS <- pland_Metrics[as.numeric(sapply(str_split(pland_Metrics$PID, "D"), "[[", 2)) >= 3000 ,]

BIOFRAG$plot_id <- paste0(BIOFRAG$PID, "_", BIOFRAG$plot_id)
PREDICTS$plot_id <- paste0(PREDICTS$PID, "_", PREDICTS$plot_id)

pland_Metrics <- rbind(BIOFRAG, PREDICTS)

write.csv(pland_Metrics, paste0("data/processed/percentage_Forest_Cover", cutOff_value, ".csv"), row.names = F)
