################################################################
## Calculate Forest Cover for the entire region of each study
## Using 70% Forest cover as binary forest/non-forest cut off
################################################################

library(dplyr)
library(sf)
library(terra)
library(stringr)
library(tibble)


load("data/processed/study_Geometries.RData")

study_names <- list.files("data/processed/BIOFRAG_and_PREDICTS")

raster_Paths <- list.files("data/processed/BIOFRAG_and_PREDICTS", recursive = T, full = T, pattern = "hansen_image")

## Load in landscape rasters for each study
regional_Rasters <- lapply(raster_Paths, rast)


calc_forest_cover = function(hull, x, z) {
  
  print(str_split(z, pattern = "_")[[1]][1])
  
  hull = vect(hull)
  
  ## Cut landscape to minimal convex hull
  x = x %>% mask(hull) %>% crop(hull)
  
  #plot(x[[1]])
  #plot(x[[2]])
  
  ## Load in separate bands
  #tree = x$treecover2000
  #mask = x$datamask
  
  tree = x[[1]]
  mask = x[[2]]
  
  
  ## Change no data and water cells to NA in the mask
  mask[mask == 2 | mask == 0] = NA
  
  ## Update values in tree to be NA if they are in NA of the mask
  tree = tree*mask
  
  ## Classify cells 70 or above to 1, and 69 or below as 0
  tree[tree < 70 & !is.na(tree)] = 0
  tree[tree >= 70] = 1
  
  #plot(tree)
  
  ## Calculate % forest cover, not including NA values (permanent water)
  forest_Cover = as.data.frame(tree, xy = T) %>% 
    {colnames(.) <- c("x", "y", "treecover2000"); .} %>%
    filter(!is.na(treecover2000)) %>% 
    summarise(cover = nrow(filter(., treecover2000 == 1))/nrow(.))
  
  out = forest_Cover %>% add_column(PID = str_split(z, pattern = "_")[[1]][1])
  
  return(out)
  
}




for(i in 1:length(study_names)){
  
  tryCatch({
    
    ## Calculate landscape forest cover
    
    z <- study_names[[i]]
    hull <- study_Shapefiles[[i]]
    x <- regional_Rasters[[i]]
    
    
    file_path <- paste0("data/processed/PREDICTS_regional_Forest_Cover/", z, ".csv")
    
    if(!file.exists(file_path)){
      
      regional_Forest_Cover = calc_forest_cover(hull, x, z)
      
      write.csv(regional_Forest_Cover, file_path)
      
    }
    
    rm(list = setdiff(ls(), c("study_names", "study_Shapefiles", "regional_Rasters", "calc_forest_cover")))
    
  }, error = function(e) {
    print(paste("Error:", conditionMessage(e), "\n"))
    
  })
  
}


BIOFRAG_regional_forest_cover <- read.csv("data/processed/BIOFRAG_regional_Forest_Cover.csv")

setwd("data/processed/PREDICTS_regional_Forest_Cover/")
data <- data.frame()
data_study <- data.frame()
for (file in list.files(pattern = ".csv")){
  data_study <- read_csv(file)
  data <- rbind(data, data_study)
}

setwd("C:/Users/nrg19/OneDrive - Imperial College London/PhD/Thresholds_Ben")

PREDICTS_regional_forest_cover <- data[,2:3]

regional_forest_cover <- rbind(BIOFRAG_regional_forest_cover, PREDICTS_regional_forest_cover )

write.csv(regional_forest_cover, "data/processed/regional_Forest_Cover.csv")
