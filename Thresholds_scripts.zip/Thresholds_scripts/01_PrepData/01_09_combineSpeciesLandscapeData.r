################################################################
## Extract species matrix 
## and combine with landscape metrics (forest cover %)
################################################################

library(tidyverse)
library(sf)
library(landscapemetrics)
library(janitor)
library(gtools)
library(units)
library(readr)



cutOff_value <- 70
#cutOff_value <- 50
#cutOff_value <- 80



## List all study folders

Studies = list.files("data/processed/BIOFRAG_and_PREDICTS", pattern = "PID*")

#########################
## Load in Species Data
#########################

## Make a list of all study PIDs and just keep percentage cover of matrix (0) and forest (1) for now from landscape metrics

study_PIDs = sapply(1:length(Studies), function (x) {str_split(Studies, pattern = "_")[[x]][1]})

## Load in Species Matrix

species_Matrix = mapply(function(x,y) {
read_csv(paste0("data/processed/BIOFRAG_and_PREDICTS/", x, "/", y, "_species_matrix.csv"), show_col_types = F) %>% clean_names()
}, Studies, study_PIDs)

## Replace NaNs and NAs with 0

for (i in 1:length(species_Matrix)) {
    species_Matrix[[i]][is.na(species_Matrix[[i]])] = 0
}



## Pivot data to long format

species_Matrix = species_Matrix %>% purrr:::map(~ pivot_longer(data = .x, !plot, names_to = "Species", values_to = "Occurrence")) %>%
                        purrr:::map(mutate, plot = as.character(plot))

## Add PID to each list object
species_Matrix = mapply(function(x, y) add_column(x, PID = as.character(y)), species_Matrix, study_PIDs, SIMPLIFY = F)


## Bind together and add column for occurrence, which is just 0 or 1
species_Matrix = species_Matrix %>% bind_rows() %>% mutate(Occurrence = ifelse(Occurrence > 0, 1, 0)) %>% relocate(PID, plot, Species, Occurrence)


BIOFRAG <- species_Matrix[as.numeric(sapply(str_split(species_Matrix$PID, "D"), "[[", 2)) < 3000 ,]
PREDICTS <- species_Matrix[as.numeric(sapply(str_split(species_Matrix$PID, "D"), "[[", 2)) >= 3000 ,]

BIOFRAG$plot_id <- paste0(BIOFRAG$PID, "_", BIOFRAG$plot)
PREDICTS$plot_id <- paste0(PREDICTS$PID, "_", PREDICTS$plot)

species_Matrix <- rbind(BIOFRAG, PREDICTS)



## Load in forest cover data

pland_Metrics = read_csv(paste0("data/processed/percentage_Forest_Cover", cutOff_value, ".csv"))


## Add forest cover for each plot to species matrix
## Remove unwanted columns (e.g percentage_inside)
## Filter to only keep forest cover, remove class 0 which is matrix

species_Occurrence = left_join(species_Matrix, pland_Metrics, by = c("plot_id", "PID"), relationship = "many-to-many") %>% 
                              filter(class == 1) %>% 
                              dplyr:::select(-class, -metric, -percentage_inside) %>%
                              relocate(PID, plot_id, buffer, Species, value, Occurrence) %>% 
                              rename("Forest_Cover" = "value",  "Buffer" = "buffer") 
  
colnames(species_Occurrence)



species_Occurrence <- species_Occurrence %>%
  dplyr::select(PID, plot_id, Buffer, Species, Forest_Cover, Occurrence)


write.csv(species_Occurrence, file = paste0("data/processed/speciesOccurrence", cutOff_value, ".csv"), row.names = F)


