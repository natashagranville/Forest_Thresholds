####################################
## Get data quality measures for the studies
####################################

library(tidyverse)
library(janitor)


## Load in forest data
cutOff_value <- 70
pland = read_csv(paste0("data/processed/percentage_Forest_Cover", cutOff_value, ".csv")) %>% 
    clean_names() %>% 
    filter(class == 1) %>%
    mutate(fCov = value/100) %>%
    dplyr::select(fCov, plot_id, pid, buffer)

## Get local forest cover (50m) for each plot and join
localForestCover = pland %>%
    filter(buffer == 50) %>%
    rename(local_forest_cover = fCov) %>%
    dplyr::select(plot_id, pid, local_forest_cover)

pland = pland %>%
    left_join(localForestCover, join_by(plot_id, pid)) %>%
    filter(buffer != 50)

## Identify control sites as those within 5% forest cover of the
## highest forest cover site in the study
## and those that have a local forest cover > 75%

controlSites = pland %>% 
    filter(local_forest_cover >= 0.75) %>%
    group_by(pid, buffer) %>%
    filter(fCov > max(fCov) - 0.05)

## Get number of sites per study
nSites = pland %>% 
    group_by(pid, buffer) %>%
    summarise(nSites = n_distinct(plot_id))

## Get number of control sites per study
nControls = controlSites %>%
    group_by(pid, buffer) %>%
    summarise(nControls = n_distinct(plot_id))

## Highest forest cover in the study (that of the highest control site)
controlForest = controlSites %>%
    group_by(pid, buffer) %>%
    summarise(controlForest = max(fCov))

## Get range of forest cover per study
forestRange = pland %>%
    group_by(pid, buffer) %>%
    summarise(forestRange = max(fCov) - min(fCov))

## Join everything together
dataQuality = left_join(nSites, nControls) %>%
    left_join(controlForest) %>%
    left_join(forestRange)

## ** FILTER FOR FOREST RANGE **
## Remove studies with less than 0.3 (30%) forest range
## as the threshold is limited to relatively small set of values
dataQuality = dataQuality %>% filter(forestRange >= 0.3)


## Change NA for ncontrol and controlForest to 0, since these are studies
## without any control sites
dataQuality = mutate(dataQuality, nControls = ifelse(is.na(nControls), 0, nControls),
    controlForest = ifelse(is.na(controlForest), 0, controlForest))



## Save output
write_csv(dataQuality, "data/processed/dataQuality_fp70.csv")

