#### Calculate community similarity between control and deforested sites -------

library(tidyverse)
library(janitor)
library(vegan)
library(stringr)


cutOff_value <- 70
#cutOff_value <- 50
#cutOff_value <- 80


## Load in species occurrence data
specOcc = read_csv(paste0("data/processed/speciesOccurrence", cutOff_value, ".csv")) %>%
    clean_names() %>%
    mutate(forest_cover = forest_cover/100)

dataQuality = read_csv(paste0("data/processed/dataQuality_fp", cutOff_value, ".csv"))


# filter >30% variation in forest cover
specOcc = subset(specOcc, pid %in% dataQuality$pid)


pidTaxa = read_csv("data/processed/taxa_PID_Lookup.csv") %>%
  dplyr::select(c(pid, taxa, REALM))


## Load forest cover data
pland = read_csv(paste0("data/processed/percentage_Forest_Cover", cutOff_value, ".csv"), locale = locale(encoding = "windows-1252")) %>% 
  clean_names() %>% 
  filter(class == 1) %>%
  mutate(fCov = value/100) %>%
  dplyr::select(fCov, plot_id, pid, buffer)

# filter >30% variation in forest cover
pland = subset(pland, pid %in% dataQuality$pid)

localForestCover = pland %>%
    filter(buffer == 50) %>%
    rename(local_forest_cover = fCov) %>%
    dplyr::select(plot_id, pid, local_forest_cover)

pland = pland %>%
    left_join(localForestCover, join_by(plot_id, pid)) %>%
    filter(buffer != 50)

## Identify control sites as those within 5% forest cover of the
## highest forest cover site in the study
## and those that have a local forest cover == 75%
controlSites = pland %>% 
    filter(local_forest_cover >= 0.75)  %>%
     group_by(pid, buffer) %>%
     filter(fCov > max(fCov) - 0.05)

controlSites <- controlSites[!duplicated(controlSites), ]


## Remove duplicates
duplicates = c("PID0112", "PID0100", "PID0101", "PID0102", "PID0103", 
                "PID0104", "PID0105", "PID0106", "PID0107", "PID0108", "PID0109", 
                "PID0110", "PID0111", "PID0138", "PID1001", "PID0115", "PID0117")

controlSites = controlSites %>%
    filter(!pid %in% duplicates)

specOcc = specOcc %>%
  filter(!pid %in% duplicates)

## Add taxa info
specOcc = specOcc %>% 
    left_join(pidTaxa, by = "pid") %>% 
    filter(!pid %in% duplicates)


## Save as formattedSpecOcc
write_csv(specOcc, paste0("data/processed/formattedSpecOcc_fp", cutOff_value, ".csv"))


############################
## Calculating Similarity
############################


## Remove all plots that do not contain any species (occurrence == 0)
## as you can't compare community composition of plots without any community
sumOcc = specOcc %>%
        group_by(pid, plot_id) %>%
        summarise(sumOcc = sum(occurrence))

specOcc = specOcc %>%
        left_join(sumOcc, join_by(pid, plot_id)) %>%
        filter(sumOcc > 0) %>%
        dplyr::select(-sumOcc)

## Convert to wide format for use in similarity calculations
specWide_list <-  specOcc %>%
      dplyr::select(pid, plot_id, buffer, species, taxa, occurrence) %>%
      group_by(pid, plot_id, buffer, species) %>%
      summarise(occurrence = sum(occurrence, na.rm = TRUE), .groups = "drop") %>%  
      group_split(pid, buffer) 



pivot <- function(data){
  pivoted_i <- pivot_wider(data, names_from = species, values_from = occurrence) %>%
    distinct(plot_id, .keep_all = TRUE) %>%  # Ensure unique 'plot'
    column_to_rownames("plot_id")
  return(pivoted_i)
}

specWide <- lapply(specWide_list, pivot)
     
## Calculate sorensen similarity between control sites
## We do this using vegdist, and do 1 - dist so convert from dissimilarity to similarity
sim = specWide %>%
        map(~list(pid = .$pid[[1]], buffer = .$buffer[[1]], 
        sor = 1 - vegdist(.[, 3:ncol(.)], method = "bray", binary = TRUE),
        jac = 1 - vegdist(.[, 3:ncol(.)], method = "jaccard", binary = TRUE)))


## Convert to long format for plotting and analysis
simLongSor = sim %>%
        map(~pivot_longer(cols = -plot, as.data.frame(as.matrix(.$sor)) %>% 
                            rownames_to_column("plot")) %>%
        rename(control = name, sor = value) %>% 
        filter(plot != control))

simLongJac = sim %>%
  map(~pivot_longer(cols = -plot, as.data.frame(as.matrix(.$jac)) %>% 
                      rownames_to_column("plot")) %>%
        rename(control = name, jac = value) %>% 
        filter(plot != control))

## Add pid and buffer to each data frame
simLongSor = simLongSor %>%
        map2(sim, ~mutate(.before = 1, .x, pid = .y$pid, buffer = .y$buffer)) %>%
        bind_rows()

simLongJac = simLongJac %>%
  map2(sim, ~mutate(.before = 1, .x, pid = .y$pid, buffer = .y$buffer)) %>%
  bind_rows()


names(simLongSor)[names(simLongSor) == 'plot'] <- 'plot_id'
names(simLongJac)[names(simLongJac) == 'plot'] <- 'plot_id'

## Keep only control sites in the control column of the data frame
## Do this by joining control sites to ensure it's the correct pid site combo
simLongSor = left_join(simLongSor, controlSites, join_by(pid, buffer, control == plot_id)) %>%
      filter(!is.na(fCov)) %>%
      dplyr::select(pid, buffer, plot_id, control, sor)

simLongJac = left_join(simLongJac, controlSites, join_by(pid, buffer, control == plot_id)) %>%
  filter(!is.na(fCov)) %>%
  dplyr::select(pid, buffer, plot_id, control, jac)

    
## ** Removing comparisons between control sites and other control sites **
    
simLong_filtered <- subset(simLongSor, ! plot_id  %in% unique(simLongSor$control))

simLong_filtered_Jac <- subset(simLongJac, ! plot_id  %in% unique(simLongJac$control))

write_csv(simLong_filtered, paste0("data/processed/rawSimilarity_fp", cutOff_value, ".csv"))

write_csv(simLong_filtered_Jac, "data/processed/Jaccard_rawSimilarity_fp70.csv")

