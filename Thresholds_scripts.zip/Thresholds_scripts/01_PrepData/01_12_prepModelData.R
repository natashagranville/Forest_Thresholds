#### Prepare data for segmented model analysis ---------------------------------

library(readr)
library(tidyverse)
library(janitor)


## Load in similarity data

cutOff_value <- 70
#cutOff_value <- 50
#cutOff_value <- 80

sim = read_csv(paste0("data/processed/rawSimilarity_fp", cutOff_value, ".csv"))

## Load in distance data
distances = read_csv("data/processed/distances.csv")


# ensure that site (plot) names include study (PID) names
BIOFRAG <- distances[as.numeric(sapply(str_split(distances$pid, "D"), "[[", 2)) < 3000 ,]
PREDICTS <- distances[as.numeric(sapply(str_split(distances$pid, "D"), "[[", 2)) >= 3000 ,]

BIOFRAG$plot <- paste0(BIOFRAG$pid, "_", BIOFRAG$plot)
BIOFRAG$plot2 <- paste0(BIOFRAG$pid, "_", BIOFRAG$plot2)

PREDICTS$plot <- paste0(PREDICTS$pid, "_", PREDICTS$plot)
PREDICTS$plot2 <- paste0(PREDICTS$pid, "_", PREDICTS$plot2)

distances <- rbind(BIOFRAG, PREDICTS)


## Convert distance to km from m (distance/1000)
distances = distances %>% mutate(distance_km = distance/1000)

## Join distance and similarity data
## Left join with sim first so we only keep pristine sites in plot2
dat = left_join(sim, distances, join_by(pid == pid, plot_id == plot, control == plot2))
#Jac_dat = left_join(jac, distances, join_by(pid == pid, plot_id == plot, control == plot2))


## Arcsin sqrt transform similarity metrics so they are not bound between 0 - 1
## so linear models are appropriate
dat = dat %>%
  mutate(sor = asin(sqrt(sor)))

# Jac_dat = Jac_dat %>%
#   mutate(jac = asin(sqrt(jac)))

## Load in forest cover data
## choose only forest (class == 1)
## and clean and rename columns
forest = read_csv(paste0("data/processed/percentage_Forest_Cover", cutOff_value, ".csv"), locale = readr::locale(encoding = "latin1")) %>%
  filter(class == 1) %>%
  clean_names() %>%
  dplyr::select(pid, buffer, plot_id, value) %>%
  rename(forest_cover = value)


## Change forest cover to be between 0 - 1
forest = forest %>% mutate(forest_cover = forest_cover/100)

## Add local forest cover at 50m buffer as another column
localForest = forest %>%
  filter(buffer == 50) %>%
  rename(local_forest_cover = forest_cover) %>%
  dplyr::select(-buffer)

## Join local forest to forest data frame
forest = left_join(forest, localForest, join_by(pid == pid, plot_id == plot_id))

## Join with dat based on plot (not control site)
dat = left_join(dat, forest, join_by(pid == pid, plot_id == plot_id, buffer == buffer))

Jac_dat = left_join(Jac_dat, forest, join_by(pid == pid, plot_id == plot_id, buffer == buffer))

## Save as data used for analysis
write_csv(dat, paste0("data/processed/simDat_fp", cutOff_value, ".csv"))
