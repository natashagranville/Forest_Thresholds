#### Run segmented models -------------

## Model similarity as a function of forest cover and distance
## Using linear models, as well as segmented linear models
## Running models at the optimal scale of effect as found in the previous step

library(tidyverse)
library(segmented)

cutOff_value <- 70

dat <- read.csv(paste0("data/processed/bestScaleSimDat_fp", cutOff_value, ".csv"))

split_by_pid <- group_split(dat, pid)

for(i in 1:length(split_by_pid)){
  
  tryCatch({
    
    pid_data <- split_by_pid[[i]]
    
    pid <- unique(pid_data$pid)
    
    
    print(paste0("------- Running model at optimal scale for ", pid, " -------"))
    
    ## If 2+ control sites, use control site as a random intercept, and threshold
    
    if(length(unique(pid_data$control)) == 1) {
      
      ## If there is only one control site, use no random effects
      lin <- lm(sor ~ forest_cover + distance_km, data = pid_data)
      
    } else {    
      
      ## If >1 control sites, use control site as a random intercept
      lin <- lme(sor ~ forest_cover + distance_km, random = list(control = pdDiag(~1)), data = pid_data)
    }
    
    ## Create new models with forest cover removed for null slope tests
    nullLin <- update(lin, . ~ . -forest_cover)
    
    ## Create negative forest cover to use in null right slope models
    negative_forest_cover <- -pid_data$forest_cover
    
    ## Run right null slope only 
    ## Varying if there is random effects based on number of control sites (==1 or >1)
  
    if(length(unique(pid_data$control)) == 1) {
      
      ## If there is only one control site, use no random effects
      rseg = tryCatch(segmented(nullLin, seg.Z = ~negative_forest_cover, data = pid_data),
                      warning = function(w) {NA}, error = function(e) {NA})
      
    } else {
      
      ## If >1 control sites, use control site as a random effect
      rseg = tryCatch(segmented.lme(nullLin, seg.Z = ~negative_forest_cover, random = list(control = pdDiag(~1+G0)), data = pid_data),
                      warning = function(w) {NA}, error = function(e) {NA}) 
    }
    
    ## Build list for output
    out <- list(pid = pid, lin = lin, rseg = rseg)
    
    
    save(out, file = paste0("results/SorModels_fp", cutOff_value, "/", unique(pid_data$pid),".Rdata"))
    
    
    rm(list = setdiff(ls(), c("split_by_pid", "cutOff_value")))
    
  }
  , error = function(e) {
    print(paste("Error:", conditionMessage(e), "\n"))
    
  })
  
}

