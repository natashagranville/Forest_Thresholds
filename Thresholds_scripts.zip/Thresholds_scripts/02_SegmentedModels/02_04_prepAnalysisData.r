##########################################################################
## Make analysis dataframe and supplementary table
##########################################################################

#### Prep analysis data ---------------------------------------------

library(tidyverse)
library(janitor)
library(sf)
library(kableExtra)
library(viridis)
library(units)

cutOff_value <- 70
#cutOff_value <- 50
#cutOff_value <- 80



## Load in dataquality which has most of the required data
dataQuality = read_csv(paste0("data/processed/dataQuality_fp", cutOff_value, ".csv"))

# data that we tried running segmented models for
simDat <- read.csv(paste0("data/processed/simDat_fp", cutOff_value, ".csv"))
length(unique(simDat$pid))
dataQuality <- subset(dataQuality, pid %in% unique(simDat$pid))

## Load in scale of effect data
bestScale = read_csv(paste0("data/processed/bestScaleSimDat_fp", cutOff_value, ".csv")) %>%
  distinct(pid, buffer)

## Filter dataquality by the scale of effect
dataQuality = inner_join(dataQuality, bestScale)

## Load in explanatory variable data
regionalForest = read.csv(paste0("data/processed/regional_Forest_Cover_fp", cutOff_value, ".csv")) %>%
  clean_names()

load("data/processed/study_Geometries.RData")
avgLat = study_Plot_Points_sf %>% map2(.,., ~st_coordinates(.x) %>% as.data.frame() %>% add_column(PID = .y$PID)) %>% 
  bind_rows() %>% group_by(PID) %>% summarise(avg_Lat = abs(mean(Y))) %>%
  clean_names()

## Join up with data quality
dataQuality = left_join(dataQuality, avgLat, by = "pid")
dataQuality = left_join(dataQuality, regionalForest[,c("cover", "pid")], by = "pid")


## Load in taxa data and join with data quality
taxa = read_csv("data/processed/taxa_PID_Lookup.csv") %>%
  clean_names() %>%
  mutate(taxa = ifelse(taxa == "Bats", "Mammals", taxa))

dataQuality = left_join(dataQuality, taxa[,c("pid", "taxa")], by = "pid")

## Load in thresholds of sites with 
## significant differences in slopes
## and give threshold type and position
sorThresh = read_csv(paste0("results/sorThresholds_fp", cutOff_value, ".csv")) %>%
  clean_names()

## Join with data quality
data = left_join(dataQuality, sorThresh)




## Geographic area covered by the study
load("data/processed/study_Geometries.Rdata")


get_area <- function(study_data){
  hull <- st_convex_hull(st_union(study_data))
  study_data$area <- set_units(st_area(hull), km^2)
  return(study_data)
}

get_area_data <- lapply(study_Plot_Points_sf, get_area) %>%
  bind_rows() %>%
  st_drop_geometry() %>%
  group_by(PID) %>%
  summarise(area = unique(area)) %>%
  rename(pid = PID) %>%
  subset(pid %in% data$pid)


data <- left_join(data, get_area_data, by = "pid")

data <- subset(data,  g0 <= 1 | is.na(g0))

data <- subset(data, !is.na(data$cover))

data <- data[!duplicated(data$pid),]

## Change order of columns
finalTable = data %>%
  relocate(pid, taxa, g0, type, nSites, nControls, controlForest, forestRange, avg_lat, cover)



finalTable %>% group_by(type) %>% summarise(n())



## Regional deforestation 
finalTable$deforest <- 1 - finalTable$cover



## Binary term indicating presence/absence of relevant threshold
finalTable$relevant_threshold_YN <- ifelse(finalTable$type == "declining_integrity_below_thresh", 1, 0)

finalTable %>% group_by(relevant_threshold_YN) %>% summarise(n())


### Key info

# how many studies in total?
length(unique(finalTable$pid))

# how many studies with relevant thresholds?
finalTable_thresh <- subset(finalTable, relevant_threshold_YN == 1)
length(unique(finalTable_thresh$pid))

# how many studies in total for each taxa?
finalTable %>% group_by(taxa) %>% summarise(length(unique(pid)))

# how many studies with thresholds for each taxa?
finalTable_thresh %>% group_by(taxa) %>% summarise(length(unique(pid)))

# of the non-threshold studies, how many were non sig reg, how many were linear?
finalTable %>% group_by(type) %>% summarise(n())

# threshold positions
min(finalTable_thresh$g0, na.rm = T)
max(finalTable_thresh$g0, na.rm = T)
mean(finalTable_thresh$g0, na.rm = T)
median(finalTable_thresh$g0, na.rm = T)


##### Make supplementary table -----------------

### Get biome info
centroids <- lapply(study_Plot_Points_sf, function(x) {
  st_centroid(sfheaders::sf_multipoint(st_coordinates(x)))
})

PIDs <- lapply(study_Plot_Points_sf, function(x) {
  unique(x$PID)
})

centroids_sf <- do.call(rbind, centroids)
PIDs <- do.call(rbind, PIDs)

centroids <- cbind(centroids_sf, PIDs)
colnames(centroids) <- c("id","pid","geometry")


ecoregions <- st_read("data/raw/Ecoregions2017/Ecoregions2017.shp")

ecoregions <- st_transform(ecoregions, 4326)

ecoregions <- dplyr::select(ecoregions, c(ECO_NAME, BIOME_NAME, REALM))

ecoregions <- st_make_valid(ecoregions)

st_crs(centroids) <- 4326

ecoregion_data <- st_join(centroids, ecoregions)

finalTable <- left_join(finalTable, ecoregion_data[,c("pid", "REALM", "BIOME_NAME")], by = "pid")

finalTable<- finalTable %>% dplyr::select(-geometry)


### save data for analysis
write.csv(finalTable, paste0("results/FinalData_fp", cutOff_value, ".csv"))






##### Format supp table -------------------------------------------------------
## Include total number of species within the study

data_for_nSpecies <- read.csv(paste0("data/processed/formattedSpecOcc_fp", cutOff_value, ".csv"))


nSpecies_per_study <- data_for_nSpecies %>%
  group_by(pid) %>%
  summarise(nSpecies = length(unique(species)))


finalTable <- left_join(finalTable, nSpecies_per_study, by = "pid")

suppTable <- finalTable %>%
  dplyr::select(c(pid, taxa, REALM, buffer, relevant_threshold_YN, type, nSites, nControls, nSpecies, g0, low_g0, high_g0))

#suppTable <- subset(suppTable, type == "declining_integrity_below_thresh")

suppTable$g0 <- round(suppTable$g0, 2) * 100
suppTable$low_g0 <- round(suppTable$low_g0, 2) * 100
suppTable$high_g0 <- round(suppTable$high_g0, 2) * 100

suppTable$g0_col <- paste0(suppTable$g0, "% (", suppTable$high_g0, ", ", suppTable$low_g0, ")")

suppTable$relevant_threshold_YN[suppTable$relevant_threshold_YN == 1]  <- "Yes"
suppTable$relevant_threshold_YN[suppTable$relevant_threshold_YN == 0]  <- "No"

suppTable$nonThresh_reason <- ifelse(suppTable$type == "increasing_integrity_below_thresh", 
                                     "Non-conservation-relevant threshold (increase in compositional intactness below threshold)",
                                      ifelse(suppTable$type == "nonSig_rseg",
                                            "Non-significant threshold (95% CIs of both piecewise regression slopes overlapped)",
                                        ifelse(suppTable$type == "lin",
                                            "Linear model fitted better than piecewise model",
                                            "Threshold identified")))

# put NA in the threshold position column if there was no threshold
suppTable$g0_col <- ifelse(suppTable$relevant_threshold_YN == "Yes", 
                           suppTable$g0_col,
                           NA)


# Label the reasons for threshold non-detection 
order <- c("Threshold identified", 
         "Non-conservation-relevant threshold (increase in compositional intactness below threshold)",
         "Non-significant threshold (95% CIs of both piecewise regression slopes overlapped)",
         "Linear model fitted better than piecewise model")


# Order the dataframe to put the threshold studies first
suppTable <- suppTable[order(factor(suppTable$nonThresh_reason, levels = order)),]


suppTable$nonThresh_reason[suppTable$nonThresh_reason == "Threshold identified"]  <- NA


suppTable <- suppTable %>%
  dplyr::select(-c(g0, low_g0, high_g0, type))


colnames(suppTable) <- c("Study ID", "Taxonomic group",  "Biogeographic realm", "Optimal landscape scale (m) ", "Threshold identified?",
                         "Total number of sites", "Number of highly forested reference sites", "Total number of species",
                         "Threshold position (95% CIs)", "Reason for threshold non-detection")


write.csv(suppTable, "results/summary_table.csv")


