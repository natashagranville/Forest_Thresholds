#### Analyse threshold presence -----------------------

library(emmeans)
library(tidyverse)
library(glmmTMB)
library(sjPlot)

data <- read.csv("results/FinalData_fp70.csv")



data$REALM[data$REALM == "Oceania"] <- "Australasia"


## How many of each type?
data %>% group_by(type) %>% summarise(n())


data$relevant_threshold_YN <- as.factor(data$relevant_threshold_YN)


data %>% group_by(relevant_threshold_YN) %>% summarise(n())

data %>% group_by(taxa) %>% summarise(n())



performance::check_collinearity(full_model)

## Taxa
taxa_model <- glmmTMB(relevant_threshold_YN ~ taxa, data = data, family = "binomial")
summary(taxa_model)
AIC(taxa_model)
performance::r2(taxa_model)


taxa_model_emmeans <- emmeans(taxa_model, specs = ~ taxa)
taxa_summary <- summary(taxa_model_emmeans, type = "response")
taxa_summary

taxa_df <- as.data.frame(taxa_summary)

taxa_df <- taxa_df %>%
  dplyr::select(taxa, prob, asymp.LCL, asymp.UCL) %>%
  rename(`Taxonomic group` = taxa,
         `Probability of identifying a threshold` = prob,
         `Lower 95% confidence interval` = asymp.LCL,
         `Upper 95% confidence interval`  = asymp.UCL)%>%
  mutate_if(is.numeric, round, 2)
taxa_df


write.csv(taxa_df, "results/taxa_thresh_prob.csv")

## Biogeographic realm
realm_model <- glmmTMB(relevant_threshold_YN ~ REALM, data = data, family = "binomial")
summary(realm_model)
AIC(realm_model)
performance::r2(realm_model)


realm_model_emmeans <- emmeans(realm_model, specs = ~ REALM)
realm_summary <- summary(realm_model_emmeans, type = "response")
realm_summary


realm_df <- as.data.frame(realm_summary)

realm_df <- realm_df %>%
  dplyr::select(REALM, prob, asymp.LCL, asymp.UCL) %>%
  rename(`Biogeographic realm` = REALM,
         `Probability of identifying a threshold` = prob,
         `Lower 95% confidence interval` = asymp.LCL,
         `Upper 95% confidence interval`  = asymp.UCL)%>%
  mutate_if(is.numeric, round, 2)

write.csv(realm_df, "results/realm_thresh_prob.csv")




## Number of sites
nSites_model <- glmmTMB(relevant_threshold_YN ~ nSites, data = data, family = binomial)
summary(nSites_model)

save(nSites_model, file = "results/nSites_model.Rdata")

tab_model(nSites_model, show.intercept = F, show.se = T, show.ci = F, show.stat = T, 
          show.r2 = T, show.aic = T, show.icc = F,  show.re.var = FALSE, 
          transform = NULL, 
          string.stat = "z", string.resp = "", digits = 3, digits.rsq = 2,
          pred.labels = c("Number of sites"),
          title = "Threshold presence ~ number of sites",
          file = "results/ThreshPresence_nSites_model.html")


## Latitude and regional deforestation
lat_model <- glmmTMB(relevant_threshold_YN ~ avg_lat, data = data, family = binomial)
summary(lat_model)

deforest_model <- glmmTMB(relevant_threshold_YN ~ deforest, data = data, family = binomial)
summary(deforest_model)

AIC(lat_model, deforest_model)

save(lat_model, file = "results/lat_presence_model.Rdata")

tab_model(lat_model,  show.intercept = F, show.se = T, show.ci = F, show.stat = T, 
          show.r2 = T, show.aic = T, show.icc = F,  show.re.var = FALSE, 
          transform = NULL, 
          string.stat = "z", string.resp = "", digits = 3, digits.rsq = 2,
          pred.labels = c("Absolute latitude"),
          title = "Threshold presence ~ latitude",
          file = "results/ThreshPresence_lat_model.html")


save(deforest_model, file = "results/deforest_presence_model.Rdata")

tab_model(deforest_model,  show.intercept = F, show.se = T, show.ci = F, show.stat = T, 
          show.r2 = T, show.aic = T, show.icc = F,  show.re.var = FALSE, 
          transform = NULL, 
          string.stat = "z", string.resp = "", digits = 3, digits.rsq = 2,
          pred.labels = c("Regional deforestation"),
          title = "Threshold presence ~ regional deforestation",
          file = "results/ThreshPresence_deforest_model.html")


## Range of forest cover
forestRange_model <- glmmTMB(relevant_threshold_YN ~ forestRange, data = data, family = binomial)
summary(forestRange_model)

save(forestRange_model, file = "results/forestRange_model.Rdata")

tab_model(forestRange_model,  show.intercept = F, show.se = T, show.ci = F, show.stat = T, 
          show.r2 = T, show.aic = T, show.icc = F,  show.re.var = FALSE, 
          transform = NULL, 
          string.stat = "z", string.resp = "", digits = 3, digits.rsq = 2,
          pred.labels = c("Range of forest cover"),
          title = "Threshold presence ~ range of forest cover",
          file = "results/ThreshPresence_forestRange_model.html")


