#### Analyse threshold position -------------

library(glmmTMB)
library(emmeans)
library(tidyverse)
library(sjPlot)


data <- read.csv("results/FinalData_fp70.csv")
data %>% group_by(taxa) %>% summarise(n())

thresh_data <- subset(data, relevant_threshold_YN == 1)


min(thresh_data$g0, na.rm = T)
max(thresh_data$g0, na.rm = T)
mean(thresh_data$g0, na.rm = T)
median(thresh_data$g0, na.rm = T)

## Swap lowG0 and highG0 around if the model was an rseg as it messes up plotting
thresh_data = thresh_data %>% mutate(newLowG0 = ifelse(model == "rseg", low_g0, 0),
                                     low_g0 = ifelse(model == "rseg", high_g0, lowG0),
                                     high_g0 = ifelse(model == "rseg", newLowG0, highG0))


## We will model the position of the threholds using a beta regression since our
## response is bounded between  0 - 1
thresh_data = thresh_data %>% mutate(weightDiffG0 = log(1/diff_g0), type = as.factor(type))


## weighted mean
weighted.mean(thresh_data$g0, thresh_data$weightDiffG0)




## Weighted Average threshold for each taxonomic group
taxa_model = glmmTMB(g0 ~ taxa, data = thresh_data, weights = weightDiffG0,  family = beta_family())
summary(taxa_model)

taxa_model_emmeans <- emmeans(taxa_model, specs = ~ taxa)
taxa_summary <- summary(taxa_model_emmeans, type = "response")
AIC(taxa_model)
performance::r2(taxa_model)

taxa_df <- as.data.frame(taxa_summary)


taxa_df <- taxa_df %>%
  dplyr::select(taxa, response, asymp.LCL, asymp.UCL) %>%
  rename(`Taxonomic group` = taxa,
         `Threshold position` = response,
         `Lower 95% confidence interval` = asymp.LCL,
         `Upper 95% confidence interval`  = asymp.UCL)%>%
  mutate_if(is.numeric, round, 2)
taxa_df


#write.csv(taxa_df, "results/taxa_thresh_position.csv")




#### Latitude + regional FC ------------------------

thresh_data$vert_invert <- ifelse(thresh_data$taxa == "Arthropods", "Invertebrates", "Vertebrates")
thresh_data$vert_invert <- as.factor(thresh_data$vert_invert )

LatMod = glmmTMB(g0 ~ avg_lat * vert_invert, data = thresh_data, weights = weightDiffG0, family = beta_family())
summary(LatMod)

save(LatMod, file = "results/lat_position_model.Rdata")


LatMod = glmmTMB(g0 ~ avg_lat * relevel(vert_invert, ref = "Vertebrates"), data = thresh_data, weights = weightDiffG0, family = beta_family())
summary(LatMod)



RegionalFCMod = glmmTMB(g0 ~ cover * vert_invert, data = thresh_data, weights = weightDiffG0, family = beta_family())
summary(RegionalFCMod)

save(RegionalFCMod, file = "results/regionalFC_position_model.Rdata")



tab_model(LatMod,  show.intercept = F, show.se = T, show.ci = F, show.stat = T, 
          show.r2 = T, show.aic = T, show.icc = F,  show.re.var = FALSE, 
          transform = NULL, 
          string.stat = "z", string.resp = "", digits = 3, digits.rsq = 2,
        #  pred.labels =  c("Absolute latitude [reference level = Invertebrates]", "Absolute latitude x Group [Vertebrates]"),
          title = "Threshold position ~ latitude * phylum",
          file =  "results/lat_position_model.html")


tab_model(RegionalFCMod,  show.intercept = F, show.se = T, show.ci = F, show.stat = T, 
          show.r2 = T, show.aic = T, show.icc = F,  show.re.var = FALSE, 
          transform = NULL, 
          string.stat = "z", string.resp = "", digits = 3, digits.rsq = 2,
          #pred.labels =  "Regional deforestation",
          title = "Threshold position ~ regional forest cover * phylum",
          file =  "results/regionalFC_position_model.html")

RegionalFCMod = glmmTMB(g0 ~ cover * relevel(vert_invert, ref = "Vertebrates"), data = thresh_data, weights = weightDiffG0, family = beta_family())
summary(RegionalFCMod)

