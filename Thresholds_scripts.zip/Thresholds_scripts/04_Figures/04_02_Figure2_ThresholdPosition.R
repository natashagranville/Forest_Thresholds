#### Figure 2 - global variation in position of threshold ----------------------

library(dplyr)
library(sf)
library(ggplot2)
library(ggeffects)
library(viridis)
library(cowplot)


data <- read.csv("results/FinalData_fp70.csv")

thresh_data <- subset(data, relevant_threshold_YN == 1)


##### Panel A - map ------------------------------------------------------------

load("data/processed/study_Geometries.RData")

centroids <- lapply(study_Plot_Points_sf, function(x) {
  st_centroid(sfheaders::sf_multipoint(st_coordinates(x)))
})

PIDs <- lapply(study_Plot_Points_sf, function(x) {
  unique(x$PID)
})

centroids_sf <- do.call(rbind, centroids)
PIDs <- do.call(rbind, PIDs)

centroids <- cbind(centroids_sf, PIDs)
colnames(centroids) <- c("id","pid","geometry")


thresh_data <- st_sf(left_join(thresh_data, centroids, by = "pid"))

world <- map_data('world') %>% 
  as_tibble()

thresh_data$Site_Longitude_x_wgs84 <- st_coordinates(thresh_data)[,1]
thresh_data$Site_Latitude_y_wgs84 <- st_coordinates(thresh_data)[,2]



thresh_position_map <- ggplot() +
  geom_polygon(data=world, 
               aes(long, lat, group = group), colour=NA, fill='#C8C8C8', size=0) +#
  coord_map('mollweide', ylim = c(-60, 90), xlim = c(-180, 180)) +
  theme_void() +
  theme(panel.grid = element_blank(), 
        panel.border = element_blank(),
        axis.ticks = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        legend.position = c(0.2,0.3),
        legend.text = element_text(size = 16),
        legend.title = element_text(size = 16),
        legend.background = element_blank(),
        plot.margin = margin(0.5,0.5,0.5,0.5, "cm")) +
  scale_x_continuous(breaks = seq(-180, 180, by = 30), 
                     minor_breaks = seq(-180, 180, by = 10)) +
  scale_y_continuous(breaks = seq(-60, 90, by = 30), 
                     minor_breaks = seq(-60, 90, by = 10)) +
  geom_point(data = thresh_data, aes(x = Site_Longitude_x_wgs84, y = Site_Latitude_y_wgs84, colour = g0),  size = 3) +
  scale_colour_viridis(direction = -1, breaks = c(0, 0.25, 0.5, 0.75, 1), name = "Threshold \nposition",
                       labels = c("0%", "25%", "50%", "75%", "100%"), limits = c(0, 1))

thresh_position_map
ggsave(thresh_position_map, filename = "figures/thresh_position_map.jpg", width = 25, height = 28, units = "cm")


##### Panel B - boxplot --------------------------------------------------------

thresh_data <- st_drop_geometry(thresh_data)

thresh_data %>% group_by(taxa) %>% summarise(mean(g0))

thresh_data$taxa <- ifelse(thresh_data$taxa == "Arthropods", "Invertebrates", "Vertebrates")
taxa_boxplot <- ggplot(thresh_data, aes(x = taxa, y = g0)) +
  geom_boxplot(width = 0.5, outliers = F) +
  geom_jitter(aes(colour = g0), width = 0.2, alpha = 0.7) +
  scale_colour_viridis(direction = -1) +
  labs(x = "",  y = "Threshold position") +
  scale_y_continuous(labels = scales::percent, breaks = c(0,0.2,0.4,0.6,0.8,1),
                     limits = c(0,1)) +
  theme_classic() +
  theme(axis.text = element_text(size = 13, colour = "black"),
        axis.title = element_text(size = 13),
        legend.position = "none")
taxa_boxplot



thresh_data$temp_trop <- ifelse(thresh_data$avg_lat > 23.5, "Temperate", "Tropical")

temp_trop_boxplot <- ggplot(thresh_data, aes(x = temp_trop, y = g0)) +
  geom_boxplot(width = 0.5, outliers = F) +
  geom_jitter(aes(colour = g0), width = 0.2, alpha = 0.7) +
  scale_colour_viridis(direction = -1) +
  labs(x = "",  y = "Threshold position") +
  scale_y_continuous(labels = scales::percent, breaks = c(0,0.2,0.4,0.6,0.8,1),
                     limits = c(0,1)) +
  theme_classic() +
  theme(axis.text = element_text(size = 13, colour = "black"),
        axis.title = element_text(size = 13),
        legend.position = "none")
temp_trop_boxplot


boxplot <- plot_grid(taxa_boxplot, temp_trop_boxplot, nrow = 1, align = "vh")
boxplot

ggsave(boxplot, filename = "figures/boxplot.jpg", width = 18, height = 7, units = "cm")





##### Panel C - latitude and regional deforestation graph ----------------------

load("results/deforest_position_model.Rdata")


allTaxa_Predictions = expand.grid(deforest = seq(min(thresh_data$deforest), max(thresh_data$deforest), length.out = 100), 
                                  weightDiffG0 = 1) %>% 
  mutate(g0 = predict(DeforestMod, ., type = "response"), se = predict(DeforestMod, ., se.fit = TRUE, type = "response")[[2]]) %>%
  mutate(se = se*1.96)


pred <- ggpredict(DeforestMod, terms = c('deforest[all]'))


deforest_Plot = ggplot() +
  geom_pointrange(data = thresh_data, aes(x = deforest, y = g0, ymin = low_g0, ymax = high_g0, colour = g0), size = 0.9, linewidth = 1) +
  
  geom_line(data = pred, aes(x = x,y = predicted), size = 0.9, linewidth = 1) +
  geom_ribbon(data = pred, aes(x = x, ymin = conf.low, ymax = conf.high), alpha = 0.15) +
  scale_colour_viridis(direction = -1, breaks = c(0, 0.25, 0.5, 0.75, 1), name = "Threshold \nposition",
                       labels = c("0%", "25%", "50%", "75%", "100%"), limits = c(0, 1)) +
  theme_classic() +
  scale_x_continuous(limits = c(0,1)) +
  scale_y_continuous(labels = scales::percent, breaks = c(0,0.2,0.4,0.6,0.8,1)) +
  labs(x = "Regional Deforestation", y = "Threshold position", col = "Latitude") +
  theme(axis.text = element_text(size = 15, colour = "black"),
        legend.position = "none",
        axis.title = element_text(size = 15),
        strip.background = element_blank(),
        panel.spacing = unit(1, "lines"),
        legend.title = element_text(size = 13),
        legend.text = element_text(size = 13))
deforest_Plot

ggsave(deforest_Plot, filename = "figures/deforest_plot.png", width = 12, height = 16, units = "cm")



