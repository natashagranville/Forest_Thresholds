#### Map of studies, coloured by taxa ---------------------------------

library(dplyr)
library(sf)
library(ggplot2)


data <- read.csv("results/FinalData_fp70.csv")



load("data/processed/study_Geometries.RData")

centroids <- lapply(study_Plot_Points_sf, function(x) {
  st_centroid(sfheaders::sf_multipoint(st_coordinates(x)))
})

PIDs <- lapply(study_Plot_Points_sf, function(x) {
  unique(x$PID)
})

centroids_sf <- do.call(rbind, centroids)
PIDs <- do.call(rbind, PIDs)

centroids <- cbind(centroids_sf, PIDs)
colnames(centroids) <- c("id","pid","geometry")


data <- st_sf(left_join(data, centroids, by = "pid"))

world <- map_data('world') %>% 
  as_tibble()

data <- data[!duplicated(data),]

data$Site_Longitude_x_wgs84 <- st_coordinates(data)[,1]
data$Site_Latitude_y_wgs84 <- st_coordinates(data)[,2]

all_map <- ggplot() +
  geom_polygon(data=world, 
               aes(long, lat, group = group), colour=NA, fill='#C8C8C8',  linewidth=0) +#
  coord_map('mollweide', ylim = c(-60, 90), xlim = c(-180, 180)) +
  theme_bw() +
  theme(panel.grid = element_line(colour = 'grey30', size = 0.1), 
        panel.border = element_blank(),
        axis.ticks = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        legend.title = element_blank(),
        legend.position = c(0.2,0.3),
        legend.text = element_text(size = 16),
        legend.background = element_rect(fill = NA),
        plot.margin = margin(0.5,0.5,0.5,0.5, "cm")) +
  scale_x_continuous(breaks = seq(-180, 180, by = 30), 
                     minor_breaks = seq(-180, 180, by = 10)) +
  scale_y_continuous(breaks = seq(-60, 90, by = 30), 
                     minor_breaks = seq(-60, 90, by = 10)) +
  geom_point(data = data, aes(x = Site_Longitude_x_wgs84, y = Site_Latitude_y_wgs84, colour = taxa, fill = taxa, shape = taxa), size = 3) +
  scale_fill_manual(values = c('forestgreen', 'magenta3', 'darkorange', 'skyblue'),
                    labels = c("Arthropods", "Birds", "Herptiles", "Mammals")) +
  scale_colour_manual(values = c('forestgreen', 'magenta3', 'darkorange', 'skyblue'),
                      labels = c("Arthropods", "Birds", "Herptiles", "Mammals")) +
  scale_shape_manual(values = c(21, 22, 24, 25),
                     labels = c("Arthropods", "Birds", "Herptiles", "Mammals"))
all_map

ggsave("figures/all_studies_taxa_map.jpg", width = 20, height = 15, units = "cm")


thresh_data <- subset(data, relevant_threshold_YN == 1)

thresh_map <- ggplot() +
  geom_polygon(data=world, 
               aes(long, lat, group = group), colour=NA, fill='#C8C8C8', linewidth=0) +#
  coord_map('mollweide', ylim = c(-60, 90), xlim = c(-180, 180)) +
  theme_bw() +
  theme(panel.grid = element_line(colour = 'grey30', size = 0.1), 
        panel.border = element_blank(),
        axis.ticks = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        legend.title = element_blank(),
        legend.position = c(0.2,0.3),
        legend.text = element_text(size = 16),
        legend.background = element_rect(fill = NA),
        plot.margin = margin(0.5,0.5,0.5,0.5, "cm")) +
  scale_x_continuous(breaks = seq(-180, 180, by = 30), 
                     minor_breaks = seq(-180, 180, by = 10)) +
  scale_y_continuous(breaks = seq(-60, 90, by = 30), 
                     minor_breaks = seq(-60, 90, by = 10)) +
  geom_point(data = thresh_data, aes(x = Site_Longitude_x_wgs84, y = Site_Latitude_y_wgs84, colour = taxa, fill = taxa, shape = taxa), size = 3) +
  scale_fill_manual(values = c('forestgreen', 'magenta3', 'darkorange', 'skyblue'),
                    labels = c("Arthropods", "Birds", "Herptiles", "Mammals")) +
  scale_colour_manual(values = c('forestgreen', 'magenta3', 'darkorange', 'skyblue'),
                      labels = c("Arthropods", "Birds", "Herptiles", "Mammals")) +
  scale_shape_manual(values = c(21, 22, 24, 25),
                     labels = c("Arthropods", "Birds", "Herptiles", "Mammals"))
thresh_map

ggsave("figures/thresh_studies_taxa_map.jpg", width = 20, height = 15, units = "cm")
