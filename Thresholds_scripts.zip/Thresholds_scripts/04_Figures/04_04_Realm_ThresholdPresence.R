#### Plot how probability of detecting a threshold might vary across biogeographic realms --------------


library(tidyverse)
library(sf)


data <- read.csv("results/FinalData_fp70.csv")

data$realm[data$realm == "Oceania"] <- "Australasia"



##### Doughnut plots -----------------------------
data_sum <- data %>% 
  group_by(relevant_threshold_YN, REALM) %>%
  summarise(count = n())


afrotropic <- subset(data_sum, REALM == "Afrotropic")
afrotropic$fraction <- afrotropic$count / sum(afrotropic$count)
afrotropic$ymax <- cumsum(afrotropic$fraction)
afrotropic$ymin <- c(0, head(afrotropic$ymax, n=-1))
afrotropic$labelPosition <- (afrotropic$ymax + afrotropic$ymin) / 2
afrotropic$label <- paste0(afrotropic$count)

afrotropic_plot <- ggplot(afrotropic, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=as.factor(relevant_threshold_YN))) +
  geom_rect() +
  geom_text(x=3.5, aes(y= labelPosition, label= label), size=5, fill = NA) +
  scale_fill_manual(values = c("orange", "#6a51a3"),
                    labels = c("No conservation-relevant threshold identified", "Conservation-relevant threshold identified")) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  ggtitle("Afrotropical") +
  theme_void() +
  theme(legend.title = element_blank(),
        legend.position = "none",
    plot.title = element_text(hjust = 0.5, size = 12))
afrotropic_plot



indomalay <- subset(data_sum, REALM == "Indomalayan")
indomalay$fraction <- indomalay$count / sum(indomalay$count)
indomalay$ymax <- cumsum(indomalay$fraction)
indomalay$ymin <- c(0, head(indomalay$ymax, n=-1))
indomalay$labelPosition <- (indomalay$ymax + indomalay$ymin) / 2
indomalay$label <- paste0(indomalay$count)

indomalay_plot <- ggplot(indomalay, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=as.factor(relevant_threshold_YN))) +
  geom_rect() +
  geom_text(x=3.5, aes(y= labelPosition, label= label), size=5, fill = NA) +
  scale_fill_manual(values = c("orange", "#6a51a3")) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  ggtitle("Indo-Malayan") +
  theme_void() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 12))
indomalay_plot



nearctic <- subset(data_sum, REALM == "Nearctic")
nearctic$fraction <- nearctic$count / sum(nearctic$count)
nearctic$ymax <- cumsum(nearctic$fraction)
nearctic$ymin <- c(0, head(nearctic$ymax, n=-1))
nearctic$labelPosition <- (nearctic$ymax + nearctic$ymin) / 2
nearctic$label <- paste0(nearctic$count)

nearctic_plot <- ggplot(nearctic, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=as.factor(relevant_threshold_YN))) +
  geom_rect() +
  geom_text(x=3.5, aes(y= labelPosition, label= label), size=5, fill = NA) +
  scale_fill_manual(values = c("orange", "#6a51a3")) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  ggtitle("Nearctic") +
  theme_void() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 12))
nearctic_plot




neotropic <- subset(data_sum, REALM == "Neotropic")
neotropic$fraction <- neotropic$count / sum(neotropic$count)
neotropic$ymax <- cumsum(neotropic$fraction)
neotropic$ymin <- c(0, head(neotropic$ymax, n=-1))
neotropic$labelPosition <- (neotropic$ymax + neotropic$ymin) / 2
neotropic$label <- paste0(neotropic$count)

neotropic_plot <- ggplot(neotropic, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=as.factor(relevant_threshold_YN))) +
  geom_rect() +
  geom_text(x=3.5, aes(y= labelPosition, label= label), size=5, fill = NA) +
  scale_fill_manual(values = c("orange", "#6a51a3")) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  ggtitle("Neotropical") +
  theme_void() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 12))
neotropic_plot




australasia <- subset(data_sum, REALM == "Australasia")
australasia$fraction <- australasia$count / sum(australasia$count)
australasia$ymax <- cumsum(australasia$fraction)
australasia$ymin <- c(0, head(australasia$ymax, n=-1))
australasia$labelPosition <- (australasia$ymax + australasia$ymin) / 2
australasia$label <- paste0(australasia$count)

australasia_plot <- ggplot(australasia, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=as.factor(relevant_threshold_YN))) +
  geom_rect() +
  geom_text(x=3.5, aes(y= labelPosition, label= label), size=5, fill = NA) +
  scale_fill_manual(values = c("orange", "#6a51a3")) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  ggtitle("Australasian") +
  theme_void() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 12))
australasia_plot




palearctic <- subset(data_sum, REALM == "Palearctic")
palearctic$fraction <- palearctic$count / sum(palearctic$count)
palearctic$ymax <- cumsum(palearctic$fraction)
palearctic$ymin <- c(0, head(palearctic$ymax, n=-1))
palearctic$labelPosition <- (palearctic$ymax + palearctic$ymin) / 2
palearctic$label <- paste0(palearctic$count)

palearctic_plot <- ggplot(palearctic, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=as.factor(relevant_threshold_YN))) +
  geom_rect() +
  geom_text(x=3.5, aes(y= labelPosition, label= label), size=5, fill = NA) +
  scale_fill_manual(values = c("orange", "#6a51a3")) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  ggtitle("Palearctic") +
  theme_void() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 12))
palearctic_plot

legend_plot <- ggplot(afrotropic, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=as.factor(relevant_threshold_YN))) +
  geom_rect() +
  geom_text(x=3.5, aes(y= labelPosition, label= label), size=5, fill = NA) +
  scale_fill_manual(values = c("orange", "#6a51a3"),
                    labels = c("No conservation-relevant threshold identified", "Conservation-relevant threshold identified")) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  ggtitle("Afrotropical") +
  theme_void() +
  theme(legend.title = element_blank(),
        legend.text = element_text(size = 12),
        plot.title = element_text(hjust = 0.5, size = 18))

legend <- cowplot::get_legend(legend_plot)


doughnut_plots <- cowplot::plot_grid(afrotropic_plot, indomalay_plot, nearctic_plot,
                                     neotropic_plot, australasia_plot, palearctic_plot)
doughnut_plots

doughnut_plots <- cowplot::plot_grid(doughnut_plots, legend, nrow = 2, rel_heights = c(1,0.2))
doughnut_plots
ggsave(doughnut_plots, filename = "figures/REALM_doughnut_plots.png", width = 15, height = 10, units = "cm")

##### Map ------------------------

### study locations
load("data/processed/study_Geometries.RData")

centroids <- lapply(study_Plot_Points_sf, function(x) {
  st_centroid(sfheaders::sf_multipoint(st_coordinates(x)))
})

PIDs <- lapply(study_Plot_Points_sf, function(x) {
  unique(x$PID)
})

centroids_sf <- do.call(rbind, centroids)
PIDs <- do.call(rbind, PIDs)

centroids <- cbind(centroids_sf, PIDs)
colnames(centroids) <- c("id","pid","geometry")


data <- st_sf(left_join(data, centroids, by = "pid"))

world <- map_data('world') %>% 
  as_tibble()

data <- data[!duplicated(data),]

data$Site_Longitude_x_wgs84 <- st_coordinates(data)[,1]
data$Site_Latitude_y_wgs84 <- st_coordinates(data)[,2]

## REALM boundaries

# Read shapefile
REALMs <- st_read("data/raw/Generalised_Biogeographic_REALMs_2004/brpol_fin_dd.shp")

# Convert to data frame with grouping info
REALMs_df <- REALMs %>%
  st_cast("MULTIPOLYGON") %>%
  st_cast("POLYGON") %>%
  st_as_sf() %>%
  mutate(id = row_number()) %>%
  st_cast("LINESTRING") %>%
  st_coordinates() %>%
  as.data.frame()

## plot map
map <- ggplot() +
  geom_polygon(data=world, 
               aes(long, lat, group = group), colour=NA, fill='#C8C8C8', size=0, alpha = 0.3) +
  geom_path(data = REALMs_df, aes(x = X, y = Y, group = L1), color = "#C1C1C1") +
  theme_void() +
  theme(panel.grid = element_blank(), 
        panel.border = element_blank(),
        axis.ticks = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        legend.title = element_blank(),
        legend.position = "none",
        legend.text = element_text(size = 16),
        legend.background = element_blank(),
        plot.margin = margin(0.5,0.5,0.5,0.5, "cm")) +
  scale_x_continuous(breaks = seq(-180, 180, by = 30), 
                     minor_breaks = seq(-180, 180, by = 10)) +
  scale_y_continuous(breaks = seq(-60, 90, by = 30), 
                     minor_breaks = seq(-60, 90, by = 10)) +
  geom_point(data = data, aes(x = Site_Longitude_x_wgs84, y = Site_Latitude_y_wgs84, 
                              colour = as.factor(relevant_threshold_YN)),  size = 2, alpha = 0.7) +
  scale_colour_manual(values = c("orange", "#6a51a3"))
map

ggsave("figures/REALM_map.jpg", width = 20, height = 15, units = "cm")

