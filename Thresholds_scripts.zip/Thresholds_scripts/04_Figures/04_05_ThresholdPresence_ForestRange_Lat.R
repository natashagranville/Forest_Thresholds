#### Threshold presence ~ forest range or geographic area of studies ---------

library(cowplot)
library(ggplot2)
library(glmmTMB)

data <- read.csv("results/FinalData_fp70.csv")




#### Forest range ---------
load("results/forestRange_model.Rdata")

forestRange_pred <-  predict(forestRange_model, data, type = 'response', re.form = NA, se.fit = T)

data$forestRange_pred <- forestRange_pred$fit
data$forestRange_pred_LCI <- forestRange_pred$fit - forestRange_pred$se.fit
data$forestRange_pred_UCI <- forestRange_pred$fit + forestRange_pred$se.fit

forestRange_plot <- ggplot(data, aes(x = forestRange)) +
  geom_line(aes(y = forestRange_pred), linewidth = 1.2) +
  geom_point(aes(y = relevant_threshold_YN, colour = factor(relevant_threshold_YN)), 
             alpha = 0.75,  shape = 16,  position = position_jitter(width = 0, height = 0.05)) +
  scale_colour_manual(values = c("0" = "orange", "1" = "#6a51a3")) +
  geom_ribbon(aes(ymin = forestRange_pred_LCI, ymax = forestRange_pred_UCI), colour = "#C8C8C8", alpha = 0.3) +
  theme_classic() +
  labs(x = "Range of forest cover", y = "Probability of detecting a threshold") +
  theme(axis.text = element_text(size = 18, colour = "black"),
        axis.title = element_text(size = 18),
        legend.position = "none")
forestRange_plot


#### Latitude -----------------
load("results/lat_presence_model.Rdata")

lat_pred <-  predict(lat_model, data, type = 'response', re.form = NA, se.fit = T)

data$lat_pred <- lat_pred$fit
data$lat_pred_LCI <- lat_pred$fit - lat_pred$se.fit
data$lat_pred_UCI <- lat_pred$fit + lat_pred$se.fit

lat_plot <- ggplot(data, aes(x = avg_lat)) +
  geom_line(aes(y = lat_pred), linewidth = 1.2) +
  geom_point(aes(y = relevant_threshold_YN, colour = factor(relevant_threshold_YN)), 
             alpha = 0.75,  shape = 16,  position = position_jitter(width = 0, height = 0.05)) +
  scale_colour_manual(values = c("0" = "orange", "1" = "#6a51a3")) +
  geom_ribbon(aes(ymin = lat_pred_LCI, ymax = lat_pred_UCI), colour = "#C8C8C8", alpha = 0.3) +
  theme_classic() +
  labs(x = "Absolute latitude (°)", y = "Probability of detecting a threshold") +
  theme(axis.text = element_text(size = 18, colour = "black"),
        axis.title = element_text(size = 18),
        legend.position = "none")
lat_plot


combined_figure <- cowplot::plot_grid(forestRange_plot, lat_plot, ncol = 2, align = "vh", 
                             labels = c("(A)", "(B)"), label_fontface = "plain", hjust = -1.5)
combined_figure

ggsave(combined_figure, filename = "figures/forestRange_lat_plot.jpg", height = 12, width = 22, units = "cm")

