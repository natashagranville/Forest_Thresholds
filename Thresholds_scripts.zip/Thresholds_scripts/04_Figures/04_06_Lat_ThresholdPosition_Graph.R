#### Supplementary figure - threshold position ~ latitude ---------------------

library(dplyr)
library(sf)
library(ggplot2)
library(ggeffects)
library(viridis)


data <- read.csv("results/FinalData_fp70.csv")


thresh_data <- subset(data, relevant_threshold_YN == 1)


thresh_data$vert_invert <- ifelse(thresh_data$taxa == "Arthropods", "Invertebrates", "Vertebrates")
thresh_data$vert_invert <- as.factor(thresh_data$vert_invert)

load("results/lat_position_model.Rdata")

## Swap lowG0 and highG0 around if the model was an rseg as it messes up plotting
thresh_data = thresh_data %>% mutate(newLowG0 = ifelse(model == "rseg", low_g0, 0),
                                     low_g0 = ifelse(model == "rseg", high_g0, lowG0),
                                     high_g0 = ifelse(model == "rseg", newLowG0, highG0))


## We will model the position of the threholds using a beta regression since our
## response is bounded between  0 - 1
thresh_data = thresh_data %>% mutate(weightDiffG0 = log(1/diff_g0), type = as.factor(type))


thresh_data$pred <- predict(LatMod, thresh_data, type = "response")
thresh_data$pred_se <- predict(LatMod, thresh_data, se.fit = T, type = "response")[[2]]
thresh_data$pred_lci <- thresh_data$pred - (1.96 * thresh_data$pred_se)
thresh_data$pred_uci <- thresh_data$pred + (1.96 * thresh_data$pred_se)


facet_labels <- as_labeller(c('Invertebrates' = 'Arthropods',
                              'Vertebrates' = 'Vertebrates'))

lat_Plot = ggplot() +
  geom_pointrange(data = thresh_data, aes(x = avg_lat, y = g0, ymin = low_g0, ymax = high_g0, colour = g0), size = 0.9, linewidth = 1) +
  facet_wrap(~vert_invert, labeller = facet_labels) +
  geom_ribbon(data = thresh_data, aes(x = avg_lat, y = pred, ymin = pred_lci, ymax = pred_uci), fill = "#C8C8C8", alpha = 0.5) +
  
  geom_line(data = thresh_data, aes(x = avg_lat, y = pred), size = 0.9, linewidth = 1) +
  scale_colour_viridis(direction = -1, breaks = c(0, 0.25, 0.5, 0.75, 1), name = "Threshold \nposition",
                       labels = c("0%", "25%", "50%", "75%", "100%"), limits = c(0, 1)) +
  theme_classic() +
  scale_y_continuous(labels = scales::percent, breaks = c(0,0.2,0.4,0.6,0.8,1)) +
  labs(x = "Absolute latitude (°)", y = "Threshold position") +
  theme(axis.text = element_text(size = 15, colour = "black"),
        legend.position = "none",
        axis.title = element_text(size = 15),
        strip.background = element_blank(),
        strip.text= element_text(size = 15),
        panel.spacing = unit(1, "lines"),
        legend.title = element_text(size = 13),
        legend.text = element_text(size = 13))
lat_Plot

ggsave(lat_Plot, filename = "figures/lat_plot.png", width = 17, height = 13, units = "cm")



