#### Supplementary figure - threshold position ~ latitude ---------------------

library(dplyr)
library(sf)
library(ggplot2)
library(ggeffects)
library(viridis)


data <- read.csv("results/FinalData_fp70.csv")


thresh_data <- subset(data, relevant_threshold_YN == 1)

load("results/lat_position_model.Rdata")

summary(LatMod)

allTaxa_Predictions = expand.grid(avg_lat = seq(min(thresh_data$avg_lat), max(thresh_data$avg_lat), length.out = 100), 
                                  weightDiffG0 = 1) %>% 
  mutate(g0 = predict(LatMod, ., type = "response"), se = predict(LatMod, ., se.fit = TRUE, type = "response")[[2]]) %>%
  mutate(se = se*1.96)


pred <- ggpredict(LatMod, terms = c('avg_lat[all]'))


lat_Plot = ggplot() +
  geom_pointrange(data = thresh_data, aes(x = avg_lat, y = g0, ymin = low_g0, ymax = high_g0, colour = g0), size = 0.9, linewidth = 1) +
  
  geom_ribbon(data = pred, aes(x = x, ymin = conf.low, ymax = conf.high), fill = "#C8C8C8", alpha = 0.5) +
  
  geom_line(data = pred, aes(x = x,y = predicted), size = 0.9, linewidth = 1) +
  scale_colour_viridis(direction = -1, breaks = c(0, 0.25, 0.5, 0.75, 1), name = "Threshold \nposition",
                       labels = c("0%", "25%", "50%", "75%", "100%"), limits = c(0, 1)) +
  theme_classic() +
  scale_y_continuous(labels = scales::percent, breaks = c(0,0.2,0.4,0.6,0.8,1)) +
  labs(x = "Absolute latitude (°)", y = "Threshold position") +
  theme(axis.text = element_text(size = 15, colour = "black"),
        legend.position = "none",
        axis.title = element_text(size = 15),
        strip.background = element_blank(),
        panel.spacing = unit(1, "lines"),
        legend.title = element_text(size = 13),
        legend.text = element_text(size = 13))
lat_Plot

ggsave(lat_Plot, filename = "figures/lat_plot.png", width = 15, height = 15, units = "cm")



