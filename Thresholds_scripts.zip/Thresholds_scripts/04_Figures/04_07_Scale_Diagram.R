#### Figure to illustrate landscape vs. regional scales -----------------------

library(sf)
library(terra)

r <- rast("data/processed/BIOFRAG_and_PREDICTS/PID0095_DungBeetles_Mexico/hansen_image_PID0095.tif")

r <- r[[1]]

palette <- colorRampPalette(c("#FFFFFF", "#EAF7E6", "#CDECC6","#9DDC9B","#5AB46E","#238B45"))




##### Regional scale --------------------

pdf("regional_scale.pdf")
plot(r, col = palette(200), axes = TRUE, main = "Regional scale")



load("data/processed/study_Geometries.RData")

points <- study_Plot_Points_sf[[60]]

unique(points$PID)


plot(st_geometry(points), add = T, pch = 4, cex.axis = 2)




behr <- "+proj=cea +lon_0=0 +lat_ts=30 +x_0=0 +y_0=0 +datum=WGS84 +ellps=WGS84 +units=m +no_defs"

bbox_data <- points 
bbox_data <- st_transform(points, behr)
bbox_data <- st_buffer(bbox_data, 10000)
bbox_data <- st_transform(bbox_data, 4326)

bbox <- st_as_sfc(st_bbox(bbox_data))
plot(st_geometry(bbox), add = T)

dev.off()



##### Landscape scale -------------------------------------------------------

pdf("landscape_scale.pdf")

cropped_r <- crop(r, st_bbox(bbox_data))

plot(cropped_r, col = palette(200), axes = TRUE, main = "Landscape scales")
plot(st_geometry(points), add = T, pch = 4)



buffered_points_200 <- points
buffered_points_200 <- st_transform(buffered_points_200, behr)
buffered_points_200 <- st_buffer(buffered_points_200, 200)
buffered_points_200 <- st_transform(buffered_points_200, 4326)
plot(st_geometry(buffered_points_200), add = T)




buffered_points_500 <- points
buffered_points_500 <- st_transform(buffered_points_500, behr)
buffered_points_500 <- st_buffer(buffered_points_500, 500)
buffered_points_500 <- st_transform(buffered_points_500, 4326)
plot(st_geometry(buffered_points_500), add = T)



buffered_points_1000 <- points
buffered_points_1000 <- st_transform(buffered_points_1000, behr)
buffered_points_1000 <- st_buffer(buffered_points_1000, 1000)
buffered_points_1000 <- st_transform(buffered_points_1000, 4326)
plot(st_geometry(buffered_points_1000), add = T)



buffered_points_2000 <- points
buffered_points_2000 <- st_transform(buffered_points_2000, behr)
buffered_points_2000 <- st_buffer(buffered_points_2000, 2000)
buffered_points_2000 <- st_transform(buffered_points_2000, 4326)

plot(st_geometry(buffered_points_2000), add = T)
dev.off()



pdf("one_point.pdf")

one_point <- points[14,]
one_point_200 <- buffered_points_200[14,]
one_point_500 <- buffered_points_500[14,]
one_point_1000 <- buffered_points_1000[14,]
one_point_2000 <- buffered_points_2000[14,]


bbox_data <- one_point_2000 
bbox_data <- st_transform(one_point_2000, behr)
bbox_data <- st_buffer(bbox_data, 100)
bbox_data <- st_transform(bbox_data, 4326)

one_point_r <- crop(cropped_r, bbox_data)

plot(one_point_r, col = palette(200), axes = TRUE)
plot(st_geometry(one_point), add = T, pch = 4)
plot(st_geometry(one_point_200), add = T)
plot(st_geometry(one_point_500), add = T)
plot(st_geometry(one_point_1000), add = T)
plot(st_geometry(one_point_2000), add = T)

dev.off()



##### Local scale ------------------------------------



pdf("local_scale.pdf")

buffered_points_50 <- points
buffered_points_50 <- st_transform(buffered_points_50, behr)
buffered_points_50 <- st_buffer(buffered_points_50, 50)
buffered_points_50 <- st_transform(buffered_points_50, 4326)
plot(st_geometry(buffered_points_50))

one_point_buffered <- buffered_points_50[14,]
one_point <- points[14,]

cropped_r <- crop(r, st_bbox(st_buffer(one_point_buffered, 10)))


plot(cropped_r, col = palette(200), axes = TRUE, main = "Local scale")


plot(st_geometry(one_point), add = T, pch = 4)

plot(st_geometry(one_point_buffered), add = T)

dev.off()