#### Prep data to test for species richness thresholds

library(tidyverse)
library(janitor)

data <- read.csv( "data/processed/formattedSpecOcc_fp70.csv")

# remove local scale 50 m buffer
data <- subset(data, buffer != 50)


### Calculate log-transformed species richness
data <- data %>%
  group_by(plot_id, buffer) %>%
  summarise(sp_rich = log10(sum(occurrence)), 
            forest_cover = unique(forest_cover),
            pid = unique(pid))


## Save as data used for analysis
write_csv(data, "data/processed/SpeciesRichness/SpeciesRichness_fp70.csv")

