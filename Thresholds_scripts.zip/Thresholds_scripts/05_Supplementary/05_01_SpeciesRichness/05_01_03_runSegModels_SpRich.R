#### Run species richness models at optimal scale 

library(tidyverse)
library(segmented)
library(piecewiseSEM)


data <- read.csv("data/processed/SpeciesRichness/SpeciesRichness_scaleOptimised_Model_data_fp70.csv")


split_by_pid <- split(data, data$pid)

for(i in 1:length(split_by_pid)){
  
  tryCatch({
    
    pid_data <- split_by_pid[[i]]
    
    pid <- unique(pid_data$pid)
    
    
    print(paste0("------- Running model at optimal scale for ", pid, " -------"))
    
    lin = lm(sp_rich ~ forest_cover, data = pid_data)
    
    
    ## Create new models with forest cover removed for null slope tests
    nullLin <- update(lin, . ~ . -forest_cover)
    
    ## Create negative forest cover to use in null right slope models
    negative_forest_cover <- -pid_data$forest_cover
    
    ## Run right null slope only 
    rseg = segmented(nullLin, seg.Z = ~negative_forest_cover, data = pid_data)
    
    
    out <- list(pid = pid, lin = lin, rseg = rseg)
    
    
    save(out, file = paste0("results/SpeciesRichness/Models_SpRich/", unique(pid_data$pid),".Rdata"))
    
    
    rm(list = setdiff(ls(), c("split_by_pid", "cutOff_value")))
    
  }
  , error = function(e) {
    print(paste("Error:", conditionMessage(e), "\n"))
    
  })
  
}

