
library(emmeans)
library(tidyverse)
library(glmmTMB)
library(sjPlot)

data <- read.csv("results/SpeciesRichness/Final_data_SpeciesRichness.csv")


data$realm[data$realm == "Oceania"] <- "Australasia"


## How many of each type?
data %>% group_by(type) %>% summarise(n())

taxa_model <- glmmTMB(relevant_threshold_YN ~ taxa, data = data, family = "binomial")
summary(taxa_model)

taxa_model_emmeans <- emmeans(taxa_model, specs = ~ taxa)
taxa_summary <- summary(taxa_model_emmeans, type = "response")
taxa_summary

## Biogeographic realm
realm_model <- glmmTMB(relevant_threshold_YN ~ realm, data = data, family = "binomial")
summary(realm_model)

realm_model_emmeans <- emmeans(realm_model, specs = ~ realm)
realm_summary <- summary(realm_model_emmeans, type = "response")
realm_summary

## Number of sites
nSites_model <- glmmTMB(relevant_threshold_YN ~ nSites, data = data, family = binomial)
summary(nSites_model)

save(nSites_model, file = "results/SpeciesRichness/SpeciesRichness_nSites_model.Rdata")

## Latitude
lat_model <- glmmTMB(relevant_threshold_YN ~ avg_lat, data = data, family = binomial)
summary(lat_model)


## Regional deforestation
deforest_model <- glmmTMB(relevant_threshold_YN ~ deforest, data = data, family = binomial)
summary(deforest_model)

save(deforest_model, file = "results/SpeciesRichness/SpeciesRichness_deforest_model.Rdata")

## Range of forest cover
forestRange_model <- glmmTMB(relevant_threshold_YN ~ forestRange, data = data, family = binomial)
summary(forestRange_model)
