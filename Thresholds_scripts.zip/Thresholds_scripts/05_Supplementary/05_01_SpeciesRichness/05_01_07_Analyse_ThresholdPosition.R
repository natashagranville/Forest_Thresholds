
library(emmeans)
library(tidyverse)
library(glmmTMB)
library(sjPlot)

data <- read.csv("results/SpeciesRichness/Final_data_SpeciesRichness.csv")



data$vert_invert <- ifelse(data$taxa == "Arthropods", "Invertebrates", "Vertebrates")

data$vert_invert <- as.factor(data$vert_invert)



thresh_data <- subset(data, relevant_threshold_YN == 1)

min(thresh_data$G0, na.rm = T)
max(thresh_data$G0, na.rm = T)
mean(thresh_data$G0, na.rm = T)
median(thresh_data$G0, na.rm = T)



## Swap lowG0 and highG0 around if the model was an rseg as it messes up plotting
thresh_data = thresh_data %>% mutate(newLowG0 = ifelse(model == "rseg", lowG0, 0),
                                     low_g0 = ifelse(model == "rseg", highG0, lowG0),
                                     high_g0 = ifelse(model == "rseg", newLowG0, highG0))


## We will model the position of the threholds using a beta regression since our
## response is bounded between  0 - 1
thresh_data = thresh_data %>% mutate(weightDiffG0 = log(1/diffG0), type = as.factor(type))

weighted.mean(thresh_data$G0, thresh_data$weightDiffG0)


## Average threshold for each taxonomic group

taxa_model = glmmTMB(G0 ~ taxa, data = thresh_data, weights = weightDiffG0, family = beta_family())
summary(taxa_model)

taxa_model_emmeans <- emmeans(taxa_model, specs = ~ taxa)
taxa_summary <- summary(taxa_model_emmeans, type = "response")
taxa_summary



#### Latitude and regional forest cover ------------------------

LatMod = glmmTMB(G0 ~ avg_lat * vert_invert, data = thresh_data, weights = weightDiffG0, family = beta_family())
summary(LatMod)


LatMod = glmmTMB(G0 ~ avg_lat * relevel(vert_invert, ref = "Vertebrates"), data = thresh_data, weights = weightDiffG0, family = beta_family())
summary(LatMod)


plot(thresh_data$G0 ~ thresh_data$avg_lat)


RegionalFCMod = glmmTMB(G0 ~ cover * vert_invert, data = thresh_data, weights = weightDiffG0, family = beta_family())
summary(RegionalFCMod)
save(RegionalFCMod, file = "results/SpeciesRichness/SpeciesRichness_RegionalFCMod_Position_model.Rdata")

plot(thresh_data$G0 ~ thresh_data$cover)



RegionalFCMod = glmmTMB(G0 ~ cover * relevel(vert_invert, ref = "Vertebrates"), data = thresh_data, weights = weightDiffG0, family = beta_family())
summary(RegionalFCMod)
