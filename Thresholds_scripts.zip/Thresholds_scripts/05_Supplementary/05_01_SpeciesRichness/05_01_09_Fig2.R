
#### Figure 2 - global variation in position of threshold ----------------------

library(dplyr)
library(sf)
library(ggplot2)
library(ggeffects)
library(viridis)


data <- read.csv("results/SpeciesRichness/Final_data_SpeciesRichness.csv")

thresh_data <- subset(data, relevant_threshold_YN == 1)


thresh_data$vert_invert <- ifelse(thresh_data$taxa == "Arthropods", "Invertebrates", "Vertebrates")

thresh_data$vert_invert <- as.factor(thresh_data$vert_invert)




##### Panel A - map ------------------------------------------------------------

load("data/processed/study_Geometries.RData")

centroids <- lapply(study_Plot_Points_sf, function(x) {
  st_centroid(sfheaders::sf_multipoint(st_coordinates(x)))
})

PIDs <- lapply(study_Plot_Points_sf, function(x) {
  unique(x$PID)
})

centroids_sf <- do.call(rbind, centroids)
PIDs <- do.call(rbind, PIDs)

centroids <- cbind(centroids_sf, PIDs)
colnames(centroids) <- c("id","pid","geometry")


thresh_data <- st_sf(left_join(thresh_data, centroids, by = "pid"))

world <- map_data('world') %>% 
  as_tibble()

thresh_data$Site_Longitude_x_wgs84 <- st_coordinates(thresh_data)[,1]
thresh_data$Site_Latitude_y_wgs84 <- st_coordinates(thresh_data)[,2]



thresh_position_map <- ggplot() +
  geom_polygon(data=world, 
               aes(long, lat, group = group), colour=NA, fill='#C8C8C8', size=0) +#
  coord_map('mollweide', ylim = c(-60, 90), xlim = c(-180, 180)) +
  theme_void() +
  theme(panel.grid = element_blank(), 
        panel.border = element_blank(),
        axis.ticks = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        legend.position = c(0.2,0.3),
        legend.text = element_text(size = 16),
        legend.title = element_text(size = 16),
        legend.background = element_blank(),
        plot.margin = margin(0.5,0.5,0.5,0.5, "cm")) +
  scale_x_continuous(breaks = seq(-180, 180, by = 30), 
                     minor_breaks = seq(-180, 180, by = 10)) +
  scale_y_continuous(breaks = seq(-60, 90, by = 30), 
                     minor_breaks = seq(-60, 90, by = 10)) +
  geom_point(data = thresh_data, aes(x = Site_Longitude_x_wgs84, y = Site_Latitude_y_wgs84, colour = G0),  size = 3) +
  scale_colour_viridis(direction = -1, breaks = c(0, 0.25, 0.5, 0.75, 1), name = "Threshold \nposition",
                       labels = c("0%", "25%", "50%", "75%", "100%"), limits = c(0, 1))

thresh_position_map
ggsave(thresh_position_map, filename = "figures/SpeciesRichness/thresh_position_map.jpg", width = 25, height = 28, units = "cm")


##### Panel B - boxplot --------------------------------------------------------

thresh_data <- st_drop_geometry(thresh_data)


taxa_boxplot <- ggplot(thresh_data, aes(x = vert_invert, y = G0)) +
  geom_boxplot(width = 0.5, outliers = F) +
  geom_jitter(aes(colour = G0), width = 0.2, alpha = 0.7) +
  scale_colour_viridis(direction = -1) +
  labs(x = "",  y = "Threshold position") +
  scale_y_continuous(labels = scales::percent, breaks = c(0,0.2,0.4,0.6,0.8,1),
                     limits = c(0,1)) +
  theme_classic() +
  theme(axis.text = element_text(size = 13, colour = "black"),
        axis.title = element_text(size = 13),
        legend.position = "none")
taxa_boxplot



thresh_data$temp_trop <- ifelse(thresh_data$avg_lat > 23.5, "Temperate", "Tropical")

temp_trop_boxplot <- ggplot(thresh_data, aes(x = temp_trop, y = G0)) +
  geom_boxplot(width = 0.5, outliers = F) +
  geom_jitter(aes(colour = G0), width = 0.2, alpha = 0.7) +
  scale_colour_viridis(direction = -1) +
  labs(x = "",  y = "Threshold position") +
  scale_y_continuous(labels = scales::percent, breaks = c(0,0.2,0.4,0.6,0.8,1),
                     limits = c(0,1)) +
  theme_classic() +
  theme(axis.text = element_text(size = 13, colour = "black"),
        axis.title = element_text(size = 13),
        legend.position = "none")
temp_trop_boxplot


boxplot <- cowplot::plot_grid(taxa_boxplot, temp_trop_boxplot, nrow = 1, align = "vh")
boxplot

ggsave(boxplot, filename = "figures/SpeciesRichness/boxplot.jpg", width = 18, height = 7, units = "cm")





##### Panel C - latitude and regional forest cover graph ----------------------

load("results/SpeciesRichness/SpeciesRichness_RegionalFCMod_Position_model.Rdata")




## Swap lowG0 and highG0 around if the model was an rseg as it messes up plotting
thresh_data = thresh_data %>% mutate(newLowG0 = ifelse(model == "rseg", lowG0, 0),
                                     low_g0 = ifelse(model == "rseg", highG0, lowG0),
                                     high_g0 = ifelse(model == "rseg", newLowG0, highG0))


## We will model the position of the threholds using a beta regression since our
## response is bounded between  0 - 1
thresh_data = thresh_data %>% mutate(weightDiffG0 = log(1/diffG0), type = as.factor(type))


thresh_data$pred <- predict(RegionalFCMod, thresh_data, type = "response")
thresh_data$pred_se <- predict(RegionalFCMod, thresh_data, se.fit = T, type = "response")[[2]]
thresh_data$pred_lci <- thresh_data$pred - (1.96 * thresh_data$pred_se)
thresh_data$pred_uci <- thresh_data$pred + (1.96 * thresh_data$pred_se)



regionalFC_Plot = ggplot(data = thresh_data) +
  geom_pointrange(aes(x = cover, y = G0, ymin = low_g0, ymax = high_g0, 
                      colour = G0), size = 0.8, linewidth = 1,
                  alpha = 0.8) +
  facet_wrap(~vert_invert, nrow = 2) +
  geom_line(aes(x = cover, y = pred, group = vert_invert), size = 0.9, linewidth = 1) +
  geom_ribbon(aes(x = cover, ymin = pred_lci, ymax = pred_uci, group = vert_invert), alpha = 0.15) +
  scale_colour_viridis(direction = -1, breaks = c(0, 0.25, 0.5, 0.75, 1), name = "Threshold \nposition",
                       labels = c("0%", "25%", "50%", "75%", "100%"), limits = c(0, 1)) +
  theme_classic() +
  scale_x_continuous(limits = c(0,1)) +
  scale_y_continuous(labels = scales::percent, breaks = c(0,0.2,0.4,0.6,0.8,1)) +
  labs(x = "Regional forest cover", y = "Threshold position", col = "Latitude") +
  theme(axis.text = element_text(size = 13, colour = "black"),
        legend.position = "none",
        axis.title = element_text(size = 13),
        strip.text = element_text(hjust = 0, size = 13),
        strip.background = element_blank(),
        panel.spacing = unit(1, "lines"))
regionalFC_Plot

ggsave(regionalFC_Plot, filename = "figures/SpeciesRichness/regionalFC_Plot.png", width = 12, height = 16, units = "cm")


