#### Prep data to test for community composition (PCoA) thresholds

library(tidyverse)
library(janitor)
library(vegan)

data <- read.csv("data/processed/formattedSpecOcc_fp70.csv")

# remove local scale 50 m buffer
data <- subset(data, buffer != 50)


## Remove all plots that do not contain any species (occurrence == 0)
## as you can't compare community composition of plots without any community
sumOcc = data %>%
  group_by(pid, plot_id) %>%
  summarise(sumOcc = sum(occurrence))

data = data %>%
  left_join(sumOcc, join_by(pid, plot_id)) %>%
  filter(sumOcc > 0) %>%
  dplyr::select(-sumOcc)

## to keep teh data structure consistent, we'll do this separately for each buffer within each PID, even though the community composition (PCoA) will be the same

## Convert to wide format for use in similarity calculations
specWide_list <-  data %>%
  dplyr::select(pid, plot_id, buffer, species, taxa, occurrence) %>%
  group_by(pid, plot_id, buffer, species) %>%
  summarise(occurrence = sum(occurrence, na.rm = TRUE), .groups = "drop") %>%  
  group_split(pid, buffer) 


pivot <- function(data){
  pivoted_i <- pivot_wider(data, names_from = species, values_from = occurrence) %>%
    distinct(plot_id, .keep_all = TRUE) %>%  # Ensure unique 'plot'
    column_to_rownames("plot_id")
  return(pivoted_i)
}

specWide <- lapply(specWide_list, pivot)

## Calculate sorensen dissimilarity between control sites
dissimilarity = specWide %>%
  map(~list(pid = .$pid[[1]], buffer = .$buffer[[1]], 
            dissimilarity = vegdist(.[, 3:ncol(.)], method = "bray", binary = TRUE)))


## Perform PCoA and extract first axis
pcoa <- function(pid_buffer_data) {
  output <- tryCatch({
    pcoa_axis1 <- cmdscale(pid_buffer_data$dissimilarity, k = 1)[, 1]
    
    data.frame(
      pid        = unique(pid_buffer_data$pid),
      buffer     = unique(pid_buffer_data$buffer),
      plot_id    = names(pcoa_axis1),
      pcoa_axis1 = pcoa_axis1
    )
  }, error = function(e) NULL)  # return NULL if cmdscale fails
  
  return(output)
}

pcoa_data <- lapply(dissimilarity, pcoa)

pcoa_data <- pcoa_data[sapply(pcoa_data, class) == "data.frame"] %>%
  bind_rows()


## Load in forest cover data
## choose only forest (class == 1)
## and clean and rename columns
forest = read_csv("data/processed/percentage_Forest_Cover70.csv", locale = readr::locale(encoding = "latin1")) %>%
  filter(class == 1) %>%
  clean_names() %>% 
  dplyr::select(pid, buffer, plot_id, value) %>%
  rename(forest_cover = value)


## Change forest cover to be between 0 - 1
forest = forest %>% mutate(forest_cover = forest_cover/100)

## Join with data
pcoa_data = left_join(pcoa_data, forest, join_by(pid == pid, plot_id == plot_id, buffer == buffer))


write_csv(pcoa_data, "data/processed/CommunityComposition/CommunityComposition_PCoA_fp70.csv")

