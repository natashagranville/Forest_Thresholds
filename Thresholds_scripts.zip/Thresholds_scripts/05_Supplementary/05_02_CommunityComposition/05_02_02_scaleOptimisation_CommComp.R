#### Choose scale of effect for pcoa --------------

## run piecewise models at all scales and choose the scale with the highest R2

library(tidyverse)
library(janitor)
library(segmented)
library(piecewiseSEM)


data <- read_csv("data/processed/CommunityComposition/CommunityComposition_PCoA_fp70.csv")


split_by_pid_and_buffer <- group_split(data, pid, buffer)



for(i in 1:length(split_by_pid_and_buffer)){
  
  tryCatch({
    
    x <- split_by_pid_and_buffer[[i]]
    
    print(paste0(x$pid[[1]], " ", x$buffer[[1]]))
    
    
    ## Create negative forest cover to use in null right slope models
    x$negative_forest_cover <- -x$forest_cover
    
    lin = lm(pcoa_axis1 ~ forest_cover, data = x)
    
    ## Create new models with forest cover removed for null slope tests
    nullLin = update(lin, . ~ . -forest_cover)
    
    
    rseg = segmented(nullLin, seg.Z = ~negative_forest_cover, data = x)
    
    
    
    out = data.frame(pid = x$pid[[1]], buffer = x$buffer[[1]], r2 = summary(rseg)$r.squared, segAIC = AIC(rseg), linAIC = AIC(lin))
    
    
    write.csv(out, paste0("data/processed/CommunityComposition/CommunityComposition_scaleOfEffect_fp70", "/", unique(x$pid), "_", unique(x$buffer), ".csv"))
    
  }, error = function(e) {
    print(paste("Error:", conditionMessage(e), "\n"))
    
  })
  
  
  rm(list = setdiff(ls(), c("split_by_pid_and_buffer", "cutOff_value", "data")))
  
  
  
}





files <- list.files("data/processed/CommunityComposition/CommunityComposition_scaleOfEffect_fp70", full = T)
scale_data <- data.frame()
scale_data_study <- data.frame()
for (i in 1:length(files)){
  file <- files[i]
  print(file)
  scale_data_study <- read_csv(file, show_col_types = FALSE)
  scale_data <- rbind(scale_data, scale_data_study)
}



## Find best scale of effect per PID

split_by_pid <- split(data, data$pid)

filter_scale <- function(pid_data){
  
  pid <- unique(pid_data$pid)
  
  if(pid %in% scale_data$pid){
    
    pid_scale <- scale_data[scale_data$pid == pid,]
    
    pid_best_scale <- pid_scale[which.max(pid_scale$r2),]$buffer
    
    print(pid_best_scale)
    pid_best_scale_data <- pid_data[pid_data$buffer == pid_best_scale,]
    
    return(pid_best_scale_data)
    
  }
  
  
}


best_scale_data <- lapply(split_by_pid, filter_scale) %>%
  bind_rows()


write.csv(best_scale_data, "data/processed/CommunityComposition/CommunityComposition_scaleOptimised_Model_data_fp70.csv", row.names = F)
