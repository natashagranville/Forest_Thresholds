##### Compare models to identify significant thresholds --------------------------

library(tidyverse)
library(performance)

files <- list.files(path = "results/CommunityComposition_PCoA/Models_CommComp", full.names = TRUE)

Models <- list()
for(i in 1:length(files)){
  load(files[[i]])
  Models[[i]] <- out
}

## Number of studies we successfully ran some models for
Models %>% length()

# Get AIC for each model in each list item
# and put into a data frame
getAIC = function(x) {
  if(length(x) > 1) {
    lin = AIC(x$lin)
    rseg = tryCatch(AIC(x$rseg), error = function(e) NA)
    return(data.frame(pid = x$pid, lin = lin, rseg = rseg))
  }
}

aic <- lapply(Models, getAIC) %>%
  bind_rows()

## What is the top model for each study 
aic <- aic %>%
  pivot_longer(cols = -pid, names_to = "model", values_to = "aic") %>%
  group_by(pid) %>%
  slice_min(aic, with_ties = F)



## Load in scale data to combine with aic and save
bestScale <- read_csv("data/processed/CommunityComposition/CommunityComposition_scaleOptimised_Model_data_fp70.csv") %>%
  distinct(pid, buffer)


## cases where >1 optimal scale was identified
bestScale <- bestScale[-which(duplicated(bestScale$pid)),]

aic <- left_join(aic, bestScale)


## Which models best describe each study relationship
aic %>% group_by(model) %>% count() 



## Now check the single breakpoint models for differences in slope
## based on confidence intervals
# x <- Models[[1]]
# y <- aic$model[1]

checkSlopes = function(x, y) {
  
  tryCatch({
    
    print(x$pid[[1]])
    
    mod = x[y][[1]]
    
    if(y == "lin"){
      
      type <- "lin"
      
      out <- data.frame(pid = x$pid, model = y, type = type, G0 = NA, lowG0 = NA, highG0 = NA,
                        lowU = NA, highU = NA) %>%
        mutate(diffG0 = NA, diffU = NA)
      
    } else if(y == "rseg") {
      
      conf <- confint.lm(mod, level = 0.95) %>% t() %>%
        as.data.frame() %>%
        rename("G0" = "psi1.negative_forest_cover", "U" = "U1.negative_forest_cover")
      
      confU <- conf[,'U']
      
      
      ## Check if difference in slopes crosses zero
      ## if it doesn't it's significant
      if(sign(confU[[1]]) == sign(confU[[2]])) {
        if(sign(confU[[1]]) == 1) {
          type <- "increasing_below_thresh"
        } else if(sign(confU[[1]]) == -1) {
          type <- "declining_below_thresh"
        }
        
        # Get CIs of threshold
        confG0 = -conf[,"G0"]
        
        if(length(mod$call) > 4) {
          thresh = -mod$lme.fit$coefficients$fixed["G0"]
        } else {
          thresh = -mod$psi[,"Est."]
          confG0[[1]] = thresh + confG0[[1]]
          confG0[[2]] = thresh + confG0[[2]]
        }
        
        out <- data.frame(pid = x$pid, model = y, type = type,
                          G0 = thresh, lowG0 = confG0[[1]], highG0 = confG0[[2]],
                          lowU = confU[[1]], highU = confU[[2]]) %>%
          mutate(diffG0 = abs(highG0 - lowG0), diffU = abs(highU - lowU))
        
        # If the segmented model fit best, but the difference in slopes was not significant
      } else if(sign(confU[[1]]) != sign(confU[[2]])) {
        
        type = "nonSig_rseg"
        
        out = data.frame(pid = x$pid, model = y, type = type, 
                         G0 = NA, lowG0 = NA, highG0 = NA,
                         lowU = NA, highU = NA) %>%
          mutate(diffG0 = NA, diffU = NA)
      }
      
    }
    
    # adjusted R2 of model, using performance package
    out$r2 <- as.numeric(r2(mod)[2])
    
    return(out)
    
    
  }
  , error = function(e) {
    print(paste("Error:", conditionMessage(e), "\n"))
    
  })
  
  
}

results <- mapply(x = Models, y = aic$model, FUN = checkSlopes, SIMPLIFY = FALSE) 

results <- results[sapply(results, class) == "data.frame"]

results <- bind_rows(results)

results %>% group_by(type) %>% count() 

write_csv(results, "results/CommunityComposition_PCoA/CommComp_thresh_model_results.csv")


