#### Combine model data and prep for statistical analysis of threshold presence and posiiton -----------------

library(tidyverse)
library(janitor)
library(units)
library(sf)


data <- read.csv("results/CommunityComposition_PCoA/CommComp_thresh_model_results.csv")

data %>% group_by(type) %>% summarise(n())

data$relevant_threshold_YN <- ifelse(data$type == "declining_below_thresh" | data$type == "increasing_below_thresh" , 1, 0)

## Get explanatory variables for analysis 

regionalForest <- read.csv("data/processed/regional_Forest_Cover.csv") %>%
  clean_names()

load("data/processed/study_Geometries.RData")
avgLat = study_Plot_Points_sf %>% map2(.,., ~st_coordinates(.x) %>% as.data.frame() %>% add_column(PID = .y$PID)) %>% 
  bind_rows() %>% group_by(PID) %>% summarise(avg_Lat = abs(mean(Y))) %>%
  clean_names()

## Join up with data quality
final_data = left_join(data, avgLat, by = "pid")
final_data = left_join(final_data, regionalForest[,c("cover", "pid")], by = "pid")


## Load in taxa data and join with data quality
taxa = read_csv("data/processed/taxa_PID_Lookup.csv") %>%
  clean_names() %>%
  dplyr::select(c(pid, taxa, realm))

final_data = left_join(final_data, taxa[,c("pid", "taxa", "realm")], by = "pid")


final_data <- subset(final_data, !is.na(final_data$cover))


## Regional deforestation 
final_data$deforest <- 1 - final_data$cover


## Range of forest cover
dataQuality <- read.csv("data/processed/dataQuality_fp70.csv")


bestScale <- read.csv("data/processed/CommunityComposition/CommunityComposition_scaleOptimised_Model_data_fp70.csv")

sum(unique(dataQuality$pid) %in% unique(bestScale$pid))
sum(unique(bestScale$pid) %in% unique(dataQuality$pid))

filter_scale <- function(pid_data){
  
  pid <- unique(pid_data$pid)
  
  pid_scale <- unique(bestScale[bestScale$pid == pid,]$buffer)
    
  pid_best_scale_dataQuality <- pid_data[pid_data$buffer == pid_scale,]
    
  return(pid_best_scale_dataQuality)
     
}

dataQuality <- lapply(split(dataQuality, dataQuality$pid), filter_scale) %>%
  bind_rows()

final_data <- left_join(final_data, dataQuality)


# Filter out sites with <30% range of forest cover
final_data <- subset(final_data, !is.na(final_data$forestRange))
min(final_data$forestRange)



compositional_intactness_data <- read.csv("results/FinalData_fp70.csv")

final_data <- subset(final_data, pid %in% compositional_intactness_data$pid)


##### Look at key info --------------------------------------------------------

# how many studies in total?
length(unique(final_data$pid))

# how many studies with relevant thresholds?
final_data_thresh <- subset(final_data, relevant_threshold_YN == 1)
length(unique(final_data_thresh$pid))

# how many studies in total for each taxa?
final_data %>% group_by(taxa) %>% summarise(length(unique(pid)))

# how many studies with thresholds for each taxa?
final_data_thresh %>% group_by(taxa) %>% summarise(length(unique(pid)))

# of the non-threshold studies, how many were non sig reg, how many were linear?
final_data %>% group_by(type) %>% summarise(n())

# threshold positions
min(final_data_thresh$G0, na.rm = T)
max(final_data_thresh$G0, na.rm = T)
mean(final_data_thresh$G0, na.rm = T)
median(final_data_thresh$G0, na.rm = T)


write.csv(final_data, "results/CommunityComposition_PCoA/Final_data_CommunityComposition.csv")


