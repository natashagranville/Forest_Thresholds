
library(emmeans)
library(tidyverse)
library(glmmTMB)
library(sjPlot)

data <- read.csv("results/CommunityComposition_PCoA/Final_data_CommunityComposition.csv")

data %>% group_by(type) %>% summarise(n())

data$realm[data$realm == "Oceania"] <- "Australasia"


## How many of each type?
data %>% group_by(type) %>% summarise(n())

taxa_model <- glmmTMB(relevant_threshold_YN ~ taxa, data = data, family = "binomial")
summary(taxa_model)

taxa_model_emmeans <- emmeans(taxa_model, specs = ~ taxa)
taxa_summary <- summary(taxa_model_emmeans, type = "response")
taxa_summary

## Number of sites
nSites_model <- glmmTMB(relevant_threshold_YN ~ nSites, data = data, family = binomial)
summary(nSites_model)

save(nSites_model, file = "results/CommunityComposition_PCoA/CommunityComposition_nSites_model.Rdata")

## Latitude
lat_model <- glmmTMB(relevant_threshold_YN ~ avg_lat, data = data, family = binomial)
summary(lat_model)

## Regional deforestation
regionalFC_model <- glmmTMB(relevant_threshold_YN ~ cover, data = data, family = binomial)
summary(regionalFC_model)

save(regionalFC_model, file = "results/CommunityComposition_PCoA/CommunityComposition_regionalFC_model.Rdata")

## Range of forest cover
forestRange_model <- glmmTMB(relevant_threshold_YN ~ forestRange, data = data, family = binomial)
summary(forestRange_model)

