
library(emmeans)
library(tidyverse)
library(glmmTMB)
library(sjPlot)

data <- read.csv("results/CommunityComposition_PCoA/Final_data_CommunityComposition.csv")



thresh_data <- subset(data, relevant_threshold_YN == 1)

min(thresh_data$G0, na.rm = T)
max(thresh_data$G0, na.rm = T)
mean(thresh_data$G0, na.rm = T)
median(thresh_data$G0, na.rm = T)



## Swap lowG0 and highG0 around if the model was an rseg as it messes up plotting
thresh_data = thresh_data %>% mutate(newLowG0 = ifelse(model == "rseg", lowG0, 0),
                                     low_g0 = ifelse(model == "rseg", highG0, lowG0),
                                     high_g0 = ifelse(model == "rseg", newLowG0, highG0))


## We will model the position of the threholds using a beta regression since our
## response is bounded between  0 - 1
thresh_data = thresh_data %>% mutate(weightDiffG0 = log(1/diffG0), type = as.factor(type))

weighted.mean(thresh_data$G0, thresh_data$weightDiffG0)


## Average threshold for each taxonomic group

taxa_model = glmmTMB(G0 ~ taxa, data = thresh_data, weights = weightDiffG0, family = beta_family())
summary(taxa_model)

taxa_model_emmeans <- emmeans(taxa_model, specs = ~ taxa)
taxa_summary <- summary(taxa_model_emmeans, type = "response")
taxa_summary


#### Latitude * regional deforestation ------------------------

LatMod = glmmTMB(G0 ~ avg_lat, data = thresh_data, weights = weightDiffG0, family = beta_family())
summary(LatMod)


save(LatMod, file = "results/CommunityComposition_PCoA/CommunityComposition_Lat_Position_model.Rdata")



DeforestMod = glmmTMB(G0 ~ deforest, data = thresh_data, weights = weightDiffG0, family = beta_family())
summary(DeforestMod)

save(DeforestMod, file = "results/CommunityComposition_PCoA/CommunityComposition_deforest_Position_model.Rdata")
