#### Figure 1 - probability of detecting a threshold ---------------------------

library(cowplot)
library(emmeans)
library(ggeffects)
library(glmmTMB)
library(janitor)
library(segmented)
library(sf)
library(tidyverse)

final_data <- read.csv("results/CommunityComposition_PCoA/Final_data_CommunityComposition.csv")

data <- read.csv("data/processed/CommunityComposition/CommunityComposition_scaleOptimised_Model_data_fp70.csv")

##### Panel A - graph showing all linear and threshold relationships --------------

files <- list.files(path = "results/CommunityComposition_PCoA/Models_CommComp", full.names = TRUE)
Models <- list()
for(i in 1:length(files)){
  load(files[[i]])
  Models[[i]] <- out
}

## Load in similarity data for plotting
data = data %>%
  left_join(final_data) 

data %>% group_by(type) %>% summarise(length(unique(pid)))

split_by_pid <- split(data, data$pid)

pid_data <- split_by_pid[[1]]

get_pred <- function(pid_data){
  
  tryCatch({
    
  pred_data <- NULL
  
  PID <- unique(pid_data$pid)
  
  if(PID %in% sapply(Models,"[[",1)){
    
    print(PID)
    
    pid_data <- subset(data, pid == PID)
    
    pid_models <- Models[[which(sapply(Models,"[[",1) %in% PID)]] 
    
    stopifnot(pid_models$pid == PID)
    
    if(sign(coef(pid_models$lin)[2]) == 1){
      
      invert <- FALSE
      lin <- pid_models$lin
      rseg <- pid_models$rseg
      
    } else{
      
      invert <- TRUE
      # Refit model with inverted response
      pid_data$inverted_pcoa_axis1 <- -pid_data$pcoa_axis1
      lin <- lm(inverted_pcoa_axis1  ~ forest_cover, data = pid_data)
      nullLin <- update(lin, . ~ . -forest_cover)
      pid_data$negative_forest_cover <- -pid_data$forest_cover
      rseg <- segmented(nullLin, seg.Z = ~negative_forest_cover, data = pid_data)
      
    }
    
    ## Threshold models
    if(unique(pid_data$type) == "increasing_below_thresh" | unique(pid_data$type) == "declining_below_thresh"){
      
      pred_data <- data.frame(forest_cover = pid_data$forest_cover)
      
      pred_data$negative_forest_cover <- -pred_data$forest_cover
      
      pred_data$pred <- predict(rseg, pred_data)
      
      
      pred_data$G0 <- -rseg$psi[[2]]
     
      pred_data$G0_pred <- predict(rseg, data.frame(forest_cover = unique(pred_data$G0),
                                                    negative_forest_cover = -unique(pred_data$G0)))
      
      pred_data$relevant_threshold_YN <- 1
      
      
      extra_row_for_threshold <- data.frame(forest_cover = unique(pred_data$G0),
                                            negative_forest_cover = - unique(pred_data$G0),
                                            pred = unique(pred_data$G0_pred),
                                            G0 = unique(pred_data$G0),
                                            G0_pred = unique(pred_data$G0_pred),
                                            relevant_threshold_YN = unique(pred_data$relevant_threshold_YN))
      
      pred_data <- rbind(pred_data, extra_row_for_threshold)
      
      
    } else if(unique(pid_data$type) == "nonSig_rseg"){
      
      
      pred_data <- data.frame(forest_cover = pid_data$forest_cover)
      
      pred_data$negative_forest_cover <- -pred_data$forest_cover
      
      pred_data$pred <- predict(rseg, pred_data)
      
      pred_data$G0 <- NA
      
      pred_data$G0_pred <- NA
      
      pred_data$relevant_threshold_YN <- 0
      
      
    } else if (unique(pid_data$type) == "lin"){
      
      pred_data <- data.frame(forest_cover = pid_data$forest_cover)
      
      pred_data$negative_forest_cover <- -pred_data$forest_cover
      
      pred_data$pred <- predict(lin, pred_data)
      
      pred_data$G0 <- NA
      
      pred_data$G0_pred <- NA
      
      pred_data$relevant_threshold_YN <- 0
      
    }
    
    pred_data$pid <- PID
    
    
    return(pred_data)
  } 
  
  }, error = function(e) NULL)  
  
}



pred_data_list <- lapply(split_by_pid, get_pred)


pred_data_list <- pred_data_list[sapply(pred_data_list, class) == "data.frame"]

pred_data <- bind_rows(pred_data_list)

pred_data <- pred_data[!is.na(pred_data$relevant_threshold_YN),]





facet_labels <- as_labeller(c("0" = 'No relevant threshold identified',
                              "1" = 'Relevant threshold identified'))

commComp_all_slopes_plot <- ggplot(pred_data, aes(x = forest_cover, y = pred, group = pid, colour = as.factor(relevant_threshold_YN))) +
  geom_line(alpha = 0.6) +
  facet_wrap(~relevant_threshold_YN, labeller = facet_labels) +
  geom_point(data = filter(pred_data, relevant_threshold_YN == 1),
             aes(x = G0, y = G0_pred),
             fill = "#6a51a3", size = 2.5, alpha = 0.8, shape = 20) +
  scale_colour_manual(values = c("orange", "#6a51a3")) +
  labs(x = "Forest cover", y = "Community composition (PCoA axis 1)") +
  scale_x_continuous(labels = scales::percent) +
  #ylim(c(0,2)) +
  theme_classic() +
  theme(legend.title = element_blank(),
        legend.position = "none",
        #panel.spacing = unit(2, "lines"),
        strip.text = element_text(size = 17),
        #plot.margin = unit(c(0.5,1,0.5,0.5), "cm"), 
        plot.margin = unit(c(0,0.5,0,0), "cm"),
        strip.background = element_blank(),
        axis.text = element_text(colour = "black", size = 17),
        axis.title = element_text(size = 17))
commComp_all_slopes_plot




##### Panel B - maps --------------------------------------------------------
data  <- read.csv("results/CommunityComposition_PCoA/Final_data_CommunityComposition.csv")

load("data/processed/study_Geometries.RData")


centroids <- lapply(study_Plot_Points_sf, function(x) {
  st_centroid(sfheaders::sf_multipoint(st_coordinates(x)))
})

PIDs <- lapply(study_Plot_Points_sf, function(x) {
  unique(x$PID)
})

centroids_sf <- do.call(rbind, centroids)
PIDs <- do.call(rbind, PIDs)

centroids <- cbind(centroids_sf, PIDs)
colnames(centroids) <- c("id","pid","geometry")


data <- st_sf(left_join(data, centroids, by = "pid"))

world <- map_data('world') %>% 
  as_tibble()

data <- data[!duplicated(data),]

data$Site_Longitude_x_wgs84 <- st_coordinates(data)[,1]
data$Site_Latitude_y_wgs84 <- st_coordinates(data)[,2]


## noThresh studies map
noThresh_studies <- subset(data, relevant_threshold_YN == 0)
noThresh_studies_map <- ggplot() +
  geom_polygon(data=world, 
               aes(long, lat, group = group), colour=NA, fill='#C8C8C8', size=0) +#
  coord_map('mollweide', ylim = c(-60, 90), xlim = c(-180, 180)) +
  theme_void() +
  theme(panel.grid = element_blank(), 
        panel.border = element_blank(),
        axis.ticks = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        legend.title = element_blank(),
        legend.position = c(0.2,0.3),
        legend.text = element_text(size = 16),
        legend.background = element_blank(),
        plot.margin = margin(0.5,0.5,0.5,0.5, "cm")) +
  scale_x_continuous(breaks = seq(-180, 180, by = 30), 
                     minor_breaks = seq(-180, 180, by = 10)) +
  scale_y_continuous(breaks = seq(-60, 90, by = 30), 
                     minor_breaks = seq(-60, 90, by = 10)) +
  geom_point(data = noThresh_studies, aes(x = Site_Longitude_x_wgs84, y = Site_Latitude_y_wgs84), fill = "orange", colour = "orange", size = 3) +
  scale_shape_manual(values = c(21, 22, 24, 25))
noThresh_studies_map
ggsave(noThresh_studies_map, filename = "figures/CommunityComposition/CommunityComposition_no_relevant_thresh_studies_map.jpg", height = 25, width = 28, units = "cm")



thresh_studies <- subset(data, relevant_threshold_YN == 1)

thresh_studies_map <- ggplot() +
  geom_polygon(data=world, 
               aes(long, lat, group = group), colour=NA, fill='#C8C8C8', size=0) +#
  coord_map('mollweide', ylim = c(-60, 90), xlim = c(-180, 180)) +
  theme_void() +
  theme(panel.grid = element_blank(), 
        panel.border = element_blank(),
        axis.ticks = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        legend.title = element_blank(),
        legend.position = c(0.2,0.3),
        legend.text = element_text(size = 16),
        legend.background = element_rect(fill = NA),
        plot.margin = margin(0.5,0.5,0.5,0.5, "cm")) +
  scale_x_continuous(breaks = seq(-180, 180, by = 30), 
                     minor_breaks = seq(-180, 180, by = 10)) +
  scale_y_continuous(breaks = seq(-60, 90, by = 30), 
                     minor_breaks = seq(-60, 90, by = 10)) +
  geom_point(data = thresh_studies, aes(x = Site_Longitude_x_wgs84, y = Site_Latitude_y_wgs84), fill = "#6a51a3", colour = "#6a51a3", size = 3) +
  scale_shape_manual(values = c(21, 22, 24, 25))
thresh_studies_map
ggsave(thresh_studies_map, filename = "figures/CommunityComposition/CommunityComposition_relevant_thresh_studies_map.jpg", height = 25, width = 28, units = "cm")


data_sum <- st_drop_geometry(data) %>% 
  group_by(relevant_threshold_YN, taxa) %>%
  summarise(count = n())


##### Panel C - doughnut plots for each taxonomic group ----------------------


arthro <- subset(data_sum, taxa == "Arthropods")
arthro$fraction <- arthro$count / sum(arthro$count)
arthro$ymax <- cumsum(arthro$fraction)
arthro$ymin <- c(0, head(arthro$ymax, n=-1))
arthro$labelPosition <- (arthro$ymax + arthro$ymin) / 2
arthro$label <- paste0(arthro$count)

arthro_plot <- ggplot(arthro, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=as.factor(relevant_threshold_YN))) +
  geom_rect() +
  geom_text(x=3.5, aes(y= labelPosition, label= label), size=7, fill = NA) +
  scale_fill_manual(values = c("orange", "#6a51a3")) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  ggtitle("Arthropods") +
  theme_void() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 18))
arthro_plot


bird <- subset(data_sum, taxa == "Birds")
bird$fraction <- bird$count / sum(bird$count)
bird$ymax <- cumsum(bird$fraction)
bird$ymin <- c(0, head(bird$ymax, n=-1))
bird$labelPosition <- (bird$ymax + bird$ymin) / 2
bird$label <- paste0(bird$count)

bird_plot <- ggplot(bird, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=as.factor(relevant_threshold_YN))) +
  geom_rect() +
  geom_text(x=3.5, aes(y= labelPosition, label= label), size=7, fill = NA) +
  scale_fill_manual(values = c("orange", "#6a51a3")) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  ggtitle("Birds") +
  theme_void() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 18))
bird_plot


herp <- subset(data_sum, taxa == "Herptiles")
herp$fraction <- herp$count / sum(herp$count)
herp$ymax <- cumsum(herp$fraction)
herp$ymin <- c(0, head(herp$ymax, n=-1))
herp$labelPosition <- (herp$ymax + herp$ymin) / 2
herp$label <- paste0(herp$count)

herp_plot <- ggplot(herp, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=as.factor(relevant_threshold_YN))) +
  geom_rect() +
  geom_text(x=3.5, aes(y= labelPosition, label= label), size=7, fill = NA) +
  scale_fill_manual(values = c("orange", "#6a51a3")) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  ggtitle("Herptiles") +
  theme_void() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 18))
herp_plot



mammal <- subset(data_sum, taxa == "Mammals")
mammal$fraction <- mammal$count / sum(mammal$count)
mammal$ymax <- cumsum(mammal$fraction)
mammal$ymin <- c(0, head(mammal$ymax, n=-1))
mammal$labelPosition <- (mammal$ymax + mammal$ymin) / 2
mammal$label <- paste0(mammal$count)

mammal_plot <- ggplot(mammal, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=as.factor(relevant_threshold_YN))) +
  geom_rect() +
  geom_text(x=3.5, aes(y= labelPosition, label= label), size=7, fill = NA) +
  scale_fill_manual(values = c("orange", "#6a51a3")) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  ggtitle("Mammals") +
  theme_void() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 18))
mammal_plot



##### Panel D - number of sites ----------------------------------------------

load("results/CommunityComposition_PCoA/CommunityComposition_nSites_model.Rdata")

nSites_pred <-  predict(nSites_model, data, type = 'response', re.form = NA, se.fit = T)

data$nSites_pred <- nSites_pred$fit
data$nSites_pred_LCI <- nSites_pred$fit - nSites_pred$se.fit
data$nSites_pred_UCI <- nSites_pred$fit + nSites_pred$se.fit

nSites_plot <- ggplot(data, aes(x = log10(nSites))) +
  geom_ribbon(aes(ymin = nSites_pred_LCI, ymax = nSites_pred_UCI), colour = "#C8C8C8", alpha = 0.3) +
  geom_line(aes(y = nSites_pred), linewidth = 1.2) +
  geom_point(aes(y = relevant_threshold_YN , colour = factor(relevant_threshold_YN )), 
             alpha = 0.75,  shape = 16,  position = position_jitter(width = 0, height = 0.05)) +
  scale_colour_manual(values = c("0" = "orange", "1" = "#6a51a3")) +
  theme_classic() +
  labs(x = expression(log[10]~(Number~of~sites)), y = "Probability of detecting a threshold") +
  theme(axis.text = element_text(size = 18, colour = "black"),
        axis.title = element_text(size = 18),
        legend.position = "none")
nSites_plot


##### Panel E -  regional forest cover ---------------
load("results/CommunityComposition_PCoA/CommunityComposition_regionalFC_model.Rdata")

regionalFC_pred <- ggpredict(regionalFC_model, terms = c('cover[all]'))

regionalFC_plot <- ggplot() +
  # Lines + ribbons
  geom_line(data = regionalFC_pred, aes(x = x, y = predicted), size = 1.2) +
  geom_ribbon(data = regionalFC_pred, aes(x = x, ymin = conf.low, ymax = conf.high),
              alpha = 0.3, colour = "#C8C8C8") +
  geom_point(data = data, aes(x = cover, y = relevant_threshold_YN, colour = factor(relevant_threshold_YN)),
             alpha = 0.75, shape = 16, position = position_jitter(width = 0, height = 0.05),
             show.legend = F) +
  scale_colour_manual(values = c("0" = "orange", "1" = "#6a51a3")) +
  theme_classic() +
  labs(x = "Regional forest cover", y = "Probability of detecting a threshold") +
  theme(axis.text = element_text(size = 18, colour = "black"),
        axis.title = element_text(size = 18),
        legend.text = element_text(size = 18),
        legend.title = element_text(size = 18),
        legend.background = element_blank(),
        legend.position = c(0.7,0.7))
regionalFC_plot


##### Combine panels -------------------------------------


all_taxa_plot <- cowplot:: plot_grid(arthro_plot, bird_plot, herp_plot, mammal_plot, align = "vh", nrow = 1)
all_taxa_plot

all_plot <- cowplot::plot_grid(commComp_all_slopes_plot, all_taxa_plot, nrow = 2, rel_heights = c(2,0.8))
all_plot



analyses_plot <- cowplot::plot_grid( nSites_plot, regionalFC_plot, align = "vh")
analyses_plot

final_plot <- cowplot::plot_grid(all_plot, analyses_plot, rel_heights = c(2,1), ncol = 1)
final_plot
ggsave(final_plot, filename = "figures/CommunityComposition/CommunityComposition_all_plot.jpg", width = 32, height = 32, units = "cm")


