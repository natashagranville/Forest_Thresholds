#### Sensitivity test using Jaccard dissimilarity index ------------------------

##### Run segmented models to look for thresholds ------------------------------

library(dplyr)
library(segmented)

data <- read.csv("data/processed/Jaccard_simDat_fp70.csv")


# use the optimal scale of effect that we identified previously

best_scale <- read.csv("results/FinalData_fp70.csv") %>%
  dplyr::select(c(pid, buffer))

data_split <- split(data, data$pid)

pid_data <- data_split[[1]]

select_best_scale <- function(pid_data){
  
  PID <- unique(pid_data$pid)
  
  pid_best_scale <- subset(best_scale, pid == PID)$buffer
  
  filtered_data <- subset(pid_data, buffer == pid_best_scale)
  
  return(filtered_data)
}

data <- lapply(data_split, select_best_scale) %>%
  bind_rows()


cutOff_value <- 70
split_by_pid <- group_split(data, pid)

for(i in 1:length(split_by_pid)){
  
  tryCatch({
    
    pid_data <- split_by_pid[[i]]
    
    pid <- unique(pid_data$pid)
    
    
    print(paste0("------- Running model at optimal scale for ", pid, " -------"))
    
    ## If 2+ control sites, use control site as a random intercept, and threshold
    
    if(length(unique(pid_data$control)) == 1) {
      
      ## If there is only one control site, use no random effects
      lin <- lm(jac ~ forest_cover + distance_km, data = pid_data)
      
    } else {    
      
      ## If >1 control sites, use control site as a random intercept
      lin <- lme(jac ~ forest_cover + distance_km, random = list(control = pdDiag(~1)), data = pid_data)
    }
    
    ## Create new models with forest cover removed for null slope tests
    nullLin <- update(lin, . ~ . -forest_cover)
    
    ## Create negative forest cover to use in null right slope models
    negative_forest_cover <- -pid_data$forest_cover
    
    ## Run right null slope only 
    ## Varying if there is random effects based on number of control sites (==1 or >1)
    
    if(length(unique(pid_data$control)) == 1) {
      
      ## If there is only one control site, use no random effects
      rseg = tryCatch(segmented(nullLin, seg.Z = ~negative_forest_cover, data = pid_data),
                      warning = function(w) {NA}, error = function(e) {NA})
      
    } else {
      
      ## If >1 control sites, use control site as a random effect
      rseg = tryCatch(segmented.lme(nullLin, seg.Z = ~negative_forest_cover, random = list(control = pdDiag(~1+G0)), data = pid_data),
                      warning = function(w) {NA}, error = function(e) {NA}) 
    }
    
    ## Build list for output
    out <- list(pid = pid, lin = lin, rseg = rseg)
    
    
    save(out, file = paste0("results/JacModels_fp", cutOff_value, "/", unique(pid_data$pid),".Rdata"))
    
    
    rm(list = setdiff(ls(), c("split_by_pid", "cutOff_value")))
    
  }
  , error = function(e) {
    print(paste("Error:", conditionMessage(e), "\n"))
    
  })
  
}

