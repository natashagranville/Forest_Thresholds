#### Jaccard sensitivity test ----------------------------------------------------
##### Compare models to identify significant thresholds --------------------------

library(tidyverse)
library(performance)

## Load in models
cutOff_value <- 70

files <- list.files(path = paste0("results/JacModels_fp", cutOff_value), pattern = "\\.Rdata$", full.names = TRUE)

jacModels <- list()
for(i in 1:length(files)){
  load(files[[i]])
  jacModels[[i]] <- out
}

## Number of studies we successfully ran some models for
jacModels %>% length()

# Get AIC for each model in each list item
# and put into a data frame
getAIC = function(x) {
  if(length(x) > 1) {
    lin = AIC(x$lin)
    rseg = tryCatch(AIC(x$rseg), error = function(e) NA)
    return(data.frame(pid = x$pid, lin = lin, rseg = rseg))
  }
}


aic = lapply(jacModels, getAIC) %>%
  bind_rows()

## What is the top model for each study (only including 1 break point models)
aic = aic %>%
  pivot_longer(cols = -pid, names_to = "model", values_to = "aic") %>%
  group_by(pid) %>%
  slice_min(aic, with_ties = F)

## Load in scale data to combine with aic and save
bestScale = read_csv(paste0("data/processed/bestScaleSimDat_fp", cutOff_value, ".csv")) %>%
  distinct(pid, buffer)


## cases where >1 optimal scale was identified
bestScale <- bestScale[-which(duplicated(bestScale$pid)),]

aic = left_join(aic, bestScale)

write.csv(aic, paste0("results/jacAIC_fp", cutOff_value, ".csv"), row.names = FALSE)

## Which models best describe each study relationship
aic %>% group_by(model) %>% count() 


## Now check the single breakpoint models for differences in slope
## based on confidence intervals
# x <- sorModels[[1]]
# y <- aic$model[1]

checkSlopes = function(x, y) {
  
  print(x$pid[[1]])
  
  mod = x[y][[1]]
  
  if(y == "lin"){
    
    type = "lin"
    
    # # Get R2
    # if(class(mod) == "lme") {
    #   #piecewise SEM package for mixed effects models
    #   r2 <- rsquared(mod)$Marginal
    # } else{
    #   # performance package if there are no random effects
    #   r2 <- as.numeric(r2(mod)[2])
    # }
    
    out = data.frame(pid = x$pid, model = y, type = type, G0 = NA, lowG0 = NA, highG0 = NA,
                     lowU = NA, highU = NA) %>%
      mutate(diffG0 = NA, diffU = NA)
    
  } else if(y == "rseg") {
    
    ## Check if model includes random effects (call > 4 if it is)
    if(length(mod$call) > 4) {
      conf = confint(mod, level = 0.95)
      confU = conf[,'U']
      
    } else if(length(mod$call) <= 4) {
      conf = confint.lm(mod, level = 0.95) %>% t() %>%
        as.data.frame() %>%
        rename("G0" = "psi1.negative_forest_cover", "U" = "U1.negative_forest_cover")
      confU = conf[,'U']
    }
    
    
    ## Check if difference in slopes crosses zero
    ## if it doesn't it's significant
    if(sign(confU[[1]]) == sign(confU[[2]])) {
      
      if(sign(confU[[1]]) == 1) {
        
        type = "increasing_integrity_below_thresh"
        
        confG0 = -conf[,"G0"]
        
      } else if(sign(confU[[1]]) == -1) {
        
        type = "declining_integrity_below_thresh"
        
        
        confG0 = -conf[,"G0"]
        
        # Bootstrap the 95% CIs for the threshold
        #boot_conf <- confint(mod, B=1000, parallel = "snow", ncpus = 4)
        
        # Get CIs of threshold
        #confG0 = -boot_conf[,"G0"]
        
      }
      
      
      if(length(mod$call) > 4) {
        thresh = -mod$lme.fit$coefficients$fixed["G0"]
      } else {
        thresh = -mod$psi[,"Est."]
        confG0[[1]] = thresh + confG0[[1]]
        confG0[[2]] = thresh + confG0[[2]]
      }
      
      
      # Get R2
      # if(length(mod$call) > 4) {
      #   #piecewise SEM package for mixed effects models
      #   r2_1 <- rsquared(mod[[1]])$Marginal
      #   r2_2 <- rsquared(mod[[2]])$Marginal
      #   r2 <- (r2_1 + r2_2)/2
      # } else{
      #   # performance package if there are no random effects
      #   r2 <- as.numeric(r2(mod)[2])
      # }
      
      
      out <- data.frame(pid = x$pid, model = y, type = type,
                        G0 = thresh, lowG0 = confG0[[1]], highG0 = confG0[[2]],
                        lowU = confU[[1]], highU = confU[[2]]) %>%
        mutate(diffG0 = abs(highG0 - lowG0), diffU = abs(highU - lowU))
      
      # If the segmented model fit best, but the difference in slopes was not significant
    } else if(sign(confU[[1]]) != sign(confU[[2]])) {
      
      type = "nonSig_rseg"
      
      # # Get R2
      # if(length(mod$call) > 4) {
      #   #piecewise SEM package for mixed effects models
      #   r2_1 <- rsquared(mod[[1]])$Marginal
      #   r2_2 <- rsquared(mod[[2]])$Marginal
      #   r2 <- (r2_1 + r2_2)/2
      # } else{
      #   # performance package if there are no random effects
      #   r2 <- as.numeric(r2(mod)[2])
      # }
      # 
      
      out = data.frame(pid = x$pid, model = y, type = type, 
                       G0 = NA, lowG0 = NA, highG0 = NA,
                       lowU = NA, highU = NA) %>%
        mutate(diffG0 = NA, diffU = NA)
    }
    
  }
  
  
  
  return(out)
  
}

resultsJac = mapply(x = jacModels, y = aic$model, FUN = checkSlopes, SIMPLIFY = FALSE) %>%
  bind_rows()


rownames(resultsJac)  <- NULL

resultsJac %>% group_by(type) %>% count() 


write_csv(resultsJac, "results/jacThresholds.csv")

