#### Jaccard sensitivity test --------------------------------------------------

#### Prep analysis data ---------------------------------------------

library(tidyverse)
library(janitor)
library(sf)
library(kableExtra)
library(viridis)
library(units)

## Load in dataquality which has most of the required data
cutOff_value <- 70
dataQuality = read_csv(paste0("data/processed/dataQuality_fp", cutOff_value, ".csv"))

# data that we tried running segmented models for
simDat <- read.csv(paste0("data/processed/Jaccard_simDat_fp", cutOff_value, ".csv"))
dataQuality <- subset(dataQuality, pid %in% unique(simDat$pid))

## Load in scale of effect data
bestScale = read_csv(paste0("data/processed/bestScaleSimDat_fp", cutOff_value, ".csv")) %>%
  distinct(pid, buffer)

## Filter dataquality by the scale of effect
dataQuality = inner_join(dataQuality, bestScale)

## Load in explanatory variable data
regionalForest = read.csv("data/processed/regional_Forest_Cover.csv") %>%
  clean_names()

load("data/processed/study_Geometries.RData")
avgLat = study_Plot_Points_sf %>% map2(.,., ~st_coordinates(.x) %>% as.data.frame() %>% add_column(PID = .y$PID)) %>% 
  bind_rows() %>% group_by(PID) %>% summarise(avg_Lat = abs(mean(Y))) %>%
  clean_names()

## Join up with data quality
dataQuality = left_join(dataQuality, avgLat, by = "pid")
dataQuality = left_join(dataQuality, regionalForest[,c("cover", "pid")], by = "pid")


## Load in taxa data and join with data quality
taxa = read_csv("data/processed/taxa_PID_Lookup.csv") %>%
  clean_names() %>%
  mutate(taxa = ifelse(taxa == "Bats", "Mammals", taxa))

dataQuality = left_join(dataQuality, taxa[,c("pid", "taxa")], by = "pid")

## Load in thresholds of sites with 
## significant differences in slopes
## and give threshold type and position
jacThresh = read_csv("results/jacThresholds.csv") %>%
  clean_names()

## Join with data quality
data = left_join(dataQuality, jacThresh)




## Geographic area covered by the study
load("data/processed/study_Geometries.Rdata")

get_area <- function(study_data){
  hull <- st_convex_hull(st_union(study_data))
  study_data$area <- set_units(st_area(hull), km^2)
  return(study_data)
}

get_area_data <- lapply(study_Plot_Points_sf, get_area) %>%
  bind_rows() %>%
  st_drop_geometry() %>%
  group_by(PID) %>%
  summarise(area = unique(area)) %>%
  rename(pid = PID) %>%
  subset(pid %in% data$pid)


data <- left_join(data, get_area_data, by = "pid")

data <- subset(data,  g0 <= 1 | is.na(g0))

data <- subset(data, !is.na(data$cover))

data <- data[!duplicated(data$pid),]

## Change order of columns
finalTable = data %>%
  relocate(pid, taxa, g0, type, nSites, nControls, controlForest, forestRange, avg_lat, cover)



finalTable %>% group_by(type) %>% summarise(n())



## Regional deforestation 
finalTable$deforest <- 1 - finalTable$cover




sor_data <- read.csv("results/FinalData_fp70.csv")

finalTable <- subset(finalTable, pid %in% sor_data$pid)

## Binary term indicating presence/absence of relevant threshold
finalTable$relevant_threshold_YN <- ifelse(finalTable$type == "declining_integrity_below_thresh", 1, 0)

finalTable %>% group_by(relevant_threshold_YN) %>% summarise(n())


### Key info

# how many studies in total?
length(unique(finalTable$pid))

# how many studies with relevant thresholds?
finalTable_thresh <- subset(finalTable, relevant_threshold_YN == 1)
length(unique(finalTable_thresh$pid))

# how many studies in total for each taxa?
finalTable %>% group_by(taxa) %>% summarise(length(unique(pid)))

# how many studies with thresholds for each taxa?
finalTable_thresh %>% group_by(taxa) %>% summarise(length(unique(pid)))

# of the non-threshold studies, how many were non sig reg, how many were linear?
finalTable %>% group_by(type) %>% summarise(n())

# threshold positions
min(finalTable_thresh$g0, na.rm = T)
max(finalTable_thresh$g0, na.rm = T)
mean(finalTable_thresh$g0, na.rm = T)
median(finalTable_thresh$g0, na.rm = T)



write.csv(finalTable, "results/Jaccard_FinalData_fp70.csv")

