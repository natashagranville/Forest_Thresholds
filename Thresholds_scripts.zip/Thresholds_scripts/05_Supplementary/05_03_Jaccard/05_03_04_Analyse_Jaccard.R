#### Jaccard sensitivity test
library(emmeans)
library(tidyverse)
library(glmmTMB)
library(sjPlot)

data <- read.csv("results/Jaccard_FinalData_fp70.csv")


## How many of each type?
data %>% group_by(type) %>% summarise(n())


data$relevant_threshold_YN <- as.factor(data$relevant_threshold_YN)


data %>% group_by(relevant_threshold_YN) %>% summarise(n())

data %>% group_by(taxa) %>% summarise(n())

## Taxa
taxa_model <- glmmTMB(relevant_threshold_YN ~ taxa, data = data, family = "binomial")
summary(taxa_model)
AIC(taxa_model)
performance::r2(taxa_model)


taxa_model_emmeans <- emmeans(taxa_model, specs = ~ taxa)
taxa_summary <- summary(taxa_model_emmeans, type = "response")
taxa_summary




## Number of sites
nSites_model <- glmmTMB(relevant_threshold_YN ~ nSites, data = data, family = binomial)
summary(nSites_model)
save(nSites_model, file = "results/Jaccard_nSites_model.Rdata")

## Latitude and regional deforestation
lat_model <- glmmTMB(relevant_threshold_YN ~ avg_lat, data = data, family = binomial)
summary(lat_model)

deforest_model <- glmmTMB(relevant_threshold_YN ~ deforest, data = data, family = binomial)
summary(deforest_model)

save(deforest_model, file = "results/Jaccard_deforest_presence_model.Rdata")

## Range of forest cover
forestRange_model <- glmmTMB(relevant_threshold_YN ~ forestRange, data = data, family = binomial)
summary(forestRange_model)


##### Analyse threshold position -----------------------------------------------

thresh_data <- subset(data, relevant_threshold_YN == 1)

min(thresh_data$g0, na.rm = T)
max(thresh_data$g0, na.rm = T)
mean(thresh_data$g0, na.rm = T)
median(thresh_data$g0, na.rm = T)




## Swap lowG0 and highG0 around if the model was an rseg as it messes up plotting
thresh_data = thresh_data %>% mutate(newLowG0 = ifelse(model == "rseg", low_g0, 0),
                                     low_g0 = ifelse(model == "rseg", high_g0, lowG0),
                                     high_g0 = ifelse(model == "rseg", newLowG0, highG0))


## We will model the position of the threholds using a beta regression since our
## response is bounded between  0 - 1
thresh_data = thresh_data %>% mutate(weightDiffG0 = log(1/diff_g0), type = as.factor(type))


weighted.mean(thresh_data$g0, thresh_data$weightDiffG0)




## Weighted Average threshold for each taxonomic group

taxa_model = glmmTMB(g0 ~ taxa, data = thresh_data,  weights = weightDiffG0, family = beta_family())
summary(taxa_model)

taxa_model_emmeans <- emmeans(taxa_model, specs = ~ taxa)
taxa_summary <- summary(taxa_model_emmeans, type = "response")
taxa_summary



#### Latitude * regional deforestation ------------------------

LatMod = glmmTMB(g0 ~ avg_lat, data = thresh_data, weights = weightDiffG0, family = beta_family())
summary(LatMod)



DeforestMod = glmmTMB(g0 ~ deforest, data = thresh_data, weights = weightDiffG0, family = beta_family())
summary(DeforestMod)
save(DeforestMod, file = "results/Jaccard_deforest_position_model.Rdata")