#### Sensitivity test: min. 70% range in landscape-scale forest cover values -----------------------

library(emmeans)
library(tidyverse)
library(ggeffects)
library(glmmTMB)
library(sjPlot)
library(janitor)
library(sf)
library(viridis)


data <- read.csv("results/FinalData_fp70.csv")

hist(data$forestRange)

### ** RESTRICT TO STUDIES WITH >70% RANGE OF FOREST COVER **
data <- subset(data, forestRange > 0.7)

data$REALM[data$REALM == "Oceania"] <- "Australasia"

length(unique(data$pid))

## How many of each type?
data %>% group_by(type) %>% summarise(n())


##### Analyse threshold presence -----------------------------------------------
data$relevant_threshold_YN <- as.factor(data$relevant_threshold_YN)


data %>% group_by(relevant_threshold_YN) %>% summarise(n())

data %>% group_by(taxa, relevant_threshold_YN) %>% summarise(n())



## Taxa
taxa_model <- glmmTMB(relevant_threshold_YN ~ taxa, data = data, family = "binomial")
summary(taxa_model)
AIC(taxa_model)
performance::r2(taxa_model)


taxa_model_emmeans <- emmeans(taxa_model, specs = ~ taxa)
taxa_summary <- summary(taxa_model_emmeans, type = "response")
taxa_summary

taxa_df <- as.data.frame(taxa_summary)

taxa_df <- taxa_df %>%
  dplyr::select(taxa, prob, asymp.LCL, asymp.UCL) %>%
  rename(`Taxonomic group` = taxa,
         `Probability of identifying a threshold` = prob,
         `Lower 95% confidence interval` = asymp.LCL,
         `Upper 95% confidence interval`  = asymp.UCL)%>%
  mutate_if(is.numeric, round, 2)
taxa_df


## Biogeographic realm
realm_model <- glmmTMB(relevant_threshold_YN ~ REALM, data = data, family = "binomial")
summary(realm_model)
AIC(realm_model)
performance::r2(realm_model)


realm_model_emmeans <- emmeans(realm_model, specs = ~ REALM)
realm_summary <- summary(realm_model_emmeans, type = "response")
realm_summary


realm_df <- as.data.frame(realm_summary)

realm_df <- realm_df %>%
  dplyr::select(REALM, prob, asymp.LCL, asymp.UCL) %>%
  rename(`Biogeographic realm` = REALM,
         `Probability of identifying a threshold` = prob,
         `Lower 95% confidence interval` = asymp.LCL,
         `Upper 95% confidence interval`  = asymp.UCL)%>%
  mutate_if(is.numeric, round, 2)



## Number of sites
nSites_model <- glmmTMB(relevant_threshold_YN ~ nSites, data = data, family = binomial)
summary(nSites_model)


## Latitude and regional forest cover
lat_model <- glmmTMB(relevant_threshold_YN ~ avg_lat, data = data, family = binomial)
summary(lat_model)

regional_FC_model <- glmmTMB(relevant_threshold_YN ~ cover, data = data, family = binomial)
summary(regional_FC_model)


##### Threshold presence figure ------------------------------------------------


###### Panel A - graph showing all linear and threshold relationships -----------
## Load models
files <- list.files(path = "results/SorModels_fp70/", pattern = "\\.Rdata$", full.names = TRUE)
sorModels <- list()
for(i in 1:length(files)){
  load(files[[i]])
  sorModels[[i]] <- out
}



## Load in data quality measures
dataQuality = read_csv("data/processed/dataQuality_fp70.csv") %>%
  clean_names()

## Load in similarity data for plotting
sim = read.csv("data/processed/bestScaleSimDat_fp70.csv") %>%
  left_join(dataQuality) 


sim <- subset(sim, pid %in% data$pid)


sorModel_pids <- lapply(sorModels, function(df) df$pid)

sorModel_indices <- grep(paste(data$pid, collapse = "|"), unlist(sorModel_pids))

sorModels <- sorModels[sorModel_indices]

sim <- sim %>%
  group_split(pid)


aic <- read.csv("results/sorAIC_fp70.csv")


# Check lengths match
length(sorModels)
length(sim)
nrow(data)

## Make function to predict from segmented models
predictRandSegment = function(mod, newdata) {
  
  if(length(mod$call) > 4) {
    coef = mod$lme.fit$coefficients$fixed
    int = coef["(Intercept)"][[1]]
    forestCoverSlope = coef["forest_cover"][[1]]
    distanceSlope = coef["distance_km"][[1]]
    G0 = coef["G0"][[1]]
    confintG0 = confint(mod)[,"G0"]
    USlope = coef["U"][[1]]
    
    ## If the model is lseg it won't have a forest cover slope
    ## so we set forestcoverslope to 0
    if(is.na(forestCoverSlope)) {forestCoverSlope = 0}
    
    ## Form of equation is y = B0 + B1*X1 + B2*(X1 - G0) + B3*X3 
    ## Where X1 is forestSlope, X2 is USlope, X3 is distance
    
    ## If the model is rseg then we have to flip everything around
    ## we can check this by looking if G0 is < 0
    if(G0 >= 0) {
      dat = newdata %>% mutate(pred = ifelse(forest_cover <= G0, int + (forest_cover*forestCoverSlope) + (distance_km*distanceSlope),
                                             int + (forest_cover*forestCoverSlope) + (USlope*(forest_cover - G0)) + (distance_km*distanceSlope)))
    } else {
      G0 = -G0
      confintG0 = rev(-confintG0)
      USlope = -USlope
      dat = newdata %>% mutate(pred = ifelse(forest_cover > G0, int + (forest_cover*forestCoverSlope) + (distance_km*distanceSlope),
                                             int + (forest_cover*forestCoverSlope) + (USlope*(forest_cover - G0)) + (distance_km*distanceSlope)))
    }
    
  } else if(length(mod$call) <= 4) {
    coef = coef(mod)
    int = coef["(Intercept)"][[1]]
    forestCoverSlope = coef["forest_cover"][[1]]
    distanceSlope = coef["distance_km"][[1]]
    G0 = mod$psi[[2]] ## error in coef object which means you can't get G0 from there
    confintG0 = c(G0 - (mod$psi[[3]]*1.96), G0 + (mod$psi[[3]]*1.96))
    if(G0 >= 0) {
      USlope = coef["U1.forest_cover"][[1]]
    } else {
      USlope = coef["U1.negative_forest_cover"][[1]]
    }
    
    ## If the model is lseg it won't have a forest cover slope
    ## so we set forestcoverslope to 0
    if(is.na(forestCoverSlope)) {forestCoverSlope = 0}
    
    ## Form of equation is y = B0 + B1*X1 + B2*(X1 - G0) + B3*X3 
    ## Where X1 is forestSlope, X2 is USlope, X3 is distance
    
    ## If the model is rseg then we have to flip everything around
    ## we can check this by looking if G0 is < 0
    if(G0 >= 0) {
      dat = newdata %>% mutate(pred = ifelse(forest_cover <= G0, int + (forest_cover*forestCoverSlope) + (distance_km*distanceSlope),
                                             int + (forest_cover*forestCoverSlope) + (USlope*(forest_cover - G0)) + (distance_km*distanceSlope)))
    } else {
      G0 = -G0
      confintG0 = rev(-confintG0)
      USlope = -USlope
      dat = newdata %>% mutate(pred = ifelse(forest_cover > G0, int + (forest_cover*forestCoverSlope) + (distance_km*distanceSlope),
                                             int + (forest_cover*forestCoverSlope) + (USlope*(forest_cover - G0)) + (distance_km*distanceSlope)))
    }
  }
  
  ## Add position of threshold to data frame
  ## and SE of thresholds
  dat = dat %>% mutate(G0 = G0, lowG0 = confintG0[[1]], highG0 = confintG0[[2]])
  
  return(dat)
  
}

predictions = mapply(function(x, y, z, a) {
  print(unique(z$pid))
  print(y)
  if (y == "declining_integrity_below_thresh" ) {
    
    # Full prediction line
    full_pred <- predictRandSegment(
      mod = x$rseg,
      newdata = data.frame(
        forest_cover = seq(min(z$forest_cover, na.rm = TRUE), max(z$forest_cover, na.rm = TRUE), length.out = 500),
        distance_km = mean(z$distance_km, na.rm = TRUE)
      )
    ) %>% mutate(.before = 1, pid = x$pid, type = "declining_integrity_below_thresh", forest_range = z$forest_range[[1]])
    
    full_pred$model_type <- "relevant_thresh"
    
    # Breakpoint prediction
    G0 <- full_pred$G0[1]  # Extract G0 from the prediction output
    breakpoint_pred <- predictRandSegment(
      mod = x$rseg,
      newdata = data.frame(
        forest_cover = G0,
        distance_km = mean(z$distance_km, na.rm = TRUE)
      )
    ) %>% mutate(pid = x$pid, type = "declining_integrity_below_thresh", forest_range = z$forest_range[[1]], is_breakpoint = TRUE)
    
    # Combine full prediction and breakpoint
    full_pred$is_breakpoint <- FALSE
    combined <- bind_rows(full_pred, breakpoint_pred)
    
    combined$model_type <- "relevant_thresh"
    return(combined)
    
  } else if(y == "increasing_integrity_below_thresh"){
    
    # Full prediction line
    full_pred <- predictRandSegment(
      mod = x$rseg,
      newdata = data.frame(
        forest_cover = seq(min(z$forest_cover, na.rm = TRUE), max(z$forest_cover, na.rm = TRUE), length.out = 500),
        distance_km = mean(z$distance_km, na.rm = TRUE)
      )
    ) %>% mutate(.before = 1, pid = x$pid, type = "increasing_integrity_below_thresh", forest_range = z$forest_range[[1]])
    
    full_pred$model_type <- "no_relevant_thresh"
    
    return(full_pred)
    
  } else if (y == "lin"){
    
    noThresh_pred_data <- data.frame(
      forest_cover = seq(min(z$forest_cover, na.rm = TRUE), max(z$forest_cover, na.rm = TRUE), length.out = 500),
      distance_km = mean(z$distance_km, na.rm = TRUE)
    )
    
    noThresh_pred_data$pred <- predict(x$lin, noThresh_pred_data, level = 0)
    
    noThresh_pred_data$pid <- unique(z$pid)
    noThresh_pred_data$type <- "lin"
    noThresh_pred_data$forest_range <- NA
    noThresh_pred_data$lowG0 <- NA
    noThresh_pred_data$highG0 <- NA
    noThresh_pred_data$is_breakpoint <- FALSE
    noThresh_pred_data$model_type <- "no_relevant_thresh"
    
    return(noThresh_pred_data)
    
  } else if(y == "nonSig_rseg"){
    
    full_pred <- predictRandSegment(
      mod = x$rseg,
      newdata = data.frame(
        forest_cover = seq(min(z$forest_cover, na.rm = TRUE), max(z$forest_cover, na.rm = TRUE), length.out = 500),
        distance_km = mean(z$distance_km, na.rm = TRUE)
      )
    ) %>% mutate(.before = 1, pid = x$pid, type = "nonSig_rseg", forest_range = z$forest_range[[1]])
    full_pred$model_type <- "no_relevant_thresh"
    
    return(full_pred)
  }
  
  
}, x = sorModels, y = data$type, z = sim, a = aic$model, SIMPLIFY = FALSE)


# x = sorModels[[5]]
# y = data$type[5]
# z = sim[[5]]
# a = aic$model[5]


# Combine all predictions into one data frame
predictions_df <- bind_rows(predictions)

length(unique(predictions_df$pid))
unique(predictions_df$type)


facet_labels <- as_labeller(c('no_relevant_thresh' = 'No relevant threshold identified',
                              'relevant_thresh' = 'Relevant threshold identified'))

predictions_df <- left_join(predictions_df, data[,c("nSites", "pid")], by = "pid")

# Plot with breakpoint highlighted


all_slopes_plot <- ggplot(predictions_df, aes(x = forest_cover, y = pred, group = pid, colour = model_type)) +
  geom_line(alpha = 0.6) +
  facet_wrap(~model_type, labeller = facet_labels) +
  geom_point(data = filter(predictions_df, is_breakpoint == TRUE & model_type != "lin"),
             aes(x = forest_cover, y = pred),
             fill = "#6a51a3", size = 2.5, alpha = 0.8, shape = 20) +
  scale_colour_manual(values = c("orange", "#6a51a3")) +
  labs(x = "Forest cover", y = "Arcsine transformed compositional intactness") +
  scale_x_continuous(labels = scales::percent) +
  theme_classic() +
  theme(legend.title = element_blank(),
        legend.position = "none",
        panel.spacing = unit(2, "lines"),
        strip.text = element_text(size = 18),
        plot.margin = unit(c(0.5,1,0.5,0.5), "cm"), 
        strip.background = element_blank(),
        axis.text = element_text(colour = "black", size = 18),
        axis.title = element_text(size = 18))
all_slopes_plot


###### Panel B - maps --------------------------------------------------------


load("data/processed/study_Geometries.RData")


centroids <- lapply(study_Plot_Points_sf, function(x) {
  st_centroid(sfheaders::sf_multipoint(st_coordinates(x)))
})

PIDs <- lapply(study_Plot_Points_sf, function(x) {
  unique(x$PID)
})

centroids_sf <- do.call(rbind, centroids)
PIDs <- do.call(rbind, PIDs)

centroids <- cbind(centroids_sf, PIDs)
colnames(centroids) <- c("id","pid","geometry")


data <- st_sf(left_join(data, centroids, by = "pid"))

world <- map_data('world') %>% 
  as_tibble()

data <- data[!duplicated(data),]

data$Site_Longitude_x_wgs84 <- st_coordinates(data)[,1]
data$Site_Latitude_y_wgs84 <- st_coordinates(data)[,2]


## noThresh studies map
noThresh_studies <- subset(data, relevant_threshold_YN == 0)
noThresh_studies_map <- ggplot() +
  geom_polygon(data=world, 
               aes(long, lat, group = group), colour=NA, fill='#C8C8C8', size=0) +#
  coord_map('mollweide', ylim = c(-60, 90), xlim = c(-180, 180)) +
  theme_void() +
  theme(panel.grid = element_blank(), 
        panel.border = element_blank(),
        axis.ticks = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        legend.title = element_blank(),
        legend.position = c(0.2,0.3),
        legend.text = element_text(size = 16),
        legend.background = element_blank(),
        plot.margin = margin(0.5,0.5,0.5,0.5, "cm")) +
  scale_x_continuous(breaks = seq(-180, 180, by = 30), 
                     minor_breaks = seq(-180, 180, by = 10)) +
  scale_y_continuous(breaks = seq(-60, 90, by = 30), 
                     minor_breaks = seq(-60, 90, by = 10)) +
  geom_point(data = noThresh_studies, aes(x = Site_Longitude_x_wgs84, y = Site_Latitude_y_wgs84), fill = "orange", colour = "orange", size = 3) +
  scale_shape_manual(values = c(21, 22, 24, 25))
noThresh_studies_map
ggsave(noThresh_studies_map, filename = "figures/sensitivity_tests/forestRange70_no_relevant_thresh_studies_map.jpg", height = 25, width = 28, units = "cm")



thresh_studies <- subset(data, relevant_threshold_YN == 1)

thresh_studies_map <- ggplot() +
  geom_polygon(data=world, 
               aes(long, lat, group = group), colour=NA, fill='#C8C8C8', size=0) +#
  coord_map('mollweide', ylim = c(-60, 90), xlim = c(-180, 180)) +
  theme_void() +
  theme(panel.grid = element_blank(), 
        panel.border = element_blank(),
        axis.ticks = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        legend.title = element_blank(),
        legend.position = c(0.2,0.3),
        legend.text = element_text(size = 16),
        legend.background = element_rect(fill = NA),
        plot.margin = margin(0.5,0.5,0.5,0.5, "cm")) +
  scale_x_continuous(breaks = seq(-180, 180, by = 30), 
                     minor_breaks = seq(-180, 180, by = 10)) +
  scale_y_continuous(breaks = seq(-60, 90, by = 30), 
                     minor_breaks = seq(-60, 90, by = 10)) +
  geom_point(data = thresh_studies, aes(x = Site_Longitude_x_wgs84, y = Site_Latitude_y_wgs84), fill = "#6a51a3", colour = "#6a51a3", size = 3) +
  scale_shape_manual(values = c(21, 22, 24, 25))
thresh_studies_map
ggsave(thresh_studies_map, filename = "figures/sensitivity_tests/forestRange70_relevant_thresh_studies_map.jpg", height = 25, width = 28, units = "cm")


###### Panel C - doughnut plots for each taxonomic group ----------------------

data_sum <- st_drop_geometry(data) %>% 
  group_by(relevant_threshold_YN, taxa) %>%
  summarise(count = n())



arthro <- subset(data_sum, taxa == "Arthropods")
arthro$fraction <- arthro$count / sum(arthro$count)
arthro$ymax <- cumsum(arthro$fraction)
arthro$ymin <- c(0, head(arthro$ymax, n=-1))
arthro$labelPosition <- (arthro$ymax + arthro$ymin) / 2
arthro$label <- paste0(arthro$count)

arthro_plot <- ggplot(arthro, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=as.factor(relevant_threshold_YN))) +
  geom_rect() +
  geom_text(x=3.5, aes(y= labelPosition, label= label), size=7, fill = NA) +
  scale_fill_manual(values = c("orange", "#6a51a3")) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  ggtitle("Arthropods") +
  theme_void() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 18))
arthro_plot


bird <- subset(data_sum, taxa == "Birds")
bird$fraction <- bird$count / sum(bird$count)
bird$ymax <- cumsum(bird$fraction)
bird$ymin <- c(0, head(bird$ymax, n=-1))
bird$labelPosition <- (bird$ymax + bird$ymin) / 2
bird$label <- paste0(bird$count)

bird_plot <- ggplot(bird, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=as.factor(relevant_threshold_YN))) +
  geom_rect() +
  geom_text(x=3.5, aes(y= labelPosition, label= label), size=7, fill = NA) +
  scale_fill_manual(values = c("orange", "#6a51a3")) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  ggtitle("Birds") +
  theme_void() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 18))
bird_plot



herp <- subset(data_sum, taxa == "Herptiles")
herp$fraction <- herp$count / sum(herp$count)
herp$ymax <- cumsum(herp$fraction)
herp$ymin <- c(0, head(herp$ymax, n=-1))
herp$labelPosition <- (herp$ymax + herp$ymin) / 2
herp$label <- paste0(herp$count)

herp_plot <- ggplot(herp, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=as.factor(relevant_threshold_YN))) +
  geom_rect() +
  geom_text(x=3.5, aes(y= labelPosition, label= label), size=7, fill = NA) +
  scale_fill_manual(values = c("orange", "#6a51a3")) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  ggtitle("Herptiles") +
  theme_void() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 18))
herp_plot



mammal <- subset(data_sum, taxa == "Mammals")
mammal$fraction <- mammal$count / sum(mammal$count)
mammal$ymax <- cumsum(mammal$fraction)
mammal$ymin <- c(0, head(mammal$ymax, n=-1))
mammal$labelPosition <- (mammal$ymax + mammal$ymin) / 2
mammal$label <- paste0(mammal$count)

mammal_plot <- ggplot(mammal, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=as.factor(relevant_threshold_YN))) +
  geom_rect() +
  geom_text(x=3.5, aes(y= labelPosition, label= label), size=7, fill = NA) +
  scale_fill_manual(values = c("orange", "#6a51a3")) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  ggtitle("Mammals") +
  theme_void() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 18))
mammal_plot


###### Panel D - number of sites ----------------------------------------------


str(data)

# read in and subset the data again here so that relevant_threshold_YN is *not* treated as a factor
# otherwise, it creates issues with the plot
# it needs to be an integer for the y axis and a factor for the colour
data <- read.csv("results/FinalData_fp70.csv")
data <- subset(data, forestRange > 0.7)

nSites_pred <-  predict(nSites_model, data, type = 'response', re.form = NA, se.fit = T)

data$nSites_pred <- nSites_pred$fit
data$nSites_pred_LCI <- nSites_pred$fit - nSites_pred$se.fit
data$nSites_pred_UCI <- nSites_pred$fit + nSites_pred$se.fit


nSites_plot <- ggplot(data, aes(x = log10(nSites))) +
  geom_ribbon(aes(ymin = nSites_pred_LCI, ymax = nSites_pred_UCI), colour = "#C8C8C8", alpha = 0.3) +
  geom_line(aes(y = nSites_pred), linewidth = 1.2) +
  geom_point(aes(y = relevant_threshold_YN , colour = factor(relevant_threshold_YN )), 
             alpha = 0.75,  shape = 16,  position = position_jitter(width = 0, height = 0.05)) +
  scale_colour_manual(values = c("0" = "orange", "1" = "#6a51a3")) +
  theme_classic() +
  labs(x = expression(log[10]~(Number~of~sites)), y = "Probability of detecting a threshold") +
  theme(axis.text = element_text(size = 18, colour = "black"),
        axis.title = element_text(size = 18),
        legend.position = "none")
nSites_plot


###### Panel E -  regional deforestation ---------------

regional_FC_pred <- ggpredict(regional_FC_model, terms = c('cover[all]'))

regional_FC_plot <- ggplot() +
  # Lines + ribbons
  geom_line(data = regional_FC_pred, aes(x = x, y = predicted), size = 1.2) +
  geom_ribbon(data = regional_FC_pred, aes(x = x, ymin = conf.low, ymax = conf.high),
              alpha = 0.3, colour = "#C8C8C8") +
  geom_point(data = data, aes(x = cover, y = relevant_threshold_YN, colour = factor(relevant_threshold_YN)),
             alpha = 0.75, shape = 16, position = position_jitter(width = 0, height = 0.05),
             show.legend = F) +
  scale_colour_manual(values = c("0" = "orange", "1" = "#6a51a3")) +
  theme_classic() +
  labs(x = "Regional forest cover", y = "Probability of detecting a threshold") +
  theme(axis.text = element_text(size = 18, colour = "black"),
        axis.title = element_text(size = 18),
        legend.text = element_text(size = 18),
        legend.title = element_text(size = 18),
        legend.background = element_blank(),
        legend.position = c(0.7,0.7))
regional_FC_plot


###### Combine panels -------------------------------------


all_taxa_plot <- cowplot:: plot_grid(arthro_plot, bird_plot, herp_plot, mammal_plot, align = "vh", nrow = 1)
all_taxa_plot

all_plot <- cowplot::plot_grid(all_slopes_plot, all_taxa_plot, nrow = 2, rel_heights = c(2,0.8))
all_plot



analyses_plot <- cowplot::plot_grid( nSites_plot, regional_FC_plot, align = "vh")
analyses_plot

final_plot <- cowplot::plot_grid(all_plot, analyses_plot, rel_heights = c(2,1), ncol = 1)
final_plot
ggsave(final_plot, filename = "figures/sensitivity_tests/forestRange70_all_plot.jpg", width = 32, height = 32, units = "cm")




##### Analyse threshold position --------------------------------------



thresh_data <- subset(data, relevant_threshold_YN == 1)


min(thresh_data$g0, na.rm = T)
max(thresh_data$g0, na.rm = T)
mean(thresh_data$g0, na.rm = T)
median(thresh_data$g0, na.rm = T)

## Swap lowG0 and highG0 around if the model was an rseg as it messes up plotting
thresh_data = thresh_data %>% mutate(newLowG0 = ifelse(model == "rseg", low_g0, 0),
                                     low_g0 = ifelse(model == "rseg", high_g0, lowG0),
                                     high_g0 = ifelse(model == "rseg", newLowG0, highG0))


## We will model the position of the threholds using a beta regression since our
## response is bounded between  0 - 1
thresh_data = thresh_data %>% mutate(weightDiffG0 = log(1/diff_g0), type = as.factor(type))


## weighted mean
weighted.mean(thresh_data$g0, thresh_data$weightDiffG0)




## Weighted Average threshold for each taxonomic group
taxa_model = glmmTMB(g0 ~ taxa, data = thresh_data, weights = weightDiffG0,  family = beta_family())
summary(taxa_model)

taxa_model_emmeans <- emmeans(taxa_model, specs = ~ taxa)
taxa_summary <- summary(taxa_model_emmeans, type = "response")
AIC(taxa_model)
performance::r2(taxa_model)

taxa_df <- as.data.frame(taxa_summary)

taxa_df <- taxa_df %>%
  dplyr::select(taxa, response, asymp.LCL, asymp.UCL) %>%
  rename(`Taxonomic group` = taxa,
         `Threshold position` = response,
         `Lower 95% confidence interval` = asymp.LCL,
         `Upper 95% confidence interval`  = asymp.UCL)%>%
  mutate_if(is.numeric, round, 2)
taxa_df





#### Latitude + regional FC ------------------------

thresh_data$vert_invert <- ifelse(thresh_data$taxa == "Arthropods", "Invertebrates", "Vertebrates")

thresh_data$vert_invert <- as.factor(thresh_data$vert_invert)


LatMod = glmmTMB(g0 ~ avg_lat * vert_invert, data = thresh_data, weights = weightDiffG0, family = beta_family())
summary(LatMod)

LatMod = glmmTMB(g0 ~ avg_lat * relevel(vert_invert, ref = "Vertebrates"), data = thresh_data, weights = weightDiffG0, family = beta_family())
summary(LatMod)






RegionalFCMod = glmmTMB(g0 ~ cover *  relevel(vert_invert, ref = "Vertebrates"), data = thresh_data, weights = weightDiffG0, family = beta_family())
summary(RegionalFCMod)


RegionalFCMod = glmmTMB(g0 ~ cover * vert_invert, data = thresh_data, weights = weightDiffG0, family = beta_family())
summary(RegionalFCMod)







##### Panel A - map ------------------------------------------------------------

load("data/processed/study_Geometries.RData")

centroids <- lapply(study_Plot_Points_sf, function(x) {
  st_centroid(sfheaders::sf_multipoint(st_coordinates(x)))
})

PIDs <- lapply(study_Plot_Points_sf, function(x) {
  unique(x$PID)
})

centroids_sf <- do.call(rbind, centroids)
PIDs <- do.call(rbind, PIDs)

centroids <- cbind(centroids_sf, PIDs)
colnames(centroids) <- c("id","pid","geometry")


thresh_data <- st_sf(left_join(thresh_data, centroids, by = "pid"))

world <- map_data('world') %>% 
  as_tibble()

thresh_data$Site_Longitude_x_wgs84 <- st_coordinates(thresh_data)[,1]
thresh_data$Site_Latitude_y_wgs84 <- st_coordinates(thresh_data)[,2]



thresh_position_map <- ggplot() +
  geom_polygon(data=world, 
               aes(long, lat, group = group), colour=NA, fill='#C8C8C8', size=0) +#
  coord_map('mollweide', ylim = c(-60, 90), xlim = c(-180, 180)) +
  theme_void() +
  theme(panel.grid = element_blank(), 
        panel.border = element_blank(),
        axis.ticks = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        legend.position = c(0.2,0.3),
        legend.text = element_text(size = 16),
        legend.title = element_text(size = 16),
        legend.background = element_blank(),
        plot.margin = margin(0.5,0.5,0.5,0.5, "cm")) +
  scale_x_continuous(breaks = seq(-180, 180, by = 30), 
                     minor_breaks = seq(-180, 180, by = 10)) +
  scale_y_continuous(breaks = seq(-60, 90, by = 30), 
                     minor_breaks = seq(-60, 90, by = 10)) +
  geom_point(data = thresh_data, aes(x = Site_Longitude_x_wgs84, y = Site_Latitude_y_wgs84, colour = g0),  size = 3) +
  scale_colour_viridis(direction = -1, breaks = c(0, 0.25, 0.5, 0.75, 1), name = "Threshold \nposition",
                       labels = c("0%", "25%", "50%", "75%", "100%"), limits = c(0, 1))

thresh_position_map
ggsave(thresh_position_map, filename = "figures/sensitivity_tests/forestRange70_thresh_position_map.jpg", width = 25, height = 28, units = "cm")


##### Panel B - boxplot --------------------------------------------------------

thresh_data <- st_drop_geometry(thresh_data)

thresh_data %>% group_by(taxa) %>% summarise(mean(g0))

thresh_data$vert_invert <- ifelse(thresh_data$taxa == "Arthropods", "Invertebrates", "Vertebrates")


taxa_boxplot <- ggplot(thresh_data, aes(x = vert_invert, y = g0)) +
  geom_boxplot(width = 0.5, outliers = F) +
  geom_jitter(aes(colour = g0), width = 0.2, alpha = 0.7) +
  scale_colour_viridis(direction = -1) +
  labs(x = "",  y = "Threshold position") +
  scale_y_continuous(labels = scales::percent, breaks = c(0,0.2,0.4,0.6,0.8,1),
                     limits = c(0,1)) +
  theme_classic() +
  theme(axis.text = element_text(size = 13, colour = "black"),
        axis.title = element_text(size = 13),
        legend.position = "none")
taxa_boxplot



thresh_data$temp_trop <- ifelse(thresh_data$avg_lat > 23.5, "Temperate", "Tropical")

temp_trop_boxplot <- ggplot(thresh_data, aes(x = temp_trop, y = g0)) +
  geom_boxplot(width = 0.5, outliers = F) +
  geom_jitter(aes(colour = g0), width = 0.2, alpha = 0.7) +
  scale_colour_viridis(direction = -1) +
  labs(x = "",  y = "Threshold position") +
  scale_y_continuous(labels = scales::percent, breaks = c(0,0.2,0.4,0.6,0.8,1),
                     limits = c(0,1)) +
  theme_classic() +
  theme(axis.text = element_text(size = 13, colour = "black"),
        axis.title = element_text(size = 13),
        legend.position = "none")
temp_trop_boxplot


boxplot <- cowplot::plot_grid(taxa_boxplot, temp_trop_boxplot, nrow = 1, align = "vh")
boxplot

ggsave(boxplot, filename = "figures/sensitivity_tests/forestRange70_boxplot.jpg", width = 18, height = 7, units = "cm")





##### Panel C - regional FC graph ----------------------



## Swap lowG0 and highG0 around if the model was an rseg as it messes up plotting
thresh_data = thresh_data %>% mutate(newLowG0 = ifelse(model == "rseg", low_g0, 0),
                                     low_g0 = ifelse(model == "rseg", high_g0, lowG0),
                                     high_g0 = ifelse(model == "rseg", newLowG0, highG0))



thresh_data$pred <- predict(RegionalFCMod, thresh_data, type = "response")
thresh_data$pred_se <- predict(RegionalFCMod, thresh_data, se.fit = T, type = "response")[[2]]
thresh_data$pred_lci <- thresh_data$pred - (1.96 * thresh_data$pred_se)
thresh_data$pred_uci <- thresh_data$pred + (1.96 * thresh_data$pred_se)


regionalFC_Plot = ggplot(data = thresh_data) +
  geom_pointrange(aes(x = cover, y = g0, ymin = low_g0, ymax = high_g0, 
                      colour = g0), size = 0.8, linewidth = 1,
                  alpha = 0.8) +
  facet_wrap(~vert_invert, nrow = 2) +
  geom_line(aes(x = cover, y = pred, group = vert_invert), size = 0.9, linewidth = 1) +
  geom_ribbon(aes(x = cover, ymin = pred_lci, ymax = pred_uci, group = vert_invert), alpha = 0.15) +
  scale_colour_viridis(direction = -1, breaks = c(0, 0.25, 0.5, 0.75, 1), name = "Threshold \nposition",
                       labels = c("0%", "25%", "50%", "75%", "100%"), limits = c(0, 1)) +
  theme_classic() +
  scale_x_continuous(limits = c(0,1)) +
  scale_y_continuous(labels = scales::percent, breaks = c(0,0.2,0.4,0.6,0.8,1)) +
  labs(x = "Regional forest cover", y = "Threshold position", col = "Latitude") +
  theme(axis.text = element_text(size = 13, colour = "black"),
        legend.position = "none",
        axis.title = element_text(size = 13),
        strip.text = element_text(hjust = 0, size = 13),
        strip.background = element_blank(),
        panel.spacing = unit(1, "lines"))
regionalFC_Plot

ggsave(regionalFC_Plot, filename = "figures/sensitivity_tests/forestRange70_regionalFC_plot.png", width = 9, height = 14, units = "cm")


