##### Sensitivity test: absolute (90%) forest cover value for defining highly forested reference sites ---------------------


####################################
## Get data quality measures for the studies
####################################

library(tidyverse)
library(janitor)


## Load in forest data
cutOff_value <- 70
pland = read_csv(paste0("data/processed/percentage_Forest_Cover", cutOff_value, ".csv")) %>% 
  clean_names() %>% 
  filter(class == 1) %>%
  mutate(fCov = value/100) %>%
  dplyr::select(fCov, plot_id, pid, buffer)

## Get local forest cover (50m) for each plot and join
localForestCover = pland %>%
  filter(buffer == 50) %>%
  rename(local_forest_cover = fCov) %>%
  dplyr::select(plot_id, pid, local_forest_cover)

pland = pland %>%
  left_join(localForestCover, join_by(plot_id, pid)) %>%
  filter(buffer != 50)

## Identify control sites as those within 5% forest cover of the
## highest forest cover site in the study
## and those that have a local forest cover > 75%
# 
# controlSites = pland %>% 
#   filter(local_forest_cover >= 0.75) %>%
#   group_by(pid, buffer) %>%
#   filter(fCov > max(fCov) - 0.05)


## ***** As a sensitivity test, apply an absolute forest cover value for defining reference sites *****
controlSites = pland %>% 
   filter(local_forest_cover >= 0.75) %>%
   group_by(pid, buffer) %>%
  filter(fCov > 0.9)


## Get number of sites per study
nSites = pland %>% 
  group_by(pid, buffer) %>%
  summarise(nSites = n_distinct(plot_id))

## Get number of control sites per study
nControls = controlSites %>%
  group_by(pid, buffer) %>%
  summarise(nControls = n_distinct(plot_id))

## Highest forest cover in the study (that of the highest control site)
controlForest = controlSites %>%
  group_by(pid, buffer) %>%
  summarise(controlForest = max(fCov))

## Get range of forest cover per study
forestRange = pland %>%
  group_by(pid, buffer) %>%
  summarise(forestRange = max(fCov) - min(fCov))

## Join everything together
dataQuality = left_join(nSites, nControls) %>%
  left_join(controlForest) %>%
  left_join(forestRange)

## ** FILTER FOR FOREST RANGE **
## Remove studies with less than 0.3 (30%) forest range
## as the threshold is limited to relatively small set of values
dataQuality = dataQuality %>% filter(forestRange >= 0.3)


## Change NA for ncontrol and controlForest to 0, since these are studies
## without any control sites
dataQuality = mutate(dataQuality, nControls = ifelse(is.na(nControls), 0, nControls),
                     controlForest = ifelse(is.na(controlForest), 0, controlForest))


dataQuality <- subset(dataQuality, nControls > 0)

length(unique(dataQuality$pid))

#### Calculate community similarity between control and deforested sites -------

library(tidyverse)
library(janitor)
library(vegan)
library(stringr)

## Load in species occurrence data
specOcc = read_csv("data/processed/speciesOccurrence70.csv") %>% 
  clean_names() %>% 
  mutate(forest_cover = forest_cover/100)

dataQuality = read_csv("data/processed/dataQuality_fp70.csv")

# filter >30% variation in forest cover
specOcc = subset(specOcc, pid %in% dataQuality$pid)


pidTaxa = read_csv("data/processed/taxa_PID_Lookup.csv") %>%
  dplyr::select(c(pid, taxa, REALM))


## Load forest cover data
pland = read_csv("data/processed/percentage_Forest_Cover70.csv", locale = locale(encoding = "windows-1252")) %>% 
  clean_names() %>% 
  filter(class == 1) %>%
  mutate(fCov = value/100) %>%
  dplyr::select(fCov, plot_id, pid, buffer)

# filter >30% variation in forest cover
pland = subset(pland, pid %in% dataQuality$pid)

localForestCover = pland %>%
  filter(buffer == 50) %>%
  rename(local_forest_cover = fCov) %>%
  dplyr::select(plot_id, pid, local_forest_cover)

pland = pland %>%
  left_join(localForestCover, join_by(plot_id, pid)) %>%
  filter(buffer != 50)

# controlSites = pland %>% 
#   filter(local_forest_cover >= 0.75) %>%
#   group_by(pid, buffer) %>%
#   filter(fCov > max(fCov) - 0.05)


## ***** As a sensitivity test, apply an absolute forest cover value for defining reference sites *****
controlSites = pland %>% 
  filter(local_forest_cover >= 0.75) %>%
  group_by(pid, buffer) %>%
  filter(fCov > 0.9)


controlSites <- controlSites[!duplicated(controlSites), ]


## Remove duplicates
duplicates = c("PID0112", "PID0100", "PID0101", "PID0102", "PID0103", 
               "PID0104", "PID0105", "PID0106", "PID0107", "PID0108", "PID0109", 
               "PID0110", "PID0111", "PID0138", "PID1001", "PID0115", "PID0117")

controlSites = controlSites %>%
  filter(!pid %in% duplicates)

specOcc = specOcc %>%
  filter(!pid %in% duplicates)

## Add taxa info
specOcc = specOcc %>% 
  left_join(pidTaxa, by = "pid") %>% 
  filter(!pid %in% duplicates)


############################
## Calculating Similarity
############################

##################
## Calculate similarity of sites to control sites
##################

## Remove all plots that do not contain any species (occurrence == 0)
## as you can't compare community composition of plots without any community
sumOcc = specOcc %>%
  group_by(pid, plot_id) %>%
  summarise(sumOcc = sum(occurrence))

specOcc = specOcc %>%
  left_join(sumOcc, join_by(pid, plot_id)) %>%
  filter(sumOcc > 0) %>%
  dplyr::select(-sumOcc)

## Convert to wide format for use in similarity calculations
specWide_list <-  specOcc %>%
  dplyr::select(pid, plot_id, buffer, species, taxa, occurrence) %>%
  group_by(pid, plot_id, buffer, species) %>%
  summarise(occurrence = sum(occurrence, na.rm = TRUE), .groups = "drop") %>%  
  group_split(pid, buffer) 



pivot <- function(data){
  pivoted_i <- pivot_wider(data, names_from = species, values_from = occurrence) %>%
    distinct(plot_id, .keep_all = TRUE) %>%  # Ensure unique 'plot'
    column_to_rownames("plot_id")
  return(pivoted_i)
}

specWide <- lapply(specWide_list, pivot)

## Calculate sorensen similarity between control sites
## We do this using vegdist, and do 1 - dist so convert from dissimilarity to similarity
sim = specWide %>%
  map(~list(pid = .$pid[[1]], buffer = .$buffer[[1]], 
            sor = 1 - vegdist(.[, 3:ncol(.)], method = "bray", binary = TRUE)))


## Convert to long format for plotting and analysis
simLongSor = sim %>%
  map(~pivot_longer(cols = -plot, as.data.frame(as.matrix(.$sor)) %>% 
                      rownames_to_column("plot")) %>%
        rename(control = name, sor = value) %>% 
        filter(plot != control))


## Add pid and buffer to each data frame
simLongSor = simLongSor %>%
  map2(sim, ~mutate(.before = 1, .x, pid = .y$pid, buffer = .y$buffer)) %>%
  bind_rows()


names(simLongSor)[names(simLongSor) == 'plot'] <- 'plot_id'
names(simLongJac)[names(simLongJac) == 'plot'] <- 'plot_id'

## Keep only control sites in the control column of the data frame
## Do this by joining control sites to ensure it's the correct pid site combo
simLongSor = left_join(simLongSor, controlSites, join_by(pid, buffer, control == plot_id)) %>%
  filter(!is.na(fCov)) %>%
  dplyr::select(pid, buffer, plot_id, control, sor)

## ** Removing comparisons between control sites and other control sites **

simLong_filtered <- subset(simLongSor, ! plot_id  %in% unique(simLongSor$control))

write_csv(simLong_filtered, "data/processed/sensitivity_tests/absoluteReferenceSites_rawSimilarity_fp70.csv")



###### Prep model data ------------------------------------

sim <- simLong_filtered

## Load in distance data
distances = read_csv("data/processed/distances.csv")


# ensure that site (plot) names include study (PID) names
BIOFRAG <- distances[as.numeric(sapply(str_split(distances$pid, "D"), "[[", 2)) < 3000 ,]
PREDICTS <- distances[as.numeric(sapply(str_split(distances$pid, "D"), "[[", 2)) >= 3000 ,]

BIOFRAG$plot <- paste0(BIOFRAG$pid, "_", BIOFRAG$plot)
BIOFRAG$plot2 <- paste0(BIOFRAG$pid, "_", BIOFRAG$plot2)

PREDICTS$plot <- paste0(PREDICTS$pid, "_", PREDICTS$plot)
PREDICTS$plot2 <- paste0(PREDICTS$pid, "_", PREDICTS$plot2)

distances <- rbind(BIOFRAG, PREDICTS)


## Convert distance to km from m (distance/1000)
distances = distances %>% mutate(distance_km = distance/1000)

## Join distance and similarity data
## Left join with sim first so we only keep pristine sites in plot2
dat = left_join(sim, distances, join_by(pid == pid, plot_id == plot, control == plot2))


## Arcsin sqrt transform similarity metrics so they are not bound between 0 - 1
## so linear models are appropriate
dat = dat %>%
  mutate(sor = asin(sqrt(sor)))

## Load in forest cover data
## choose only forest (class == 1)
## and clean and rename columns
forest = read_csv("data/processed/percentage_Forest_Cover70.csv", locale = readr::locale(encoding = "latin1")) %>%
  filter(class == 1) %>%
  clean_names() %>% 
  dplyr::select(pid, buffer, plot_id, value) %>%
  rename(forest_cover = value)


## Change forest cover to be between 0 - 1
forest = forest %>% mutate(forest_cover = forest_cover/100)

## Add local forest cover at 50m buffer as another column
localForest = forest %>%
  filter(buffer == 50) %>%
  rename(local_forest_cover = forest_cover) %>%
  dplyr::select(-buffer)

## Join local forest to forest data frame
forest = left_join(forest, localForest, join_by(pid == pid, plot_id == plot_id))

## Join with dat based on plot (not control site)
dat = left_join(dat, forest, join_by(pid == pid, plot_id == plot_id, buffer == buffer))

## Save as data used for analysis
write_csv(dat, "data/processed/sensitivity_tests/absoluteReferenceSites_simDat_fp70.csv")

length(unique(dat$pid))
