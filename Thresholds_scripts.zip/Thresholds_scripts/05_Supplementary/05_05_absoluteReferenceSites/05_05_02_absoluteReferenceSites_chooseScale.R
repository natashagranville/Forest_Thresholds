##### Sensitivity test: absolute (90%) forest cover value for defining highly forested reference sites ---------------------


#### Choose scale of effect --------------

library(tidyverse)
library(segmented)
library(piecewiseSEM)


dat <- read.csv("data/processed/sensitivity_tests/absoluteReferenceSites_simDat_fp70.csv")


split_by_pid_and_buffer <- group_split(dat, pid, buffer)

cutOff_value <- 70

for(i in 1:length(split_by_pid_and_buffer)){
  
  tryCatch({
    
    x <- split_by_pid_and_buffer[[i]]
    
    print(paste0(x$pid[[1]], " ", x$buffer[[1]]))
    
    
    
    ## If > 1 control site run a linear mixed model with control site as a random effect
    if(n_distinct(x$control) == 1) {
      tryCatch({
        
        lin = lm(sor ~ forest_cover + distance_km, data = x)
        
        ## Create new models with forest cover removed for null slope tests
        nullLin = update(lin, . ~ . -forest_cover)
        
        ## Create negative forest cover to use in null right slope models
        negative_forest_cover = -x$forest_cover
        
        rseg = segmented(nullLin, seg.Z = ~negative_forest_cover, data = x)
        out = data.frame(pid = x$pid[[1]], buffer = x$buffer[[1]], r2 = summary(rseg)$r.squared, r22 = NA, segAIC = AIC(rseg), linAIC = AIC(lin)) %>%
          mutate(finalr2 = ifelse(is.na(r22), r2, (r2 + r22)/2))
        
        return(out)}, error = function(e) {NULL})
      
    } else {
      tryCatch({
        
        lin = lme(sor ~ forest_cover + distance_km, random = list(control = pdDiag(~1)), data = x)
        
        ## Create new models with forest cover removed for null slope tests
        nullLin = update(lin, . ~ . -forest_cover)
        
        ## Create negative forest cover to use in null right slope models
        negative_forest_cover = -x$forest_cover
        rseg = segmented.lme(nullLin, seg.Z = ~negative_forest_cover, random = list(control = pdDiag(~1 + G0)), data = x)
        out = data.frame(pid = x$pid[[1]], buffer = x$buffer[[1]], r2 = rsquared(rseg[[1]])$Marginal, r22 = rsquared(rseg[[2]])$Marginal, 
                         segAIC = AIC(rseg), linAIC = AIC(lin)) %>%
          ## Since we get 2 R2 values from segmented.lme models
          ## we will take the average
          mutate(finalr2 = ifelse(is.na(r22), r2, (r2 + r22)/2))
        
        return(out)}, error = function(e) {
          
          tryCatch({
            
            lin = lme(sor ~ forest_cover + distance_km, random = list(control = pdDiag(~1)), data = x)
            
            ## Create new models with forest cover removed for null slope tests
            nullLin = update(lin, . ~ . -forest_cover)
            
            ## Create negative forest cover to use in null right slope models
            negative_forest_cover = -x$forest_cover
            
            rseg = segmented.lme(nullLin, seg.Z = ~negative_forest_cover, random = list(control = pdDiag(~1)), data = x)
            out = data.frame(pid = x$pid[[1]], buffer = x$buffer[[1]], r2 = rsquared(rseg[[1]])$Marginal, r22 = rsquared(rseg[[2]])$Marginal, 
                             segAIC = AIC(rseg), linAIC = AIC(lin)) %>%
              ## Since we get 2 R2 values from segmented.lme models
              ## we will take the average
              mutate(finalr2 = ifelse(is.na(r22), r2, (r2 + r22)/2))
            
            return(out)}, error = function(e) {NULL})
        })
    }
    
    write.csv(out, paste0("data/processed/sensitivity_tests/absoluteRefereceSites_scaleOfEffect_fp", cutOff_value, "/", unique(x$pid), "_", unique(x$buffer), ".csv"))
    
    
  }, error = function(e) {
    print(paste("Error:", conditionMessage(e), "\n"))
    
  })
  
  
  rm(list = setdiff(ls(), c("split_by_pid_and_buffer", "cutOff_value")))
  
  
  
}



### Combine into one dataframe

files <- list.files(paste0("data/processed/sensitivity_tests/absoluteRefereceSites_scaleOfEffect_fp", cutOff_value), full = T)
data <- data.frame()
data_study <- data.frame()
for (i in 1:length(files)){
  file <- files[i]
  print(file)
  data_study <- read_csv(file, show_col_types = FALSE)
  data <- rbind(data, data_study)
}



scaleOfEffect <- data[,c("pid","buffer","r2","r22","segAIC","linAIC","finalr2")]

sort(unique(scaleOfEffect$pid))

## Find best scale of effect per PID
bestScale = scaleOfEffect %>%
  group_by(pid) %>%
  filter(finalr2 == max(finalr2)) %>%
  ungroup() %>%
  dplyr::select(-r2, -r22)

mean(bestScale$buffer)

dat <- read.csv(paste0("data/processed/sensitivity_tests/absoluteReferenceSites_simDat_fp", cutOff_value, ".csv"))

## Filter data to only include data at the optimal scale
dat = left_join(dat, bestScale, join_by(pid == pid, buffer == buffer)) %>%
  filter(!is.na(finalr2))

write.csv(dat, paste0("data/processed/sensitivity_tests/absoluteReferenceSites_bestScaleSimDat_fp", cutOff_value, ".csv"), row.names = F)
