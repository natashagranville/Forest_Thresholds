#### Basic info about the non-conservation-relevant thresholds -----------------

library(dplyr)
library(ggplot2)
library(sf)
library(tidyr)
library(viridis)

data <- read.csv("results/FinalData_fp70.csv")

data$nonRelevant_threshold_YN <- ifelse(data$type == "increasing_integrity_below_thresh", 1, 0)

nonConservationRelevantThresh_data <- subset(data, type == "increasing_integrity_below_thresh")

summary(nonConservationRelevantThresh_data$nSites)
summary(nonConservationRelevantThresh_data$nControls)


summary(data$nSites)
summary(data$nControls)





##### Map ----------------------------------------------------------------------
load("data/processed/study_Geometries.RData")

centroids <- lapply(study_Plot_Points_sf, function(x) {
  st_centroid(sfheaders::sf_multipoint(st_coordinates(x)))
})

PIDs <- lapply(study_Plot_Points_sf, function(x) {
  unique(x$PID)
})

centroids_sf <- do.call(rbind, centroids)
PIDs <- do.call(rbind, PIDs)

centroids <- cbind(centroids_sf, PIDs)
colnames(centroids) <- c("id","pid","geometry")

nonConservationRelevantThresh_data <- st_sf(left_join(nonConservationRelevantThresh_data, centroids, by = "pid"))

world <- map_data('world') %>% 
  as_tibble()

nonConservationRelevantThresh_data$Site_Longitude_x_wgs84 <- st_coordinates(nonConservationRelevantThresh_data)[,1]
nonConservationRelevantThresh_data$Site_Latitude_y_wgs84 <- st_coordinates(nonConservationRelevantThresh_data)[,2]



thresh_position_map <- ggplot() +
  geom_polygon(data=world, 
               aes(long, lat, group = group), colour=NA, fill='#C8C8C8', size=0) +#
  coord_map('mollweide', ylim = c(-60, 90), xlim = c(-180, 180)) +
  theme_void() +
  theme(panel.grid = element_blank(), 
        panel.border = element_blank(),
        axis.ticks = element_blank(),
        axis.title = element_blank(),
        axis.text = element_blank(),
        legend.position = c(0.1,0.5),
        legend.text = element_text(size = 16),
        legend.title = element_text(size = 16),
        legend.background = element_blank(),
        plot.margin = margin(0.5,0.5,0.5,0.5, "cm")) +
  scale_x_continuous(breaks = seq(-180, 180, by = 30), 
                     minor_breaks = seq(-180, 180, by = 10)) +
  scale_y_continuous(breaks = seq(-60, 90, by = 30), 
                     minor_breaks = seq(-60, 90, by = 10)) +
  geom_point(data = nonConservationRelevantThresh_data, aes(x = Site_Longitude_x_wgs84, y = Site_Latitude_y_wgs84, 
                                                            shape = taxa ,fill = g0, colour = g0),  size = 3) +
  scale_fill_viridis(direction = -1, breaks = c(0, 0.25, 0.5, 0.75, 1), name = "Threshold \nposition",
                       labels = c("0%", "25%", "50%", "75%", "100%"), limits = c(0, 1)) +
  scale_colour_viridis(direction = -1, breaks = c(0, 0.25, 0.5, 0.75, 1), name = "Threshold \nposition",
                     labels = c("0%", "25%", "50%", "75%", "100%"), limits = c(0, 1)) +
  scale_shape_manual(values = c(21, 22, 24, 25), name = "Taxonomic group")

thresh_position_map
ggsave(thresh_position_map, filename = "figures/nonConservationRelevantThresh_map.jpg")


##### Proportion of studies for each taxonommic group - doughnut plots ------------

data_sum <- st_drop_geometry(data) %>% 
  group_by(nonRelevant_threshold_YN, taxa) %>%
  summarise(count = n())



arthro <- subset(data_sum, taxa == "Arthropods")
arthro$fraction <- arthro$count / sum(arthro$count)
arthro$ymax <- cumsum(arthro$fraction)
arthro$ymin <- c(0, head(arthro$ymax, n=-1))
arthro$labelPosition <- (arthro$ymax + arthro$ymin) / 2
arthro$label <- paste0(arthro$count)

arthro_plot <- ggplot(arthro, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=as.factor(nonRelevant_threshold_YN))) +
  geom_rect() +
  geom_text(x=3.5, aes(y= labelPosition, label= label), size=7, fill = NA) +
  scale_fill_manual(values = c("orange", "#6a51a3")) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  ggtitle("Arthropods") +
  theme_void() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 18))
arthro_plot


bird <- subset(data_sum, taxa == "Birds")
bird$fraction <- bird$count / sum(bird$count)
bird$ymax <- cumsum(bird$fraction)
bird$ymin <- c(0, head(bird$ymax, n=-1))
bird$labelPosition <- (bird$ymax + bird$ymin) / 2
bird$label <- paste0(bird$count)

bird_plot <- ggplot(bird, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=as.factor(nonRelevant_threshold_YN))) +
  geom_rect() +
  geom_text(x=3.5, aes(y= labelPosition, label= label), size=7, fill = NA) +
  scale_fill_manual(values = c("orange", "#6a51a3")) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  ggtitle("Birds") +
  theme_void() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 18))
bird_plot


herp <- subset(data_sum, taxa == "Herptiles")
herp$fraction <- herp$count / sum(herp$count)
herp$ymax <- cumsum(herp$fraction)
herp$ymin <- c(0, head(herp$ymax, n=-1))
herp$labelPosition <- (herp$ymax + herp$ymin) / 2
herp$label <- paste0(herp$count)

herp_plot <- ggplot(herp, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=as.factor(nonRelevant_threshold_YN))) +
  geom_rect() +
  geom_text(x=3.5, aes(y= labelPosition, label= label), size=7, fill = NA) +
  scale_fill_manual(values = c("orange", "#6a51a3")) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  ggtitle("Herptiles") +
  theme_void() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 18))
herp_plot



mammal <- subset(data_sum, taxa == "Mammals")
mammal$fraction <- mammal$count / sum(mammal$count)
mammal$ymax <- cumsum(mammal$fraction)
mammal$ymin <- c(0, head(mammal$ymax, n=-1))
mammal$labelPosition <- (mammal$ymax + mammal$ymin) / 2
mammal$label <- paste0(mammal$count)

mammal_plot <- ggplot(mammal, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=as.factor(nonRelevant_threshold_YN))) +
  geom_rect() +
  geom_text(x=3.5, aes(y= labelPosition, label= label), size=7, fill = NA) +
  scale_fill_manual(values = c("orange", "#6a51a3")) +
  coord_polar(theta="y") +
  xlim(c(2, 4)) +
  ggtitle("Mammals") +
  theme_void() +
  theme(legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 18))
mammal_plot


all_taxa_plot <- cowplot:: plot_grid(arthro_plot, bird_plot, herp_plot, mammal_plot, align = "vh", nrow = 1)
all_taxa_plot
ggsave(all_taxa_plot, filename = "figures/nonConservationRelevantThresh_taxa_doughnut_plots.jpg")



##### Number of sites and reference sites -----------------------
hist(nonConservationRelevantThresh_data$nSites)
hist(nonConservationRelevantThresh_data$nControls)


nSite_data_to_plot <- pivot_longer(nonConservationRelevantThresh_data, 
                                   cols = c(nControls, nSites),
                                   names_to = "var")
nSite_data_to_plot$var <- factor(
  nSite_data_to_plot$var,
  levels = c("nSites", "nControls")
)

nSite_plot <- ggplot(nSite_data_to_plot, aes(x = var, y = value)) +
  geom_jitter(aes(shape = taxa ,fill = g0, colour = g0), width = 0.2) +
  geom_violin(fill = NA, colour = "grey50") +
  #geom_boxplot(fill = NA, colour = "black", width = 0.1) +
  scale_y_continuous(breaks = c(0,50,100,150,200, 250)) +
  scale_x_discrete(breaks = c("nSites", "nControls"), 
                   labels = c( "Total number of sites", "Number of reference sites")) +
  scale_fill_viridis(direction = -1, breaks = c(0, 0.25, 0.5, 0.75, 1), name = "Threshold \nposition",
                     labels = c("0%", "25%", "50%", "75%", "100%"), limits = c(0, 1)) +
  scale_colour_viridis(direction = -1, breaks = c(0, 0.25, 0.5, 0.75, 1), name = "Threshold \nposition",
                       labels = c("0%", "25%", "50%", "75%", "100%"), limits = c(0, 1)) +
  scale_shape_manual(values = c(21, 22, 24, 25), name = "Taxonomic group") +
  labs(x = "", y = "Number of sites") +
  theme_classic() +
  theme(axis.text = element_text(size = 12, colour = "black"),
      axis.title = element_text(size = 12),
      legend.text = element_text(size = 12),
      legend.title = element_text(size = 12))
nSite_plot
ggsave(nSite_plot, filename = "figures/nonConservationRelevantThresh_nSite_plot.jpg",
       height = 12, width = 17, units = "cm")
