#### Sensitivity test: selecting scale independently of model form --------------
#  compare linear and piecewise models across all candidate scales and then select the best-supported combination

# fit all linear and piecewise models at all scales, and extract the AIC

library(tidyverse)
library(segmented)
library(piecewiseSEM)


dat <- read.csv("data/processed/simDat_fp70.csv")

split_by_pid <- group_split(dat, pid)

cutOff_value <- 70



for(i in 1:length(split_by_pid)){
  
  tryCatch({
    
    pid_data <- split_by_pid[[i]]
    
    pid <- unique(pid_data$pid)
    
    
    print(pid)
    
    output <- data.frame()
    for(j in 1:length(unique(pid_data$buffer))){
      
      tryCatch({
        
      buff <- unique(pid_data$buffer)[j]
      
      print(buff)
      
      pid_buffer_data <- subset(pid_data, buffer == buff)
      
      if(length(unique(pid_buffer_data$control)) == 1) {
        
        ## If there is only one control site, use no random effects
        lin <- lm(sor ~ forest_cover + distance_km, data = pid_buffer_data)
        
      } else {    
        
        ## If >1 control sites, use control site as a random intercept
        lin <- lme(sor ~ forest_cover + distance_km, random = list(control = pdDiag(~1)), data = pid_buffer_data)
      }
      
      ## Create new models with forest cover removed for null slope tests
      nullLin <- update(lin, . ~ . -forest_cover)
      
      ## Create negative forest cover to use in null right slope models
      pid_buffer_data$negative_forest_cover <- -pid_buffer_data$forest_cover
      
      ## Run right null slope only 
      ## Varying if there is random effects based on number of control sites (==1 or >1)
      
      if(length(unique(pid_buffer_data$control)) == 1) {
        
        ## If there is only one control site, use no random effects
        rseg = tryCatch(segmented(nullLin, seg.Z = ~negative_forest_cover, data = pid_buffer_data),
                        warning = function(w) {NA}, error = function(e) {NA})
        
      } else {
        
        ## If >1 control sites, use control site as a random effect
        rseg = tryCatch(segmented.lme(nullLin, seg.Z = ~negative_forest_cover, random = list(control = pdDiag(~1+G0)), data = pid_buffer_data),
                        warning = function(w) {NA}, error = function(e) {NA}) 
      }
      
      output_row <- data.frame(
        model = c("lin", "rseg"),
        buff = buff,
        AIC = c(
          if (!any(is.na(lin))) AIC(lin) else NA,
          if (!any(is.na(rseg))) AIC(rseg) else NA
        )
      )
      
      print(output_row)
      
      output <- bind_rows(output, output_row)
      
      
      }, error = function(e) {
        print(paste("Error:", conditionMessage(e), "\n"))
        
      })
      
    }
    
    write.csv(output, paste0("data/processed/scaleIndependent_modelSelection/", pid, ".csv"))
    
    rm(list = setdiff(ls(), c("split_by_pid_and_buffer", "split_by_pid", "cutOff_value", "output")))
    
    
    
  }, error = function(e) {
    print(paste("Error:", conditionMessage(e), "\n"))
    
  })
  
  
  
}
