#### Sensitivity test: selecting scale independently of model form --------------
#  compare linear and piecewise models across all candidate scales and then select the best-supported combination

#  find the model-scale combination which has the best AIC and run the models at this scale

library(tidyverse)
library(segmented)
library(piecewiseSEM)


dat <- read.csv("data/processed/simDat_fp70.csv")

split_by_pid <- group_split(dat, pid)

cutOff_value <- 70




for(i in 1:length(split_by_pid)){
  
  
  tryCatch({
    
    
    pid_data <- split_by_pid[[i]]
    
    pid <- unique(pid_data$pid)
    
    
    print(pid)
    
    output <- data.frame()
    
    model_selection <- read.csv(paste0("data/processed/scaleIndependent_modelSelection/", pid, ".csv"))
    
    selected_model <- model_selection[which.min(model_selection$AIC),]
    
    pid_buffer_data <- subset(pid_data, buffer == selected_model$buff)
    
    
    
    if(length(unique(pid_buffer_data$control)) == 1) {
      
      ## If there is only one control site, use no random effects
      lin <- lm(sor ~ forest_cover + distance_km, data = pid_buffer_data)
      
    } else {    
      
      ## If >1 control sites, use control site as a random intercept
      lin <- lme(sor ~ forest_cover + distance_km, random = list(control = pdDiag(~1)), data = pid_buffer_data)
    }
    
  
      ## Create new models with forest cover removed for null slope tests
      nullLin <- update(lin, . ~ . -forest_cover)
      
      ## Create negative forest cover to use in null right slope models
      pid_buffer_data$negative_forest_cover <- -pid_buffer_data$forest_cover
      
      ## Run right null slope only 
      ## Varying if there is random effects based on number of control sites (==1 or >1)
      
      if(length(unique(pid_buffer_data$control)) == 1) {
        
        ## If there is only one control site, use no random effects
        rseg = tryCatch(segmented(nullLin, seg.Z = ~negative_forest_cover, data = pid_buffer_data),
                        warning = function(w) {NA}, error = function(e) {NA})
        
      } else {
        
        ## If >1 control sites, use control site as a random effect
        rseg = tryCatch(segmented.lme(nullLin, seg.Z = ~negative_forest_cover, random = list(control = pdDiag(~1+G0)), data = pid_buffer_data),
                        warning = function(w) {NA}, error = function(e) {NA}) 
      }
      
     
    
    
    
    out <- list(pid = pid, lin = lin, rseg = rseg)
    
    save(out, file = paste0("results/SorModels_scaleIndependent/", pid, ".Rdata"))
    
    
  }, error = function(e) {
    print(paste("Error:", conditionMessage(e), "\n"))
    
  })
  
}




