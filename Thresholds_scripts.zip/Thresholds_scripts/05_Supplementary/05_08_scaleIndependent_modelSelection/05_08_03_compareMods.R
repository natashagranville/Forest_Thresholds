#### Sensitivity test: selecting scale independently of model form --------------
#  compare linear and piecewise models across all candidate scales and then select the best-supported combination

# test whether the thresholds are significant based on 95% CIs
# and test whether they are conservation-relevant based on the direction

library(tidyverse)
library(janitor)
library(segmented) 
library(piecewiseSEM)
library(glmmTMB)
library(performance)

cutOff_value <- 70

files <- list.files("results/SorModels_scaleIndependent", full = T)

sorModels <- list()
for(i in 1:length(files)){
  load(files[[i]])
  sorModels[[i]] <- out
}

## Number of studies we successfully ran some models for
sorModels %>% length()

# Get AIC for each model in each list item
# and put into a data frame
getAIC = function(x) {
    if(length(x) > 1) {
        lin = AIC(x$lin)
        rseg = tryCatch(AIC(x$rseg), error = function(e) NA)
        return(data.frame(pid = x$pid, lin = lin, rseg = rseg))
    }
}


aic = lapply(sorModels, getAIC) %>%
    bind_rows()

## What is the top model for each study (only including 1 break point models)
aic = aic %>%
    pivot_longer(cols = -pid, names_to = "model", values_to = "aic") %>%
    group_by(pid) %>%
    slice_min(aic, with_ties = F)



# ## Load in scale data to combine with aic and save
# bestScale = read_csv(paste0("data/processed/bestScaleSimDat_fp", cutOff_value, ".csv")) %>%
#     distinct(pid, buffer)
# 
# 
# ## cases where >1 optimal scale was identified
# bestScale <- bestScale[-which(duplicated(bestScale$pid)),]

# aic = left_join(aic, bestScale)
# 
write.csv(aic, paste0("results/scaleIndependent_sorAIC_fp", cutOff_value, ".csv"), row.names = FALSE)
# 

## Which models best describe each study relationship
aic %>% group_by(model) %>% count() 


## Now check the single breakpoint models for differences in slope
## based on confidence intervals
# x <- sorModels[[1]]
# y <- aic$model[1]

checkSlopes = function(x, y) {
  
  print(x$pid[[1]])
  
  mod = x[y][[1]]
  
  if(y == "lin"){
    
    type = "lin"
    
    # Get R2
    if(class(mod) == "lme") {
      #piecewise SEM package for mixed effects models
      r2 <- rsquared(mod)$Marginal
    } else{
      # performance package if there are no random effects
      r2 <- as.numeric(r2(mod)[2])
    }
    
    out = data.frame(pid = x$pid, model = y, type = type, G0 = NA, lowG0 = NA, highG0 = NA,
                     lowU = NA, highU = NA, r2 = r2) %>%
      mutate(diffG0 = NA, diffU = NA)
    
  } else if(y == "rseg") {
    
    ## Check if model includes random effects (call > 4 if it is)
    if(length(mod$call) > 4) {
      conf = confint(mod, level = 0.95)
      confU = conf[,'U']
      
    } else if(length(mod$call) <= 4) {
      conf = confint.lm(mod, level = 0.95) %>% t() %>%
        as.data.frame() %>%
        rename("G0" = "psi1.negative_forest_cover", "U" = "U1.negative_forest_cover")
      confU = conf[,'U']
    }
    
    
    ## Check if difference in slopes crosses zero
    ## if it doesn't it's significant
    if(sign(confU[[1]]) == sign(confU[[2]])) {
      
      if(sign(confU[[1]]) == 1) {
        
        type = "increasing_integrity_below_thresh"
        
        confG0 = -conf[,"G0"]
        
      } else if(sign(confU[[1]]) == -1) {
        
        type = "declining_integrity_below_thresh"
        
        
        confG0 = -conf[,"G0"]
        
        # Bootstrap the 95% CIs for the threshold
        #boot_conf <- confint(mod, B=1000, parallel = "snow", ncpus = 4)
        
        # Get CIs of threshold
        #confG0 = -boot_conf[,"G0"]
        
      }
      
      
      if(length(mod$call) > 4) {
        thresh = -mod$lme.fit$coefficients$fixed["G0"]
      } else {
        thresh = -mod$psi[,"Est."]
        confG0[[1]] = thresh + confG0[[1]]
        confG0[[2]] = thresh + confG0[[2]]
      }
      
      
      # Get R2
      if(length(mod$call) > 4) {
        #piecewise SEM package for mixed effects models
        r2_1 <- rsquared(mod[[1]])$Marginal
        r2_2 <- rsquared(mod[[2]])$Marginal
        r2 <- (r2_1 + r2_2)/2
      } else{
        # performance package if there are no random effects
        r2 <- as.numeric(r2(mod)[2])
      }
      
      
      out <- data.frame(pid = x$pid, model = y, type = type,
                        G0 = thresh, lowG0 = confG0[[1]], highG0 = confG0[[2]],
                        lowU = confU[[1]], highU = confU[[2]], r2 = r2) %>%
        mutate(diffG0 = abs(highG0 - lowG0), diffU = abs(highU - lowU))
      
      # If the segmented model fit best, but the difference in slopes was not significant
    } else if(sign(confU[[1]]) != sign(confU[[2]])) {
      
      type = "nonSig_rseg"
      
      # Get R2
      if(length(mod$call) > 4) {
        #piecewise SEM package for mixed effects models
        r2_1 <- rsquared(mod[[1]])$Marginal
        r2_2 <- rsquared(mod[[2]])$Marginal
        r2 <- (r2_1 + r2_2)/2
      } else{
        # performance package if there are no random effects
        r2 <- as.numeric(r2(mod)[2])
      }
      
      
      out = data.frame(pid = x$pid, model = y, type = type, 
                       G0 = NA, lowG0 = NA, highG0 = NA,
                       lowU = NA, highU = NA, r2 = r2) %>%
        mutate(diffG0 = NA, diffU = NA)
    }
    
  }
  
  
  
  return(out)
  
}


resultsSor = mapply(x = sorModels, y = aic$model, FUN = checkSlopes, SIMPLIFY = FALSE) %>%
  bind_rows()



rownames(resultsSor)  <- NULL

resultsSor %>% group_by(type) %>% count() 

write_csv(resultsSor, "results/sorThresholds_scaleIndependent.csv")


#### Prep analysis data ---------------------------------------------

library(tidyverse)
library(janitor)
library(sf)
library(kableExtra)
library(viridis)
library(units)

## Load in dataquality which has most of the required data
cutOff_value <- 70
dataQuality = read_csv(paste0("data/processed/dataQuality_fp", cutOff_value, ".csv"))

# data that we tried running segmented models for
simDat <- read.csv(paste0("data/processed/simDat_fp", cutOff_value, ".csv"))
dataQuality <- subset(dataQuality, pid %in% unique(simDat$pid))

## Load in explanatory variable data
regionalForest = read.csv("data/processed/regional_Forest_Cover_fp70.csv") %>%
  clean_names()

load("data/processed/study_Geometries.RData")
avgLat = study_Plot_Points_sf %>% map2(.,., ~st_coordinates(.x) %>% as.data.frame() %>% add_column(PID = .y$PID)) %>% 
  bind_rows() %>% group_by(PID) %>% summarise(avg_Lat = abs(mean(Y))) %>%
  clean_names()

## Join up with data quality
dataQuality = left_join(dataQuality, avgLat, by = "pid")
dataQuality = left_join(dataQuality, regionalForest[,c("cover", "pid")], by = "pid")


## Load in taxa data and join with data quality
taxa = read_csv("data/processed/taxa_PID_Lookup.csv") %>%
  clean_names() %>%
  mutate(taxa = ifelse(taxa == "Bats", "Mammals", taxa))


dataQuality = left_join(dataQuality, taxa[,c("pid", "taxa")], by = "pid")

## Load in thresholds of sites with 
## significant differences in slopes
## and give threshold type and position
sorThresh = read_csv( "results/sorThresholds_scaleIndependent.csv") %>%
  clean_names()

## Join with data quality
data = left_join(dataQuality, sorThresh)




## Geographic area covered by the study
load("data/processed/study_Geometries.Rdata")

get_area <- function(study_data){
  hull <- st_convex_hull(st_union(study_data))
  study_data$area <- set_units(st_area(hull), km^2)
  return(study_data)
}

get_area_data <- lapply(study_Plot_Points_sf, get_area) %>%
  bind_rows() %>%
  st_drop_geometry() %>%
  group_by(PID) %>%
  summarise(area = unique(area)) %>%
  rename(pid = PID) %>%
  subset(pid %in% data$pid)


data <- left_join(data, get_area_data, by = "pid")

data <- subset(data,  g0 <= 1 | is.na(g0))

data <- subset(data, !is.na(data$cover))

data <- data[!duplicated(data$pid),]

## Change order of columns
finalTable = data %>%
  relocate(pid, taxa, g0, type, nSites, nControls, controlForest, forestRange, avg_lat, cover)



finalTable %>% group_by(type) %>% summarise(n())



## Regional deforestation 
finalTable$deforest <- 1 - finalTable$cover



## Binary term indicating presence/absence of relevant threshold
finalTable$relevant_threshold_YN <- ifelse(finalTable$type == "declining_integrity_below_thresh", 1, 0)

finalTable %>% group_by(relevant_threshold_YN) %>% summarise(n())


finalTable <- finalTable[!is.na(finalTable$relevant_threshold_YN),]


### Key info

# how many studies in total?
length(unique(finalTable$pid))

# how many studies with relevant thresholds?
finalTable_thresh <- subset(finalTable, relevant_threshold_YN == 1)
length(unique(finalTable_thresh$pid))

# how many studies in total for each taxa?
finalTable %>% group_by(taxa) %>% summarise(length(unique(pid)))

# how many studies with thresholds for each taxa?
finalTable_thresh %>% group_by(taxa) %>% summarise(length(unique(pid)))

# of the non-threshold studies, how many were non sig reg, how many were linear?
finalTable %>% group_by(type) %>% summarise(n())

# threshold positions
min(finalTable_thresh$g0, na.rm = T)
max(finalTable_thresh$g0, na.rm = T)
mean(finalTable_thresh$g0, na.rm = T)
median(finalTable_thresh$g0, na.rm = T)


##### Make supplementary table -----------------

### Get biome info
centroids <- lapply(study_Plot_Points_sf, function(x) {
  st_centroid(sfheaders::sf_multipoint(st_coordinates(x)))
})

PIDs <- lapply(study_Plot_Points_sf, function(x) {
  unique(x$PID)
})

centroids_sf <- do.call(rbind, centroids)
PIDs <- do.call(rbind, PIDs)

centroids <- cbind(centroids_sf, PIDs)
colnames(centroids) <- c("id","pid","geometry")


ecoregions <- st_read("data/raw/Ecoregions2017/Ecoregions2017.shp")

ecoregions <- st_transform(ecoregions, 4326)

ecoregions <- dplyr::select(ecoregions, c(ECO_NAME, BIOME_NAME, REALM))

ecoregions <- st_make_valid(ecoregions)

st_crs(centroids) <- 4326

ecoregion_data <- st_join(centroids, ecoregions)

finalTable <- left_join(finalTable, ecoregion_data[,c("pid", "REALM", "BIOME_NAME")], by = "pid")

finalTable<- finalTable %>% dplyr::select(-geometry)


finalTable <- finalTable[!duplicated(finalTable), ]

### save data for analysis
write.csv(finalTable, "results/finalData_scaleIndependent_ModelSelection.csv")

