#### Sensitivity test: selecting scale using linear models --------------
# fit linear models at all scales, select best scale then compare linear vs piecewise at this scale

# fit linear models at all scales


library(tidyverse)
library(segmented)
library(piecewiseSEM)


dat <- read.csv("data/processed/simDat_fp70.csv")

split_by_pid <- group_split(dat, pid)

cutOff_value <- 70



for(i in 1:length(split_by_pid)){
  
  tryCatch({
    
    pid_data <- split_by_pid[[i]]
    
    pid <- unique(pid_data$pid)
    
    
    print(pid)
    
    output <- data.frame()
    for(j in 1:length(unique(pid_data$buffer))){
      
      tryCatch({
        
        buff <- unique(pid_data$buffer)[j]
        
        print(buff)
        
        pid_buffer_data <- subset(pid_data, buffer == buff)
        
        if(length(unique(pid_buffer_data$control)) == 1) {
          
          ## If there is only one control site, use no random effects
          lin <- lm(sor ~ forest_cover + distance_km, data = pid_buffer_data)
          
        } else {    
          
          ## If >1 control sites, use control site as a random intercept
          lin <- lme(sor ~ forest_cover + distance_km, random = list(control = pdDiag(~1)), data = pid_buffer_data)
        }
        
        output_row <- data.frame(
          model = c("lin"),
          buff = buff,
          AIC = c(
            if (!any(is.na(lin))) AIC(lin) else NA
          )
        )
        
        print(output_row)
        
        output <- bind_rows(output, output_row)
        
        
      }, error = function(e) {
        print(paste("Error:", conditionMessage(e), "\n"))
        
      })
      
    }
    
    write.csv(output, paste0("data/processed/linearModel_scaleSelection/", pid, ".csv"))
    
    rm(list = setdiff(ls(), c("split_by_pid_and_buffer", "split_by_pid", "cutOff_value", "output")))
    
    
    
  }, error = function(e) {
    print(paste("Error:", conditionMessage(e), "\n"))
    
  })
  
  
  
}
