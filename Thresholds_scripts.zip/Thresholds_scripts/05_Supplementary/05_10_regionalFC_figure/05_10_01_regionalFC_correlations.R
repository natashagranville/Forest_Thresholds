#### Analyse regional forest cover metric -------------------------

library(ggplot2)
library(dplyr)
library(cowplot)


data <- read.csv("results/FinalData_fp70.csv")

##### All studies --------------------------------------------

forestRange_cor <- cor.test(data$cover, data$forestRange)
forestRange_cor$estimate

forestRange_plot <- ggplot(data, aes(x = forestRange, y = cover)) +
  geom_point(alpha = 0.7) + 
  theme_classic() +
  labs(x = "Range of landscape-scale forest cover", y = "Regional forest cover",
       title = paste0("Correlation coefficient = ", round(forestRange_cor$estimate, 2))) +
  theme(axis.text = element_text(size = 12, colour = "black"),
        axis.title = element_text(size = 12))
forestRange_plot


min_fCov_cor <- cor.test(data$cover, data$min_fCov)
min_fCov_cor$estimate

min_fCov_plot <- ggplot(data, aes(x = min_fCov, y = cover)) +
  geom_point(alpha = 0.7) + 
  theme_classic() +
  labs(x = "Minimum landscape-scale forest cover", y = "Regional forest cover",
       title = paste0("Correlation coefficient = ", round(min_fCov_cor$estimate, 2))) +
  theme(axis.text = element_text(size = 12, colour = "black"),
        axis.title = element_text(size = 12))
min_fCov_plot


max_fCov_cor <- cor.test(data$cover, data$max_fCov)
max_fCov_cor$estimate

max_fCov_plot <- ggplot(data, aes(x = max_fCov, y = cover)) +
  geom_point(alpha = 0.7) + 
  theme_classic() +
  labs(x = "Maximum landscape-scale forest cover", y = "Regional forest cover",
       title = paste0("Correlation coefficient = ", round(max_fCov_cor$estimate, 2))) +
  theme(axis.text = element_text(size = 12, colour = "black"),
        axis.title = element_text(size = 12))
max_fCov_plot


all_studies_plot <- plot_grid(forestRange_plot, NULL, min_fCov_plot, max_fCov_plot,
                              labels = c("(A)", "", "(B)", "(C)"),
                              label_fontface = "plain")

title <- ggdraw() + draw_label("All studies", fontface = 'bold')

all_studies_plot <- plot_grid(title, all_studies_plot,
                              ncol = 1, rel_heights = c(0.1, 1))
all_studies_plot

ggsave(all_studies_plot, file = "figures/regionalFC_correlations_all.jpg", height = 15, width = 20, units = "cm")






##### Studies in which a relevant threshold was identified  ------------------------------------

thresh_data <- subset(data, relevant_threshold_YN == 1)

forestRange_cor <- cor.test(thresh_data$cover, thresh_data$forestRange)
forestRange_cor$estimate

forestRange_plot <- ggplot(thresh_data, aes(x = forestRange, y = cover)) +
  geom_point(alpha = 0.7) + 
  theme_classic() +
  labs(x = "Range of landscape-scale forest cover", y = "Regional forest cover",
       title = paste0("Correlation coefficient = ", round(forestRange_cor$estimate, 2))) +
  theme(axis.text = element_text(size = 12, colour = "black"),
        axis.title = element_text(size = 12))
forestRange_plot


min_fCov_cor <- cor.test(thresh_data$cover, thresh_data$min_fCov)
min_fCov_cor$estimate

min_fCov_plot <- ggplot(thresh_data, aes(x = min_fCov, y = cover)) +
  geom_point(alpha = 0.7) + 
  theme_classic() +
  labs(x = "Minimum landscape-scale forest cover", y = "Regional forest cover",
       title = paste0("Correlation coefficient = ", round(min_fCov_cor$estimate, 2))) +
  theme(axis.text = element_text(size = 12, colour = "black"),
        axis.title = element_text(size = 12))
min_fCov_plot


max_fCov_cor <- cor.test(thresh_data$cover, thresh_data$max_fCov)
max_fCov_cor$estimate

max_fCov_plot <- ggplot(thresh_data, aes(x = max_fCov, y = cover)) +
  geom_point(alpha = 0.7) + 
  theme_classic() +
  labs(x = "Maximum landscape-scale forest cover", y = "Regional forest cover",
       title = paste0("Correlation coefficient = ", round(max_fCov_cor$estimate, 2))) +
  theme(axis.text = element_text(size = 12, colour = "black"),
        axis.title = element_text(size = 12))
max_fCov_plot


thresh_studies_plot <- plot_grid(forestRange_plot, NULL, min_fCov_plot, max_fCov_plot,
                                 labels = c("(A)", "", "(B)", "(C)"),
                                 label_fontface = "plain")

title <- ggdraw() + draw_label("Threshold studies", fontface = 'bold')

thresh_studies_plot <- plot_grid(title, thresh_studies_plot,
                              ncol = 1, rel_heights = c(0.1, 1))
thresh_studies_plot

ggsave(thresh_studies_plot, file = "figures/regionalFC_correlations_thresh.jpg", height = 15, width = 20, units = "cm")

