##### Sensitivity test - direct significance test on the difference-in-slopes parameter -----------------

# run models at the optimal scale, then use the Wald test to assess whether thresholds are significant


library(tidyverse)
library(janitor)
library(segmented) 
library(piecewiseSEM)
library(glmmTMB)
library(performance)

## Load in models
cutOff_value <- 70

files <- list.files(path = paste0("results/SorModels_fp", cutOff_value), pattern = "\\.Rdata$", full.names = TRUE)

sorModels <- list()
for(i in 1:length(files)){
  load(files[[i]])
  sorModels[[i]] <- out
}

## Number of studies we successfully ran some models for
sorModels %>% length()

# Get AIC for each model in each list item
# and put into a data frame
getAIC = function(x) {
  if(length(x) > 1) {
    lin = AIC(x$lin)
    rseg = tryCatch(AIC(x$rseg), error = function(e) NA)
    return(data.frame(pid = x$pid, lin = lin, rseg = rseg))
  }
}


aic = lapply(sorModels, getAIC) %>%
  bind_rows()

## What is the top model for each study (only including 1 break point models)
aic = aic %>%
  pivot_longer(cols = -pid, names_to = "model", values_to = "aic") %>%
  group_by(pid) %>%
  slice_min(aic, with_ties = F)

## Load in scale data to combine with aic and save
bestScale = read_csv(paste0("data/processed/bestScaleSimDat_fp", cutOff_value, ".csv")) %>%
  distinct(pid, buffer)


## cases where >1 optimal scale was identified
bestScale <- bestScale[-which(duplicated(bestScale$pid)),]

aic = left_join(aic, bestScale)

#write.csv(aic, paste0("results/sorAIC_fp", cutOff_value, ".csv"), row.names = FALSE)

## Which models best describe each study relationship
aic %>% group_by(model) %>% count() 


## Now check the single breakpoint models for differences in slope
## based on confidence intervals
# x <- sorModels[[3]]
# y <- aic$model[3]

x <- sorModels[[7]]
y <- aic$model[7]
y


checkSlopes = function(x, y) {
  
  print(x$pid[[1]])
  
  mod = x[y][[1]]
  
  if(y == "lin"){
    
    type = "lin"
    
    out = data.frame(pid = x$pid, model = y, type = type, G0 = NA, lowG0 = NA, highG0 = NA,
                     lowU = NA, highU = NA) %>%
      mutate(diffG0 = NA, diffU = NA)
    
  } else if(y == "rseg") {
    
    ### Get the signs of the slopes so that we can test whether it is a conservation-relevant threshold or not
    
    if(length(mod$call) > 4) { ## Check if model includes random effects (call > 4 if it is)
      conf = confint(mod, level = 0.95)
      confU = conf[,'U']
      
      confG0 = -conf[,"G0"]
      
      
    } else if(length(mod$call) <= 4) {
      conf = confint.lm(mod, level = 0.95) %>% t() %>%
        as.data.frame() %>%
        rename("G0" = "psi1.negative_forest_cover", "U" = "U1.negative_forest_cover")
      confU = conf[,'U']
      
      confG0 = -conf[,"G0"]
      
    }
    
    ## Get the actual value of the threshold
    if(length(mod$call) > 4) {
      thresh = -mod$lme.fit$coefficients$fixed["G0"]
    } else {
      thresh = -mod$psi[,"Est."]
      confG0[[1]] = thresh + confG0[[1]]
      confG0[[2]] = thresh + confG0[[2]]
    }
    
    
    ### Test of contrast between regression coefficients

    mod_summary <- summary(mod)
   
    if(class(mod)[1] == "segmented.lme"){
        
      # can't use pscore.test() for a mixed effect model
      # so we'll calculate the test statistic and p-value manually:
      
      beta <- mod_summary$lme.fit$coefficients$fixed["U"] # difference-in-slopes parameter
        
      se <- sqrt(mod_summary$lme.fit$varFix["U", "U"])
        
        
      # https://suchibrata.in/blog/statistical-tests/wald-test 
      t <- beta / se # Wald t-statistic
      # testing null hypothesis that beta (the difference-in-slopes parameter) is equal to zero
      # t = (beta - 0)/se
     
      df <- mod_summary$lme.fit$fixDF$X["U"]
        
      # calculate p value from t distribution: https://www.cyclismo.org/tutorial/R/pValues.html 
      p <- 2 * pt(abs(t), df = df, lower.tail = FALSE)
     
      
    } else if(class(mod)[2] == "lm"){

      # this tests for a non-zero difference-in-slope parameter in a segmented regression
      # an alternative would be davies.test() but pscore.test() is more powerful when testing for _one_ breakpoint, rather than two or more 
      p <- pscore.test(mod)$p.value
      
    }
    
    
    if(p >= 0.05){
          
        type = "nonSig_rseg"
          
          
    } else if(p < 0.05){
      
      if(sign(confU[[1]]) == 1) {
        
        type = "increasing_integrity_below_thresh"
        
        } else if(sign(confU[[1]]) == -1) {
            
            type = "declining_integrity_below_thresh"
            
          }
          
      }
        
        
      print(type)
      
      out <- data.frame(pid = x$pid, model = y, type = type,
                        G0 = thresh, lowG0 = confG0[[1]], highG0 = confG0[[2]],
                        lowU = confU[[1]], highU = confU[[2]]) %>%
        mutate(diffG0 = abs(highG0 - lowG0), diffU = abs(highU - lowU))
      
    }
  
  #return(out)
  
}
  
  
 

resultsSor = mapply(x = sorModels, y = aic$model, FUN = checkSlopes, SIMPLIFY = FALSE) %>%
  bind_rows()


rownames(resultsSor)  <- NULL

resultsSor %>% group_by(type) %>% count() 


write_csv(resultsSor, "data/processed/direct_hypothesis_test_sorThresh.csv")
