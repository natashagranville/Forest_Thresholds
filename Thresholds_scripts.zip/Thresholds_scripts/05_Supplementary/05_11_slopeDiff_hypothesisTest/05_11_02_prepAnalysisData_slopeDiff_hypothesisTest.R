##### Sensitivity test - direct significance test on the difference-in-slopes parameter -----------------

## Prep analysis data

library(tidyverse)
library(janitor)
library(sf)
library(kableExtra)
library(viridis)
library(units)

## Load in dataquality which has most of the required data
cutOff_value <- 70
dataQuality = read_csv(paste0("data/processed/dataQuality_fp", cutOff_value, ".csv"))

# data that we tried running segmented models for
simDat <- read.csv(paste0("data/processed/simDat_fp", cutOff_value, ".csv"))
dataQuality <- subset(dataQuality, pid %in% unique(simDat$pid))

## Load in scale of effect data
bestScale = read_csv(paste0("data/processed/bestScaleSimDat_fp", cutOff_value, ".csv")) %>%
  distinct(pid, buffer)

## Filter dataquality by the scale of effect
dataQuality = inner_join(dataQuality, bestScale)

## Load in explanatory variable data
regionalForest = read.csv(paste0("data/processed/regional_Forest_Cover_fp", cutOff_value, ".csv")) %>%
  clean_names()

load("data/processed/study_Geometries.RData")
avgLat = study_Plot_Points_sf %>% map2(.,., ~st_coordinates(.x) %>% as.data.frame() %>% add_column(PID = .y$PID)) %>% 
  bind_rows() %>% group_by(PID) %>% summarise(avg_Lat = abs(mean(Y))) %>%
  clean_names()

## Join up with data quality
dataQuality = left_join(dataQuality, avgLat, by = "pid")
dataQuality = left_join(dataQuality, regionalForest[,c("cover", "pid")], by = "pid")


## Load in taxa data and join with data quality
taxa = read_csv("data/processed/taxa_PID_Lookup.csv") %>%
  clean_names() %>%
  mutate(taxa = ifelse(taxa == "Bats", "Mammals", taxa))

dataQuality = left_join(dataQuality, taxa[,c("pid", "taxa")], by = "pid")

## Load in the data from this sensitivity test
# the thresholds identified using the less conservative Wald-test approach
sorThresh = read_csv("data/processed/direct_hypothesis_test_sorThresh.csv") %>%
  clean_names()

## Join with data quality
data = left_join(dataQuality, sorThresh)




## Geographic area covered by the study
load("data/processed/study_Geometries.Rdata")


get_area <- function(study_data){
  hull <- st_convex_hull(st_union(study_data))
  study_data$area <- set_units(st_area(hull), km^2)
  return(study_data)
}

get_area_data <- lapply(study_Plot_Points_sf, get_area) %>%
  bind_rows() %>%
  st_drop_geometry() %>%
  group_by(PID) %>%
  summarise(area = unique(area)) %>%
  rename(pid = PID) %>%
  subset(pid %in% data$pid)


data <- left_join(data, get_area_data, by = "pid")

data <- subset(data,  g0 <= 1 | is.na(g0))

data <- subset(data, !is.na(data$cover))

data <- data[!duplicated(data$pid),]

## Change order of columns
finalTable = data %>%
  relocate(pid, taxa, g0, type, nSites, nControls, controlForest, forestRange, avg_lat, cover)



finalTable %>% group_by(type) %>% summarise(n())



## Regional deforestation 
finalTable$deforest <- 1 - finalTable$cover



## Binary term indicating presence/absence of relevant threshold
finalTable$relevant_threshold_YN <- ifelse(finalTable$type == "declining_integrity_below_thresh", 1, 0)

finalTable %>% group_by(relevant_threshold_YN) %>% summarise(n())


### Key info

# how many studies in total?
length(unique(finalTable$pid))

# how many studies with relevant thresholds?
finalTable_thresh <- subset(finalTable, relevant_threshold_YN == 1)
length(unique(finalTable_thresh$pid))

# how many studies in total for each taxa?
finalTable %>% group_by(taxa) %>% summarise(length(unique(pid)))

# how many studies with thresholds for each taxa?
finalTable_thresh %>% group_by(taxa) %>% summarise(length(unique(pid)))

# of the non-threshold studies, how many were non sig reg, how many were linear?
finalTable %>% group_by(type) %>% summarise(n())

# threshold positions
min(finalTable_thresh$g0, na.rm = T)
max(finalTable_thresh$g0, na.rm = T)
mean(finalTable_thresh$g0, na.rm = T)
median(finalTable_thresh$g0, na.rm = T)


##### Make supplementary table -----------------

### Get biome info
centroids <- lapply(study_Plot_Points_sf, function(x) {
  st_centroid(sfheaders::sf_multipoint(st_coordinates(x)))
})

PIDs <- lapply(study_Plot_Points_sf, function(x) {
  unique(x$PID)
})

centroids_sf <- do.call(rbind, centroids)
PIDs <- do.call(rbind, PIDs)

centroids <- cbind(centroids_sf, PIDs)
colnames(centroids) <- c("id","pid","geometry")


ecoregions <- st_read("data/raw/Ecoregions2017/Ecoregions2017.shp")

ecoregions <- st_transform(ecoregions, 4326)

ecoregions <- dplyr::select(ecoregions, c(ECO_NAME, BIOME_NAME, REALM))

ecoregions <- st_make_valid(ecoregions)

st_crs(centroids) <- 4326

ecoregion_data <- st_join(centroids, ecoregions)

finalTable <- left_join(finalTable, ecoregion_data[,c("pid", "REALM", "BIOME_NAME")], by = "pid")

finalTable<- finalTable %>% dplyr::select(-geometry)


### save data for analysis
write.csv(finalTable, "data/processed/direct_hypothesis_test_finalData.csv")

