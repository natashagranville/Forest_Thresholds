#### Sensitivity test: removing model weights from analysis of threshold position ------------------------------------


library(glmmTMB)
library(emmeans)
library(tidyverse)
library(sjPlot)


data <- read.csv("results/FinalData_fp70.csv")
data %>% group_by(taxa) %>% summarise(n())

thresh_data <- subset(data, relevant_threshold_YN == 1)


min(thresh_data$g0, na.rm = T)
max(thresh_data$g0, na.rm = T)
mean(thresh_data$g0, na.rm = T)
median(thresh_data$g0, na.rm = T)

## Swap lowG0 and highG0 around if the model was an rseg as it messes up plotting
thresh_data = thresh_data %>% mutate(newLowG0 = ifelse(model == "rseg", low_g0, 0),
                                     low_g0 = ifelse(model == "rseg", high_g0, lowG0),
                                     high_g0 = ifelse(model == "rseg", newLowG0, highG0))


## We will model the position of the threholds using a beta regression since our
## response is bounded between  0 - 1
thresh_data = thresh_data %>% mutate(weightDiffG0 = log(1/diff_g0), type = as.factor(type))






#### Latitude + regional FC ------------------------

thresh_data$vert_invert <- ifelse(thresh_data$taxa == "Arthropods", "Invertebrates", "Vertebrates")
thresh_data$vert_invert <- as.factor(thresh_data$vert_invert )

LatMod = glmmTMB(g0 ~ avg_lat * vert_invert, data = thresh_data, family = beta_family())
summary(LatMod)


LatMod = glmmTMB(g0 ~ avg_lat * relevel(vert_invert, ref = "Vertebrates"), data = thresh_data, family = beta_family())
summary(LatMod)



RegionalFCMod = glmmTMB(g0 ~ cover * vert_invert, data = thresh_data, family = beta_family())
summary(RegionalFCMod)





RegionalFCMod = glmmTMB(g0 ~ cover * relevel(vert_invert, ref = "Vertebrates"), data = thresh_data, family = beta_family())
summary(RegionalFCMod)
